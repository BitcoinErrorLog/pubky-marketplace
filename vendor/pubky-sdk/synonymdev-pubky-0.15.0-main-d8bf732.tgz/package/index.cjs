const makeFetchCookie = require("fetch-cookie").default;

let originalFetch = globalThis.fetch;
globalThis.fetch = makeFetchCookie(originalFetch);

/* @ts-self-types="./pubky.d.ts" */

function __pubkyRecoveredEncryptionKeys(publicKey, grantId, keys) {
    return { publicKey, grantId, keys };
}

async function __pubkyImportEncryptionCryptoKey(bytes) {
    try {
        if (!globalThis.crypto?.subtle) {
            throw new Error("WebCrypto is unavailable; use a secure context.");
        }
        return await globalThis.crypto.subtle.importKey(
            "raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
    } finally {
        bytes.fill(0);
    }
}

const PUBKY_SESSIONS_DB_NAME = "pubky-auth";
const PUBKY_SESSIONS_DB_VERSION = 1;
const PUBKY_SESSIONS_STORE_NAME = "storedSessions";
const PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME = "delegatedGrantKeys";
const PUBKY_APPROVAL_SESSION_VERSION = "pubky-session-v2";

/** Assert that IndexedDB is available for browser session persistence. */
function requireIndexedDb() {
  if (!globalThis.indexedDB) {
    throw new Error("Pubky session persistence requires IndexedDB.");
  }
}

/** Create an operation-specific error while preserving the IndexedDB cause. 
 * Used for backwards compatability because old browsers don't support the cause property.
 */
function contextualSessionStoreError(message, cause) {
  const error = new Error(message, { cause });
  if (cause !== undefined && error.cause === undefined) {
    error.cause = cause;
  }
  return error;
}

/**
 * Open the IndexedDB database used for browser auth persistence.
 *
 * The database contains session records and delegated WebCrypto key handles so
 * both stores are created here even though single-store helpers use only one.
 */
function openSessionStoreDb() {
  requireIndexedDb();
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(PUBKY_SESSIONS_DB_NAME, PUBKY_SESSIONS_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PUBKY_SESSIONS_STORE_NAME)) {
        db.createObjectStore(PUBKY_SESSIONS_STORE_NAME, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME)) {
        db.createObjectStore(PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME, { keyPath: "keyId" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Opening Pubky session store failed."));
  });
}

/**
 * Run an IndexedDB operation across session records and browser keys.
 *
 * The callback receives the transaction and returns a request. This wrapper
 * resolves only after the transaction commits, not when the request succeeds.
 */
async function withSessionStores(mode, operation) {
  const db = await openSessionStoreDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(
        [PUBKY_SESSIONS_STORE_NAME, PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME], mode,
      );
      let result;
      try {
        const request = operation(tx);
        request.onsuccess = () => {
          result = request.result;
        };
        request.onerror = () => reject(request.error ?? new Error("Pubky session store request failed."));
      } catch (error) {
        tx.abort();
        reject(error);
      }
      tx.onerror = () => reject(tx.error ?? new Error("Pubky session store transaction failed."));
      tx.onabort = () => reject(tx.error ?? new Error("Pubky session store transaction aborted."));
      tx.oncomplete = () => resolve(result);
    });
  } finally {
    db.close();
  }
}

/** Return whether browser session persistence can open its IndexedDB database. */
async function __pubkySessionStoreIsAvailable() {
  if (!globalThis.indexedDB) return false;
  try {
    if (!globalThis.navigator?.locks) return false;
    const db = await openSessionStoreDb();
    db.close();
    return true;
  } catch (_error) {
    return false;
  }
}

/** Persist or replace a browser session record. */
async function __pubkySessionStorePut(record, lease) {
  requireIndexedDb();
  try {
    const previous = await __pubkySessionStoreGet(record.id);
    if (previous?.version === PUBKY_APPROVAL_SESSION_VERSION && record.version !== previous.version) {
      throw new Error("Cannot replace a stored approval with an authentication-only record.");
    }
    const stored = { ...record };
    if (previous?.sharedSession) stored.sharedSession = previous.sharedSession;
    await withSessionStores("readwrite", tx => {
      const held = requireSessionLease(lease, true);
      if (held.id !== record.id || held.homeserver !== record.homeserver) {
        throw new Error("Session record does not match its browser lock.");
      }
      return tx.objectStore(PUBKY_SESSIONS_STORE_NAME).put(stored);
    });
  } catch (error) {
    throw contextualSessionStoreError("Saving Pubky session failed.", error);
  }
}

function sessionMetadata(record) {
  if (!record) return record;
  const { version, id, storageMode, publicKey, homeserver, grantId, clientId,
    capabilities, grantExpiresAt, createdAt } = record;
  return { version, id, storageMode, publicKey, homeserver, grantId, clientId,
    capabilities, grantExpiresAt, createdAt,
    hasStoredApproval: record.signedApproval !== undefined,
  };
}

async function __pubkySessionStoreMetadata(id) {
  return sessionMetadata(await __pubkySessionStoreGet(id));
}

/** Load a browser session record by id. */
async function __pubkySessionStoreGet(id) {
  requireIndexedDb();
  try {
    return await withSessionStores("readonly", tx =>
      tx.objectStore(PUBKY_SESSIONS_STORE_NAME).get(id),
    );
  } catch (error) {
    throw contextualSessionStoreError("Reading Pubky session failed.", error);
  }
}

/** List all browser session records, returning an empty list if storage is unavailable. */
async function __pubkySessionStoreList() {
  if (!globalThis.indexedDB) return [];
  try {
    const records = await withSessionStores("readonly", tx =>
      tx.objectStore(PUBKY_SESSIONS_STORE_NAME).getAll(),
    );
    return records.map(sessionMetadata);
  } catch (_error) {
    return [];
  }
}

/** Clear saved sessions and their keys, or every key when clearing all auth state. */
async function clearSessionStore(allKeys = false) {
  requireIndexedDb();
  const db = await openSessionStoreDb();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(
        [PUBKY_SESSIONS_STORE_NAME, PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME], "readwrite",
      );
      const sessions = tx.objectStore(PUBKY_SESSIONS_STORE_NAME);
      const keys = tx.objectStore(PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME);
      const records = sessions.getAll();
      records.onsuccess = () => {
        try {
          if (allKeys) keys.clear();
          else for (const record of records.result) {
            if (record.storageMode === "delegated") keys.delete(JSON.parse(record.credential).keyId);
          }
          sessions.clear();
        } catch (error) { tx.abort(); reject(error); }
      };
      tx.oncomplete = resolve;
      tx.onerror = tx.onabort = () => reject(tx.error ?? new Error("Clearing browser sessions failed."));
    });
  } finally { db.close(); }
}

const SESSION_STORE_LOCK = "pubky-session-store";
const sessionLeases = new Map();
let nextSessionLease = 0;
const sessionChannel = typeof indexedDB !== "undefined" && typeof BroadcastChannel === "function"
  ? new BroadcastChannel("pubky-session-store") : null;
function notifySessionChange(detail) {
  if (typeof globalThis.dispatchEvent === "function") {
    globalThis.dispatchEvent(new CustomEvent("pubky-session-changed", { detail }));
  }
}
if (sessionChannel) sessionChannel.onmessage = event => notifySessionChange(event.data);
function sessionChanged(id, action) {
  const detail = { id, action };
  notifySessionChange(detail);
  sessionChannel?.postMessage(detail);
}

function __pubkySessionAcquire(id, homeserver, exclusive) {
  if (!globalThis.navigator?.locks) throw new Error("Browser sessions require Web Locks in a secure context.");
  const token = ++nextSessionLease;
  const abort = new AbortController();
  let release, ready, failed;
  const held = new Promise(resolve => { release = resolve; });
  const waiting = new Promise((resolve, reject) => { ready = resolve; failed = reject; });
  // Cancellation can drop the Rust future before it starts awaiting this promise.
  waiting.catch(() => {});
  const lease = { id, homeserver, exclusive, abort, release, waiting, active: false };
  sessionLeases.set(token, lease);
  navigator.locks.request(SESSION_STORE_LOCK, { mode: "shared", signal: abort.signal }, () =>
    navigator.locks.request(`pubky-shared-session:${homeserver}:${id}`, {
      mode: exclusive ? "exclusive" : "shared", signal: abort.signal,
    }, async () => {
      lease.active = true;
      ready();
      await held;
    })
  ).catch(failed);
  return token;
}
function __pubkySessionWait(token) {
  return sessionLeases.get(token).waiting;
}
function __pubkySessionRelease(token) {
  const lease = sessionLeases.get(token);
  if (!lease) return;
  lease.active = false;
  lease.abort.abort();
  lease.release();
  sessionLeases.delete(token);
}
function requireSessionLease(token, write = false) {
  const lease = sessionLeases.get(token);
  if (!lease?.active || (write && !lease.exclusive)) throw new Error("Browser session lock was released.");
  return lease;
}
async function __pubkySharedSessionLoad(token) {
  const lease = requireSessionLease(token);
  const record = await __pubkySessionStoreGet(lease.id);
  if (record && record.homeserver !== lease.homeserver) throw new Error("Stored session homeserver changed.");
  return record?.sharedSession;
}
async function __pubkySharedSessionStore(token, sharedSession) {
  const lease = requireSessionLease(token, true);
  const record = await __pubkySessionStoreGet(lease.id);
  if (!record || record.homeserver !== lease.homeserver) throw new Error("Browser session was removed or changed.");
  await withSessionStores("readwrite", tx => {
    requireSessionLease(token, true);
    return tx.objectStore(PUBKY_SESSIONS_STORE_NAME).put({ ...record, sharedSession });
  });
}
async function __pubkySharedSessionRemove(token) {
  const lease = requireSessionLease(token, true);
  const record = await __pubkySessionStoreGet(lease.id);
  if (!record) return;
  const db = await openSessionStoreDb();
  try {
    requireSessionLease(token, true);
    await new Promise((resolve, reject) => {
      const tx = db.transaction([PUBKY_SESSIONS_STORE_NAME, PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME], "readwrite");
      tx.objectStore(PUBKY_SESSIONS_STORE_NAME).delete(lease.id);
      if (record.storageMode === "delegated") {
        const { keyId } = JSON.parse(record.credential);
        tx.objectStore(PUBKY_SESSIONS_DELEGATED_KEYS_STORE_NAME).delete(keyId);
      }
      tx.oncomplete = resolve;
      tx.onerror = tx.onabort = () => reject(tx.error ?? new Error("Removing browser session failed."));
    });
  } finally { db.close(); }
  sessionChanged(lease.id, "removed");
}
async function __pubkySessionStoreClear() {
  await navigator.locks.request(SESSION_STORE_LOCK, () => clearSessionStore());
  sessionChanged(null, "cleared");
}
async function __pubkySessionStoreClearAll() {
  await navigator.locks.request(SESSION_STORE_LOCK, () => clearSessionStore(true));
  sessionChanged(null, "cleared");
}

const PUBKY_GRANT_KEYS_DB_NAME = "pubky-auth";
const PUBKY_GRANT_KEYS_DB_VERSION = 1;
const PUBKY_GRANT_KEYS_STORE_NAME = "delegatedGrantKeys";
const PUBKY_GRANT_KEYS_SESSION_STORE_NAME = "storedSessions";
let canUseDelegationPromise;
const TEST_CAN_USE_DELEGATION_OVERRIDE = "__pubkyGrantCanUseDelegationOverride";

/**
 * Assert that this runtime can persist non-extractable browser signing keys.
 *
 * SubtleCrypto is exposed only in secure contexts. We rely on browser feature
 * detection here so each browser can decide which origins are trustworthy,
 * including localhost, file://, extension pages, and workers.
 */
function requireBrowserCrypto() {
  const g = globalThis;

  if (!g.crypto?.subtle || !g.indexedDB) {
    if (!g.isSecureContext) {
      throw new Error("Delegated grant keys require a secure browser context.");
    }
    throw new Error("Delegated grant keys require browser WebCrypto and IndexedDB.");
  }
}

function contextualError(message, cause) {
  const error = new Error(message, { cause });
  if (cause !== undefined && error.cause === undefined) {
    error.cause = cause;
  }
  return error;
}

/**
 * Return whether this runtime appears able to use delegated grant keys.
 *
 * This is a synchronous feature check only. Starting, resuming, or restoring a
 * delegated flow can still fail later if IndexedDB access is denied, storage is
 * cleared, or a saved key id no longer exists.
 */
function __pubkyGrantIsDelegationAvailable() {
  const g = globalThis;
  return Boolean(g.isSecureContext && g.crypto?.subtle && g.indexedDB);
}

/**
 * Return whether this runtime can actually create, store, and use browser-held
 * Ed25519 delegated grant keys.
 *
 * Some browser-like runtimes expose secure WebCrypto and IndexedDB but do not
 * implement Ed25519. Cache the probe because it creates a real CryptoKey and
 * verifies that IndexedDB can store/delete it.
 */
async function __pubkyGrantCanUseDelegation() {
  const override = globalThis[TEST_CAN_USE_DELEGATION_OVERRIDE];
  if (override === true || override === false) return override;

  if (!canUseDelegationPromise) {
    canUseDelegationPromise = (async () => {
      try {
        requireBrowserCrypto();
        const keyId = `__pubky_probe_${randomKeyId()}`;
        const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, false, ["sign", "verify"]);
        const publicKeyRaw = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
        const data = new TextEncoder().encode("pubky-delegated-grant-probe");
        const signature = new Uint8Array(await crypto.subtle.sign({ name: "Ed25519" }, pair.privateKey, data));
        if (publicKeyRaw.length !== 32 || signature.length !== 64) return false;
        await putRecord({
          keyId,
          privateKey: pair.privateKey,
          publicKeyRaw,
          createdAt: Date.now(),
        });
        await deleteRecord(keyId);
        return true;
      } catch (_error) {
        return false;
      }
    })();
  }
  return await canUseDelegationPromise;
}

/**
 * Open the IndexedDB database used for delegated grant keys.
 *
 * Records are keyed by the SDK-level key id and contain a non-extractable
 * CryptoKey plus the raw public key bytes needed for grant metadata.
 */
function openGrantKeyDb() {
  requireBrowserCrypto();
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(PUBKY_GRANT_KEYS_DB_NAME, PUBKY_GRANT_KEYS_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PUBKY_GRANT_KEYS_STORE_NAME)) {
        db.createObjectStore(PUBKY_GRANT_KEYS_STORE_NAME, { keyPath: "keyId" });
      }
      if (!db.objectStoreNames.contains(PUBKY_GRANT_KEYS_SESSION_STORE_NAME)) {
        db.createObjectStore(PUBKY_GRANT_KEYS_SESSION_STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Opening delegated grant key store failed."));
  });
}

/**
 * Run an IndexedDB operation against the delegated-key object store.
 *
 * The callback receives the object store and returns a request. This wrapper
 * resolves only after the transaction commits, not when the request succeeds.
 */
async function withGrantKeyStore(mode, operation) {
  const db = await openGrantKeyDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(PUBKY_GRANT_KEYS_STORE_NAME, mode);
      const store = tx.objectStore(PUBKY_GRANT_KEYS_STORE_NAME);
      let result;
      let settled = false;

      function fail(error) {
        if (settled) return;
        settled = true;
        reject(error);
      }

      try {
        const request = operation(store);
        request.onsuccess = () => {
          result = request.result;
        };
        request.onerror = () => fail(request.error ?? new Error("Delegated grant key request failed."));
      } catch (error) {
        fail(error);
      }
      tx.onerror = () => fail(tx.error ?? new Error("Delegated grant key transaction failed."));
      tx.onabort = () => fail(tx.error ?? new Error("Delegated grant key transaction aborted."));
      tx.oncomplete = () => {
        if (settled) return;
        settled = true;
        resolve(result);
      };
    });
  } finally {
    db.close();
  }
}

/**
 * Load a delegated-key record by key id.
 *
 * Returns `undefined` when the key id is unknown. Callers decide whether that
 * should create a new key or surface a restore/signing error.
 */
async function getRecord(keyId) {
  try {
    return await withGrantKeyStore("readonly", (store) => store.get(keyId));
  } catch (error) {
    throw contextualError("Reading delegated grant key failed.", error);
  }
}

/**
 * Persist a delegated-key record.
 *
 * The private key is a non-extractable CryptoKey, so IndexedDB stores a browser
 * handle rather than raw private key bytes.
 */
async function putRecord(record) {
  try {
    await withGrantKeyStore("readwrite", (store) => store.put(record));
  } catch (error) {
    throw contextualError("Saving delegated grant key failed.", error);
  }
}

async function deleteRecord(keyId) {
  try {
    await withGrantKeyStore("readwrite", (store) => store.delete(keyId));
  } catch (error) {
    throw contextualError("Deleting delegated grant key failed.", error);
  }
}

/**
 * Generate an opaque key id for the IndexedDB record.
 *
 * Use randomUUID when available, with a getRandomValues fallback for older
 * secure browser contexts.
 */
function randomKeyId() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Ensure a delegated grant signing key exists.
 *
 * If `keyId` is provided by an internal restore/reuse path and already exists,
 * return its public key. Otherwise generate a new non-extractable Ed25519
 * keypair, store the private CryptoKey in IndexedDB, and return
 * `{ keyId, publicKey }`.
 */
async function __pubkyGrantEnsureDelegatedKey(keyId) {
  requireBrowserCrypto();
  const resolvedKeyId = keyId || randomKeyId();
  const existing = await getRecord(resolvedKeyId);
  if (existing) {
    return { keyId: resolvedKeyId, publicKey: new Uint8Array(existing.publicKeyRaw) };
  }

  const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, false, ["sign", "verify"]);
  const publicKeyRaw = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
  await putRecord({
    keyId: resolvedKeyId,
    privateKey: pair.privateKey,
    publicKeyRaw,
    createdAt: Date.now(),
  });
  return { keyId: resolvedKeyId, publicKey: publicKeyRaw };
}

/**
 * Load the public key bytes for a delegated grant key.
 *
 * Used during delegated session restore to verify that saved metadata still
 * matches the browser-held key.
 */
async function __pubkyGrantLoadDelegatedPublicKey(keyId) {
  requireBrowserCrypto();
  const existing = await getRecord(keyId);
  if (!existing) throw new Error(`Delegated grant key not found: ${keyId}`);
  return new Uint8Array(existing.publicKeyRaw);
}

/**
 * Sign a grant PoP JWS signing input with a delegated browser key.
 *
 * `signingInput` is the exact ASCII JWS signing input produced by Rust:
 * `base64url(header) + "." + base64url(claims)`. The raw Ed25519 signature
 * bytes are returned to Rust, which finishes compact JWS serialization.
 */
async function __pubkyGrantDelegatedSign(keyId, signingInput) {
  let existing;
  try {
    requireBrowserCrypto();
    existing = await getRecord(keyId);
    if (!existing?.privateKey) throw new Error(`Delegated grant key not found: ${keyId}`);
  } catch (cause) {
    // getRecord wraps IndexedDB failures; retain the underlying diagnostic.
    const detail = cause?.cause ?? cause;
    const error = contextualError(
      `Delegated grant signing key unavailable: ${detail?.message ?? String(detail)}`,
      cause,
    );
    error.code = "SigningKeyUnavailable";
    throw error;
  }
  const data = new TextEncoder().encode(signingInput);
  return new Uint8Array(await crypto.subtle.sign({ name: "Ed25519" }, existing.privateKey, data));
}


/**
 * Start and control a pubkyauth authorization flow.
 *
 * Typical flow:
 * 1) `AuthFlow.start(...)` or `pubky.startCookieAuthFlow(...)`
 * 2) Show `authorizationUrl()` as QR/deeplink to the user’s signing device
 * 3) `awaitApproval()` to receive a ready `Session`
 *
 * @deprecated Use `GrantAuthFlow` instead.
 */
class AuthFlow {
    static __wrap(ptr) {
        const obj = Object.create(AuthFlow.prototype);
        obj.__wbg_ptr = ptr;
        AuthFlowFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthFlowFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authflow_free(ptr, 0);
    }
    /**
     * Return the authorization deep link (URL) to show as QR or open on the signer device.
     *
     * **Security:** This URL contains the `client_secret` in plaintext.
     * Treat it as a short-lived secret and delete it after the flow completes.
     * See `Pubky.startCookieAuthFlow()` docs for storage guidance.
     *
     * @returns {string} A `pubkyauth://…` or `https://…` URL with channel info.
     *
     * @example
     * renderQr(flow.authorizationUrl);
     * @returns {string}
     */
    get authorizationUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.authflow_authorizationUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Block until the user approves on their signer device; returns a `Session`.
     *
     * @returns {Promise<Session>}
     * Resolves when approved; rejects on timeout/cancel/network errors.
     *
     * @throws {PubkyError}
     * - `RequestError` if relay/network fails
     * - `AuthenticationError` if approval is denied/invalid
     * @returns {Promise<Session>}
     */
    awaitApproval() {
        const ret = wasm.authflow_awaitApproval(this.__wbg_ptr);
        return ret;
    }
    /**
     * Block until the user approves on their signer device; returns an `AuthToken`.
     *
     * @returns {Promise<AuthToken>}
     * Resolves when approved; rejects on timeout/cancel/network errors.
     *
     * @throws {PubkyError}
     * - `RequestError` if relay/network fails
     * @returns {Promise<AuthToken>}
     */
    awaitToken() {
        const ret = wasm.authflow_awaitToken(this.__wbg_ptr);
        return ret;
    }
    /**
     * Resume a previously started auth flow from its saved `authorizationUrl` (standalone).
     * Prefer `pubky.resumeCookieAuthFlow()` to reuse a facade client; this creates a default (mainnet) client.
     *
     * Relay messages expire after ~5 minutes; resume is only viable in that window.
     * See `Pubky.resumeCookieAuthFlow()` / `Pubky.startCookieAuthFlow()` for full guidance.
     *
     * **Security:** `authorizationUrl` contains the `client_secret`.
     * Delete it from storage as soon as resume completes or is abandoned.
     *
     * @param {string} authorizationUrl The `pubkyauth://…` URL from a previous flow.
     * @returns {AuthFlow} A flow reconnected to the original relay channel.
     * @throws {PubkyError}
     * - `{ name: "AuthenticationError" }` if the URL is invalid or not a signin/signup link
     *
     * @deprecated Use `GrantAuthFlow.resume(...)` instead.
     * @param {string} authorization_url
     * @returns {AuthFlow}
     */
    static resume(authorization_url) {
        const ptr0 = passStringToWasm0(authorization_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.authflow_resume(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthFlow.__wrap(ret[0]);
    }
    /**
     * Start a flow (standalone).
     * Prefer `pubky.startCookieAuthFlow()` to reuse a facade client.
     *
     * @param {string} capabilities
     * Comma-separated capabilities, e.g. `"/pub/app/:rw,/priv/foo.txt:r"`.
     * Each entry must be `"<scope>:<actions>"`, where:
     * - `scope` starts with `/` (e.g. `/pub/example.com/`)
     * - `actions` is any combo of `r` and/or `w` (order is normalized; `wr` -> `rw`)
     * Empty string is allowed (no scopes).
     *
     * @param {AuthFlowKind} kind
     * The kind of authentication flow to perform.
     * This can either be a sign in or a sign up flow.
     * Examples:
     * - `AuthFlowKind.signin()` - Sign in to an existing account.
     * - `AuthFlowKind.signup(homeserverPublicKey, signupToken)` - Sign up for a new account.
     *
     * @param {string} [relay]
     * Optional HTTP relay base, e.g. `"https://demo.httprelay.io/inbox/"`.
     * Defaults to the default Synonym-hosted relay when omitted.
     *
     * @param {XCallbackParams} [xCallback]
     * Optional return destinations for success, error, and cancellation.
     *
     * @returns {AuthFlow}
     * A running auth flow. Call `authorizationUrl()` to show the deep link,
     * then `awaitApproval()` to receive a `Session`.
     * @throws {PubkyError}
     * - `{ name: "InvalidInput", message: string }` if any capability entry is invalid
     *     or for an invalid relay URL.
     * @example
     * const flow = AuthFlow.start("/pub/my-cool-app/:rw,/pub/pubky.app/:w");
     * renderQRCode(flow.authorizationUrl());
     * const session = await flow.awaitApproval();
     *
     * @deprecated Use `GrantAuthFlow.start(...)` instead.
     * @param {Capabilities} capabilities
     * @param {AuthFlowKind} kind
     * @param {string | null} [relay]
     * @param {XCallbackParams | null} [x_callback]
     * @returns {AuthFlow}
     */
    static start(capabilities, kind, relay, x_callback) {
        const ptr0 = passStringToWasm0(capabilities, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(kind, AuthFlowKind);
        var ptr1 = kind.__destroy_into_raw();
        var ptr2 = isLikeNone(relay) ? 0 : passStringToWasm0(relay, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.authflow_start(ptr0, len0, ptr1, ptr2, len2, isLikeNone(x_callback) ? 0 : addToExternrefTable0(x_callback));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthFlow.__wrap(ret[0]);
    }
    /**
     * Non-blocking single poll step (advanced UIs).
     *
     * @returns {Promise<Session|undefined>} A session if the approval arrived, otherwise `undefined`.
     * @returns {Promise<Session | undefined>}
     */
    tryPollOnce() {
        const ret = wasm.authflow_tryPollOnce(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) AuthFlow.prototype[Symbol.dispose] = AuthFlow.prototype.free;
exports.AuthFlow = AuthFlow;

/**
 * The kind of authentication flow to perform.
 * This can either be a sign in or a sign up flow.
 */
class AuthFlowKind {
    static __wrap(ptr) {
        const obj = Object.create(AuthFlowKind.prototype);
        obj.__wbg_ptr = ptr;
        AuthFlowKindFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthFlowKindFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authflowkind_free(ptr, 0);
    }
    /**
     * Get the intent of the authentication flow.
     * # Returns
     * * `"signin"` - If the authentication flow is a sign in flow.
     * * `"signup"` - If the authentication flow is a sign up flow.
     * @returns {string}
     */
    get intent() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.authflowkind_intent(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a sign in flow.
     * @returns {AuthFlowKind}
     */
    static signin() {
        const ret = wasm.authflowkind_signin();
        return AuthFlowKind.__wrap(ret);
    }
    /**
     * Create a sign up flow.
     * # Arguments
     * * `homeserver_public_key` - The public key of the homeserver to sign up on.
     * * `signup_token` - The signup token to use for the signup flow. This is optional.
     * @param {PublicKey} homeserver_public_key
     * @param {string | null} [signup_token]
     * @returns {AuthFlowKind}
     */
    static signup(homeserver_public_key, signup_token) {
        _assertClass(homeserver_public_key, PublicKey);
        var ptr0 = isLikeNone(signup_token) ? 0 : passStringToWasm0(signup_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.authflowkind_signup(homeserver_public_key.__wbg_ptr, ptr0, len0);
        return AuthFlowKind.__wrap(ret);
    }
}
if (Symbol.dispose) AuthFlowKind.prototype[Symbol.dispose] = AuthFlowKind.prototype.free;
exports.AuthFlowKind = AuthFlowKind;

/**
 * AuthToken: signed, time-bound proof of key ownership.
 *
 * Returned by [`AuthFlow.awaitToken()`] on the 3rd-party app side when doing **authentication-only**
 * flows (no homeserver session). You can inspect who authenticated and which capabilities were
 * requested, or serialize the token and send it to a backend to verify.
 *
 * ### Typical usage
 * ```js
 * // Start an auth-only flow (no capabilities)
 * const flow = pubky.startCookieAuthFlow("", relay);
 *
 * // Wait for the signer to approve; returns an AuthToken
 * const token = await flow.awaitToken();
 *
 * // Identify the user
 * console.log(token.publicKey().toString());
 *
 * // Optionally forward to a server for verification:
 * await fetch("/api/verify", { method: "POST", body: token.toBytes() });
 * ```
 *
 * ### Binary format
 * `AuthToken` serializes to a canonical binary (postcard) form; use [`AuthToken.toBytes()`] to get a
 * `Uint8Array`, and [`AuthToken.verify()`] to parse + verify on the server.
 */
class AuthToken {
    static __wrap(ptr) {
        const obj = Object.create(AuthToken.prototype);
        obj.__wbg_ptr = ptr;
        AuthTokenFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthTokenFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authtoken_free(ptr, 0);
    }
    /**
     * Returns the **capabilities** requested by the flow at the time this token was signed.
     *
     * Most auth-only flows pass an empty string to `startCookieAuthFlow("", relay)`, so this will
     * commonly be an empty array.
     *
     * Returns: `string[]`, where each item is the canonical entry `"<scope>:<actions>"`.
     *
     * Example entry: `"/pub/my-cool-app/:rw"`
     * @returns {string[]}
     */
    get capabilities() {
        const ret = wasm.authtoken_capabilities(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Deserialize an `AuthToken` **without** verification.
     *
     * Most apps should call [`AuthToken.verify()`]. This is provided for tooling or diagnostics
     * where you want to inspect the structure first.
     *
     * Throws if the bytes cannot be parsed as a valid serialized token.
     * @param {Uint8Array} bytes
     * @returns {AuthToken}
     */
    static fromBytes(bytes) {
        const ret = wasm.authtoken_fromBytes(bytes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthToken.__wrap(ret[0]);
    }
    /**
     * Returns the **public key** that authenticated with this token.
     *
     * Use `.toString()` on the returned `PublicKey` to get the `pubky<z32>` identifier.
     * Call `.z32()` when you specifically need the raw z-base32 value (e.g. hostnames).
     *
     * @example
     * const who = token.publicKey.toString();
     * @returns {PublicKey}
     */
    get publicKey() {
        const ret = wasm.authtoken_publicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Serialize the token to a `Uint8Array` in its **canonical** (postcard) binary format.
     *
     * Use this to send the token to a backend for verification.
     *
     * ```js
     * const bytes = token.toBytes();
     * await fetch("/api/verify", { method: "POST", body: bytes });
     * ```
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.authtoken_toBytes(this.__wbg_ptr);
        return ret;
    }
    /**
     * Parse and verify an `AuthToken` from its canonical bytes.
     *
     * - Verifies version, timestamp freshness window, and signature.
     * - Throws on invalid/expired/unknown version.
     *
     * Use this on your server after receiving `Uint8Array` from the client.
     *
     * ```js
     * import { AuthToken } from "@synonymdev/pubky";
     *
     * export async function POST(req) {
     *   const bytes = new Uint8Array(await req.arrayBuffer());
     *   const token = AuthToken.verify(bytes); // throws on failure
     *   return new Response(token.publicKey().toString(), { status: 200 });
     * }
     * ```
     * @param {Uint8Array} bytes
     * @returns {AuthToken}
     */
    static verify(bytes) {
        const ret = wasm.authtoken_verify(bytes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthToken.__wrap(ret[0]);
    }
}
if (Symbol.dispose) AuthToken.prototype[Symbol.dispose] = AuthToken.prototype.free;
exports.AuthToken = AuthToken;

/**
 * Browser-backed durable store for completed grant sessions.
 */
class BrowserSessionStore {
    static __wrap(ptr) {
        const obj = Object.create(BrowserSessionStore.prototype);
        obj.__wbg_ptr = ptr;
        BrowserSessionStoreFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BrowserSessionStoreFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_browsersessionstore_free(ptr, 0);
    }
    /**
     * Clear all browser auth persistence owned by this SDK origin.
     *
     * This removes all stored session records and all browser-held delegated
     * grant keys, including keys for pending delegated grant flows. Saved
     * delegated flow state becomes unrestorable. This does not revoke remote
     * grants. Browser-managed handles stop working when their saved record is removed.
     * @returns {Promise<void>}
     */
    clearAll() {
        const ret = wasm.browsersessionstore_clearAll(this.__wbg_ptr);
        return ret;
    }
    /**
     * Clear all local stored session records for this origin.
     *
     * Delegated keys referenced by those stored session records are removed.
     * Delegated keys that only belong to pending grant flows are preserved.
     * @returns {Promise<void>}
     */
    clear() {
        const ret = wasm.browsersessionstore_clear(this.__wbg_ptr);
        return ret;
    }
    /**
     * Whether IndexedDB and Web Locks are available.
     * @returns {Promise<boolean>}
     */
    isAvailable() {
        const ret = wasm.browsersessionstore_isAvailable(this.__wbg_ptr);
        return ret;
    }
    /**
     * List all locally stored sessions for this origin.
     * @returns {Promise<StoredSessionInfo[]>}
     */
    list() {
        const ret = wasm.browsersessionstore_list(this.__wbg_ptr);
        return ret;
    }
    /**
     * Remove local stored session metadata and any SDK-owned delegated key for that record.
     * @param {string} id
     * @returns {Promise<void>}
     */
    remove(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.browsersessionstore_remove(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Recover a stored session's encryption keys without network access.
     * Verifies the signed approval, exact grant binding, and requested session
     * identity. Works after grant expiry/revocation and without the delegated
     * WebCrypto signing key.
     * Restore material is stored as plaintext in IndexedDB.
     * Bare-grant records return undefined; signed approvals without `e` scopes
     * return an empty bundle. Creates no session.
     * @param {string} id
     * @returns {Promise<EncryptionKeys | undefined>}
     */
    restoreEncryptionKeys(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.browsersessionstore_restoreEncryptionKeys(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Restore a specific stored session by id.
     *
     * Shares one bearer with other tabs on this origin. Requires IndexedDB and
     * Web Locks in a secure browser context.
     * @param {string} id
     * @returns {Promise<Session>}
     */
    restore(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.browsersessionstore_restore(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Persist a completed grant session and its optional signed approval.
     * Confidential restore material is stored as plaintext in IndexedDB.
     * Delegated signing keys remain non-extractable WebCrypto keys.
     * Records are identified by user and grant ID. Reauthorizing the same
     * client creates a separate record; use the returned ID to restore it.
     * @param {Session} session
     * @returns {Promise<StoredSessionInfo>}
     */
    save(session) {
        _assertClass(session, Session);
        const ret = wasm.browsersessionstore_save(this.__wbg_ptr, session.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) BrowserSessionStore.prototype[Symbol.dispose] = BrowserSessionStore.prototype.free;
exports.BrowserSessionStore = BrowserSessionStore;

/**
 * Low-level HTTP bridge used by the Pubky facade and actors.
 *
 * - Supports `http(s)://` URLs targeting Pubky or ICANN hosts.
 * - In browsers/undici, passes `credentials: "include"` to send cookies.
 */
class Client {
    static __wrap(ptr) {
        const obj = Object.create(Client.prototype);
        obj.__wbg_ptr = ptr;
        ClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_client_free(ptr, 0);
    }
    /**
     * Perform a raw fetch. Works with `http(s)://` URLs.
     *
     * @param {string} url
     * @param {RequestInit} init Standard fetch options; `credentials: "include"` recommended for session I/O.
     * @returns {Promise<Response>}
     *
     * @example
     * const client = pubky.client;
     * const res = await client.fetch(`https://_pubky.${user}/storage/${user}/pub/app/file.txt`, { method: "PUT", body: "hi", credentials: "include" });
     * @param {string} url
     * @param {RequestInit | null} [init]
     * @returns {Promise<Response>}
     */
    fetch(url, init) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.client_fetch(this.__wbg_ptr, ptr0, len0, isLikeNone(init) ? 0 : addToExternrefTable0(init));
        return ret;
    }
    /**
     * Create a Pubky HTTP client.
     *
     * @param {PubkyClientConfig} [config]
     * Optional error-body limit and PKARR overrides:
     * `{ maxErrorBodyBytes?: number, pkarr?: { relays?: string[], requestTimeout?: number } }`.
     *
     * @returns {Client}
     * A configured low-level client. Prefer `new Pubky().client` unless you
     * need custom relays, timeouts or error-body limits.
     *
     * @throws {InvalidInput}
     * If a relay URL is invalid or the error-body limit is not an integer in 0..=4294967295.
     *
     * @example
     * const client = new Client({
     *   maxErrorBodyBytes: 1024,
     *   pkarr: { relays: ["https://relay1/","https://relay2/"], requestTimeout: 8000 }
     * });
     * const pubky = Pubky.withClient(client);
     * @param {PubkyClientConfig | null} [config_opt]
     */
    constructor(config_opt) {
        const ret = wasm.client_new(isLikeNone(config_opt) ? 0 : addToExternrefTable0(config_opt));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        ClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Create a client wired for **local testnet**.
     *
     * Configures PKARR relays for the testnet and remembers the hostname for WASM `_pubky` mapping.
     *
     * @param {string} [host="localhost"]
     * Testnet hostname or IP.
     *
     * @returns {Client}
     * A client ready to talk to your local testnet.
     *
     * @example
     * const client = Client.testnet();           // localhost
     * const pubky  = Pubky.withClient(client);
     *
     * @example
     * const client = Client.testnet("docker0");  // custom host
     * @param {string | null} [host]
     * @returns {Client}
     */
    static testnet(host) {
        var ptr0 = isLikeNone(host) ? 0 : passStringToWasm0(host, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.client_testnet(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Client.__wrap(ret[0]);
    }
}
if (Symbol.dispose) Client.prototype[Symbol.dispose] = Client.prototype.free;
exports.Client = Client;

/**
 * Cookie-only view over a cookie-backed `Session`.
 *
 * New applications should use `session.grant` and `GrantSession`.
 *
 * @deprecated Use `GrantSession` instead.
 */
class CookieSession {
    static __wrap(ptr) {
        const obj = Object.create(CookieSession.prototype);
        obj.__wbg_ptr = ptr;
        CookieSessionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CookieSessionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cookiesession_free(ptr, 0);
    }
    /**
     * Export the cookie secret needed to restore this cookie session.
     *
     * This is available when the SDK captured the cookie secret, such as in
     * Node.js. Browser sessions cannot read HTTP-only Set-Cookie values.
     *
     * @returns {Promise<string>}
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     * @returns {Promise<string>}
     */
    exportSecret() {
        const ret = wasm.cookiesession_exportSecret(this.__wbg_ptr);
        return ret;
    }
    /**
     * Export session metadata for legacy cookie restore.
     *
     * The returned string contains no secrets; the browser cookie jar must
     * still hold the HTTP-only cookie.
     *
     * @returns {string}
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     * @returns {string}
     */
    export() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.cookiesession_export(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
}
if (Symbol.dispose) CookieSession.prototype[Symbol.dispose] = CookieSession.prototype.free;
exports.CookieSession = CookieSession;

/**
 * Parsed direct signup deeplink.
 */
class DirectSignupDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(DirectSignupDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        DirectSignupDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DirectSignupDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_directsignupdeeplink_free(ptr, 0);
    }
    /**
     * Homeserver public key requested for account creation.
     * @returns {PublicKey}
     */
    get homeserver() {
        const ret = wasm.directsignupdeeplink_homeserver(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Parse a direct signup deeplink URL.
     * @param {string} url
     * @returns {DirectSignupDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.directsignupdeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return DirectSignupDeepLink.__wrap(ret[0]);
    }
    /**
     * Optional signup token included in the request.
     * @returns {string | undefined}
     */
    get signupToken() {
        const ret = wasm.directsignupdeeplink_signupToken(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.directsignupdeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.directsignupdeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) DirectSignupDeepLink.prototype[Symbol.dispose] = DirectSignupDeepLink.prototype.free;
exports.DirectSignupDeepLink = DirectSignupDeepLink;

/**
 * Verified scoped encryption keys obtained from a session or offline recovery.
 * This object owns its secrets independently of the session and grants no storage
 * access. Call `free()` when finished; secret bytes are zeroized on free/drop.
 */
class EncryptionKeys {
    static __wrap(ptr) {
        const obj = Object.create(EncryptionKeys.prototype);
        obj.__wbg_ptr = ptr;
        EncryptionKeysFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EncryptionKeysFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_encryptionkeys_free(ptr, 0);
    }
    /**
     * Derive a non-extractable AES-GCM-256 key for WebCrypto encryption/decryption.
     * Rejects directories and files outside approved scopes. Requires WebCrypto.
     * Temporary JS key bytes are cleared after import, including on failure.
     * @param {string} path
     * @returns {Promise<CryptoKey>}
     */
    deriveCryptoKeyForPath(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.encryptionkeys_deriveCryptoKeyForPath(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Derive a 32-byte content key for a canonical decoded file path.
     * Rejects directories and files outside the approved scopes. The caller
     * owns the JS byte copy and should clear it after use.
     * @param {string} path
     * @returns {Uint8Array}
     */
    deriveForPath(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.encryptionkeys_deriveForPath(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Recover authenticated identity and keys from an exportLocalSecret() token offline.
     * Verifies the signed approval and grant binding even if the grant expired
     * or was revoked. Bare-grant tokens return undefined; signed approvals
     * without `e` scopes return a result with an empty key bundle.
     * Check publicKey (z-base-32) against the expected account and grantId
     * against the expected grant before using keys. Call keys.free() when done.
     * @param {string} token
     * @returns {RecoveredEncryptionKeys | undefined}
     */
    static fromLocalSecret(token) {
        const ptr0 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.encryptionkeys_fromLocalSecret(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Approved scopes; directory scopes cover descendant files.
     * @returns {string[]}
     */
    get scopes() {
        const ret = wasm.encryptionkeys_scopes(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) EncryptionKeys.prototype[Symbol.dispose] = EncryptionKeys.prototype.free;
exports.EncryptionKeys = EncryptionKeys;

/**
 * A single event from the event stream.
 *
 * @example
 * ```typescript
 * for await (const event of stream) {
 *   console.log(event.eventType);  // "PUT" or "DEL"
 *   console.log(event.cursor);     // cursor string for pagination
 *
 *   if (event.eventType === "PUT") {
 *     console.log("Hash:", event.contentHash);
 *   }
 *
 *   // Access resource details
 *   console.log(event.resource.owner.z32()); // User's public key
 *   console.log(event.resource.path);        // "/pub/example.txt"
 *   console.log(event.resource.toPubkyUrl()); // Full pubky:// URL
 * }
 * ```
 */
class Event {
    static __wrap(ptr) {
        const obj = Object.create(Event.prototype);
        obj.__wbg_ptr = ptr;
        EventFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EventFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_event_free(ptr, 0);
    }
    /**
     * Get the content hash (only for PUT events).
     * Returns the blake3 hash in base64 format, or undefined for DELETE events.
     * @returns {string | undefined}
     */
    get contentHash() {
        const ret = wasm.event_contentHash(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Get the cursor for pagination.
     * @returns {string}
     */
    get cursor() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.event_cursor(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Get the event type ("PUT" or "DEL").
     * @returns {string}
     */
    get eventType() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.event_eventType(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Get the resource that was created, updated, or deleted.
     * @returns {PubkyResource}
     */
    get resource() {
        const ret = wasm.event_resource(this.__wbg_ptr);
        return PubkyResource.__wrap(ret);
    }
}
if (Symbol.dispose) Event.prototype[Symbol.dispose] = Event.prototype.free;
exports.Event = Event;

/**
 * Builder for creating an event stream subscription.
 *
 * Construct via `Pubky.eventStreamForUser()` or `Pubky.eventStreamFor()`.
 * Configuration methods consume this builder unless documented otherwise.
 *
 * @example
 * ```typescript
 * const stream = await pubky.eventStreamForUser(userPubkey, null)
 *   .live()
 *   .limit(100)
 *   .path("/pub/")
 *   .subscribe();
 *
 * for await (const event of stream) {
 *   console.log(event.eventType, event.resource.path);
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Private events: attach a session and request a `/priv/...` path.
 * const stream = await pubky.eventStreamForUser(userPubkey, null)
 *   .session(session)
 *   .path("/priv/app/")
 *   .subscribe();
 * ```
 */
class EventStreamBuilder {
    static __wrap(ptr) {
        const obj = Object.create(EventStreamBuilder.prototype);
        obj.__wbg_ptr = ptr;
        EventStreamBuilderFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EventStreamBuilderFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_eventstreambuilder_free(ptr, 0);
    }
    /**
     * Add multiple users to the event stream subscription at once.
     *
     * Each user can have an independent cursor position. If a user already exists,
     * their cursor value is overwritten.
     * Updates this builder and returns a copy for chaining. Rejected input
     * leaves this builder unchanged.
     *
     * @param {Array<[string, string | null]>} users - Array of [z32PublicKey, cursor] tuples
     * @returns {EventStreamBuilder} - Builder for chaining
     * @throws {Error} - If total users would exceed 50 or if any cursor/pubkey is invalid
     *
     * @example
     * ```typescript
     * const users: [string, string | null][] = [
     *   [user1.z32(), null],
     *   [user2.z32(), "100"],
     * ];
     * const stream = await pubky.eventStreamFor(homeserver)
     *   .addUsers(users)
     *   .live()
     *   .subscribe();
     * ```
     * @param {Array<any>} users
     * @returns {EventStreamBuilder}
     */
    addUsers(users) {
        const ret = wasm.eventstreambuilder_addUsers(this.__wbg_ptr, users);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return EventStreamBuilder.__wrap(ret[0]);
    }
    /**
     * Set maximum number of events to receive before closing the connection.
     *
     * If omitted:
     * - With `live=false`: sends all historical events, then closes
     * - With `live=true`: sends all historical events, then enters live mode (infinite stream)
     *
     * @param {number} limit - Maximum number of events (1-65535)
     * @returns {EventStreamBuilder} - Builder for chaining
     * @param {number} limit
     * @returns {EventStreamBuilder}
     */
    limit(limit) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.eventstreambuilder_limit(ptr, limit);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Enable live streaming mode.
     *
     * When called, the stream will:
     * 1. First deliver all historical events (oldest first)
     * 2. Then remain open to stream new events as they occur in real-time
     *
     * Without this flag (default): Stream only delivers historical events and closes.
     *
     * **Note**: Cannot be combined with `reverse()`.
     *
     * ## Cleanup
     * To stop a live stream, use the reader's `cancel()` method:
     * ```typescript
     * const stream = await pubky.eventStreamForUser(user, null).live().subscribe();
     * const reader = stream.getReader();
     *
     * while (true) {
     *   const { done, value } = await reader.read();
     *   if (shouldStop) {
     *     await reader.cancel(); // Closes the connection
     *     break;
     *   }
     * }
     * ```
     *
     * @returns {EventStreamBuilder} - Builder for chaining
     * @returns {EventStreamBuilder}
     */
    live() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.eventstreambuilder_live(ptr);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Set a client-side byte limit for SSE payloads. Unbounded by default.
     * Limits accumulated data (including newlines joining data fields), each
     * event name, and each ID separately in historical and live streams.
     * Comments, unknown fields and framing bytes are excluded.
     * There is no total block or stream byte limit.
     * Overflow cancels the response and errors the ReadableStream.
     * Updates this builder and returns a copy for chaining. Rejected input
     * leaves this builder unchanged.
     *
     * @param {number} limit - Integer in 1..=4294967295.
     * @throws {InvalidInput} If the limit is not a positive 32-bit integer.
     * @param {number} limit
     * @returns {EventStreamBuilder}
     */
    maxEventBytes(limit) {
        const ret = wasm.eventstreambuilder_maxEventBytes(this.__wbg_ptr, limit);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return EventStreamBuilder.__wrap(ret[0]);
    }
    /**
     * Filter events by path. Call once per path to receive the
     * union of several scopes (e.g. `/pub/` plus a private `/priv/app/`).
     *
     * Format: a path WITHOUT the `pubky://` scheme or user pubkey. A trailing
     * slash matches a directory and all its descendants (`/pub/files/`); no
     * trailing slash matches an exact file (`/pub/notes.txt`).
     *
     * Private (`/priv/...`) paths require a session attached via `session()`;
     * without one the homeserver rejects the subscription with 401.
     *
     * @param {string} path - Path filter (repeatable)
     * @returns {EventStreamBuilder} - Builder for chaining
     * @param {string} path
     * @returns {EventStreamBuilder}
     */
    path(path) {
        const ptr = this.__destroy_into_raw();
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.eventstreambuilder_path(ptr, ptr0, len0);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Return events in reverse chronological order (newest first).
     *
     * When called, events are delivered from newest to oldest, then the stream closes.
     *
     * Without this flag (default): Events are delivered oldest first.
     *
     * **Note**: Cannot be combined with `live()`.
     *
     * @returns {EventStreamBuilder} - Builder for chaining
     * @returns {EventStreamBuilder}
     */
    reverse() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.eventstreambuilder_reverse(ptr);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Authenticate the subscription with a user `Session`.
     *
     * Required to receive private (`/priv/...`) events: the session credential
     * (grant or cookie) is attached so the homeserver can authorize each private
     * `path()` against the session's read capabilities. Public subscriptions
     * don't need this.
     *
     *
     * @param {Session} session - The authenticated session
     * @returns {EventStreamBuilder} - Builder for chaining
     * @param {Session} session
     * @returns {EventStreamBuilder}
     */
    session(session) {
        const ptr = this.__destroy_into_raw();
        _assertClass(session, Session);
        const ret = wasm.eventstreambuilder_session(ptr, session.__wbg_ptr);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Subscribe to the event stream.
     *
     * This performs the following steps:
     * 1. Resolves the user's homeserver via DHT/PKDNS
     * 2. Constructs the `/events-stream` URL with query parameters
     * 3. Makes the HTTP request
     * 4. Returns a Web ReadableStream of parsed events
     *
     * @returns {Promise<ReadableStream>} - A Web ReadableStream that yields Event objects
     *
     * @throws {PubkyError}
     * - `{ name: "RequestError" }` if the homeserver cannot be resolved
     * - `{ name: "ValidationError" }` if `live=true` and `reverse=true` (invalid combination)
     * - Propagates HTTP request errors
     *
     * @example
     * ```typescript
     * const stream = await builder.subscribe();
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     * @returns {Promise<ReadableStream>}
     */
    subscribe() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.eventstreambuilder_subscribe(ptr);
        return ret;
    }
}
if (Symbol.dispose) EventStreamBuilder.prototype[Symbol.dispose] = EventStreamBuilder.prototype.free;
exports.EventStreamBuilder = EventStreamBuilder;

/**
 * Start and control a grant-backed pubkyauth authorization flow.
 *
 * Typical flow:
 * 1) `GrantAuthFlow.start(...)` or `pubky.startGrantAuthFlow(...)`
 * 2) Show `authorizationUrl()` as QR/deeplink to the user's signing device
 * 3) `awaitApproval()` to receive a grant-backed, self-refreshing `Session`
 */
class GrantAuthFlow {
    static __wrap(ptr) {
        const obj = Object.create(GrantAuthFlow.prototype);
        obj.__wbg_ptr = ptr;
        GrantAuthFlowFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GrantAuthFlowFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_grantauthflow_free(ptr, 0);
    }
    /**
     * Return the authorization deep link (URL) to show as QR or open on the signer device.
     * @returns {string}
     */
    get authorizationUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantauthflow_authorizationUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Block until the user approves on their signer device; returns a grant-backed `Session`.
     * @returns {Promise<Session>}
     */
    awaitApproval() {
        const ret = wasm.grantauthflow_awaitApproval(this.__wbg_ptr);
        return ret;
    }
    /**
     * Whether delegated grant auth is available in the current JS runtime.
     *
     * This checks for a secure browser context with WebCrypto `crypto.subtle`
     * and IndexedDB. It is a coarse synchronous feature-detection helper only;
     * some runtimes expose those primitives without Ed25519 support.
     * @returns {boolean}
     */
    static get isDelegationAvailable() {
        const ret = wasm.grantauthflow_isDelegationAvailable();
        return ret !== 0;
    }
    /**
     * Resume a previously saved pending delegated grant auth flow.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. The saved `keyId` must still
     * exist in IndexedDB for the same origin. Unsupported runtimes reject with
     * `ClientStateError`.
     * @param {string} saved_state
     * @returns {Promise<GrantAuthFlow>}
     */
    static resumeDelegated(saved_state) {
        const ptr0 = passStringToWasm0(saved_state, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.grantauthflow_resumeDelegated(ptr0, len0);
        return ret;
    }
    /**
     * Resume a previously saved pending grant auth flow (standalone).
     * Prefer `pubky.resumeGrantAuthFlow()` to reuse a facade client.
     *
     * **Security:** `savedState` contains the relay secret and PoP client private key.
     * Store it only temporarily and delete it once the flow completes or is abandoned.
     *
     * @param {string} savedState A string produced by `grantFlow.saveLocal()`.
     * @returns {GrantAuthFlow} A flow reconnected to the original relay channel.
     * @param {string} saved_state
     * @returns {GrantAuthFlow}
     */
    static resume(saved_state) {
        const ptr0 = passStringToWasm0(saved_state, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.grantauthflow_resume(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GrantAuthFlow.__wrap(ret[0]);
    }
    /**
     * Save sensitive state required to resume this delegated pending grant flow.
     *
     * This does not export the delegated private key, but it includes the relay
     * secret in the authorization URL. Store it only temporarily and delete it
     * once the flow completes or is abandoned.
     * @returns {string}
     */
    saveDelegated() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.grantauthflow_saveDelegated(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Save sensitive state required to resume this pending local grant flow.
     *
     * @returns {string} Opaque state for `GrantAuthFlow.resume()` or
     * `pubky.resumeGrantAuthFlow()`.
     * @returns {string}
     */
    saveLocal() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.grantauthflow_saveLocal(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Start a browser delegated grant-backed flow.
     *
     * The SDK creates a fresh non-extractable WebCrypto Ed25519 key in
     * IndexedDB and uses that key for grant Proof-of-Possession signing.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. Unsupported runtimes reject
     * with `ClientStateError`.
     * @param {Capabilities} capabilities
     * @param {AuthFlowKind} kind
     * @param {GrantAuthFlowOptions} options
     * @returns {Promise<GrantAuthFlow>}
     */
    static startDelegated(capabilities, kind, options) {
        const ptr0 = passStringToWasm0(capabilities, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(kind, AuthFlowKind);
        var ptr1 = kind.__destroy_into_raw();
        const ret = wasm.grantauthflow_startDelegated(ptr0, len0, ptr1, options);
        return ret;
    }
    /**
     * Start a grant-backed flow with a new DHT client.
     * Prefer `pubky.startGrantAuthFlow()` to reuse a facade DHT client.
     *
     * @param {string} capabilities
     * Comma-separated capabilities, e.g. `"/pub/app/:rw,/priv/foo.txt:r"`.
     * Empty string is allowed (no scopes).
     *
     * @param {AuthFlowKind} kind
     * The kind of authentication flow to perform.
     *
     * @param {GrantAuthFlowOptions} options
     * Options for the grant flow: `{ clientId, relay?, xCallback? }`.
     *
     * @returns {GrantAuthFlow}
     * A running grant auth flow. Call `authorizationUrl()` to show the deep link,
     * then `awaitApproval()` to receive a grant-backed `Session`.
     * @param {Capabilities} capabilities
     * @param {AuthFlowKind} kind
     * @param {GrantAuthFlowOptions} options
     * @returns {GrantAuthFlow}
     */
    static start(capabilities, kind, options) {
        const ptr0 = passStringToWasm0(capabilities, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(kind, AuthFlowKind);
        var ptr1 = kind.__destroy_into_raw();
        const ret = wasm.grantauthflow_start(ptr0, len0, ptr1, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GrantAuthFlow.__wrap(ret[0]);
    }
    /**
     * Non-blocking single poll step (advanced UIs).
     *
     * @returns {Promise<Session|undefined>} A session if the approval arrived, otherwise `undefined`.
     * @returns {Promise<Session | undefined>}
     */
    tryPollOnce() {
        const ret = wasm.grantauthflow_tryPollOnce(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) GrantAuthFlow.prototype[Symbol.dispose] = GrantAuthFlow.prototype.free;
exports.GrantAuthFlow = GrantAuthFlow;

/**
 * Summary of an active grant returned by `GrantManager.list()`.
 */
class GrantInfo {
    static __wrap(ptr) {
        const obj = Object.create(GrantInfo.prototype);
        obj.__wbg_ptr = ptr;
        GrantInfoFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GrantInfoFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_grantinfo_free(ptr, 0);
    }
    /**
     * Comma-separated capabilities authorized by the grant.
     * @returns {string}
     */
    get capabilities() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantinfo_capabilities(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Application identifier.
     * @returns {string}
     */
    get clientId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantinfo_clientId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Expiry timestamp, in Unix seconds.
     * @returns {number}
     */
    get expiresAt() {
        const ret = wasm.grantinfo_expiresAt(this.__wbg_ptr);
        return ret;
    }
    /**
     * Grant identifier used for revocation.
     * @returns {string}
     */
    get grantId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantinfo_grantId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Issued-at timestamp, in Unix seconds.
     * @returns {number}
     */
    get issuedAt() {
        const ret = wasm.grantinfo_issuedAt(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) GrantInfo.prototype[Symbol.dispose] = GrantInfo.prototype.free;
exports.GrantInfo = GrantInfo;

/**
 * Account-level grant management for a signed-in user.
 */
class GrantManager {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GrantManagerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_grantmanager_free(ptr, 0);
    }
    /**
     * List all active grants for this user.
     *
     * Requires a root-capability session. Non-root sessions surface the
     * homeserver `403` as the standard request error.
     *
     * @returns {Promise<GrantInfo[]>}
     * @returns {Promise<GrantInfo[]>}
     */
    list() {
        const ret = wasm.grantmanager_list(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a grant manager authenticated by a session.
     *
     * @param {Session} session
     * @returns {GrantManager}
     * @param {Session} session
     */
    constructor(session) {
        _assertClass(session, Session);
        const ret = wasm.grantmanager_new(session.__wbg_ptr);
        this.__wbg_ptr = ret;
        GrantManagerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Revoke a specific grant by id.
     *
     * Requires a root-capability session. Malformed ids throw
     * `InvalidInput`.
     *
     * @param {string} grantId
     * @returns {Promise<void>}
     * @param {string} grant_id
     * @returns {Promise<void>}
     */
    revoke(grant_id) {
        const ptr0 = passStringToWasm0(grant_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.grantmanager_revoke(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) GrantManager.prototype[Symbol.dispose] = GrantManager.prototype.free;
exports.GrantManager = GrantManager;

/**
 * Grant-only view over a grant-backed `Session`.
 *
 * Cookie-backed sessions do not expose this view; use `session.grant` and
 * check for `undefined` before calling grant-session methods.
 */
class GrantSession {
    static __wrap(ptr) {
        const obj = Object.create(GrantSession.prototype);
        obj.__wbg_ptr = ptr;
        GrantSessionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GrantSessionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_grantsession_free(ptr, 0);
    }
    /**
     * Sign JSON data and return both the custom proof and its root-signed grant.
     * Data follows `JSON.stringify` semantics, e.g. `undefined` properties are omitted.
     * Each proof carries its signing time (`iat`) and a random `nonce`.
     * Makes no network requests. Your applications handle freshness and replay protection.
     * @param {JsonValue} data
     * @returns {Promise<CustomPop>}
     */
    createCustomPop(data) {
        const ret = wasm.grantsession_createCustomPop(this.__wbg_ptr, data);
        return ret;
    }
    /**
     * Return scoped keys with the same derivation API as offline recovered keys.
     * Bare grants return `undefined`; signed approvals without `e` scopes
     * return an object with empty scopes.
     * Each access creates an owned copy. Keep it for repeated use and call
     * `free()` when finished. It remains usable after this view or its session
     * is freed, signed out, or revoked; freeing it does not affect the session.
     * @returns {EncryptionKeys | undefined}
     */
    get encryptionKeys() {
        const ret = wasm.grantsession_encryptionKeys(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : EncryptionKeys.__wrap(ret[0]);
    }
    /**
     * Export the portable local secret material needed to restore this grant session.
     *
     * Treat the returned string as bearer-equivalent secret material until the
     * grant expires or is revoked. Included scoped keys remain sensitive after
     * expiry or revocation.
     *
     * @returns {Promise<string>}
     * @returns {Promise<string>}
     */
    exportLocalSecret() {
        const ret = wasm.grantsession_exportLocalSecret(this.__wbg_ptr);
        return ret;
    }
    /**
     * Current grant id (`jti`) backing this session.
     *
     * @returns {Promise<string>}
     * @returns {Promise<string>}
     */
    grantId() {
        const ret = wasm.grantsession_grantId(this.__wbg_ptr);
        return ret;
    }
    /**
     * Full grant session metadata.
     *
     * @returns {Promise<GrantSessionInfo>}
     * @returns {Promise<GrantSessionInfo>}
     */
    sessionInfo() {
        const ret = wasm.grantsession_sessionInfo(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) GrantSession.prototype[Symbol.dispose] = GrantSession.prototype.free;
exports.GrantSession = GrantSession;

/**
 * Grant-specific session metadata returned by `grant.sessionInfo()`.
 */
class GrantSessionInfo {
    static __wrap(ptr) {
        const obj = Object.create(GrantSessionInfo.prototype);
        obj.__wbg_ptr = ptr;
        GrantSessionInfoFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GrantSessionInfoFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_grantsessioninfo_free(ptr, 0);
    }
    /**
     * Authorized capabilities for this session.
     * @returns {string[]}
     */
    get capabilities() {
        const ret = wasm.grantsessioninfo_capabilities(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Application identifier.
     * @returns {string}
     */
    get clientId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantsessioninfo_clientId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Session creation timestamp, in Unix seconds.
     * @returns {number}
     */
    get createdAt() {
        const ret = wasm.grantsessioninfo_createdAt(this.__wbg_ptr);
        return ret;
    }
    /**
     * Underlying grant expiry timestamp, in Unix seconds.
     * @returns {number}
     */
    get grantExpiresAt() {
        const ret = wasm.grantsessioninfo_grantExpiresAt(this.__wbg_ptr);
        return ret;
    }
    /**
     * Grant id this session was minted from.
     * @returns {string}
     */
    get grantId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grantsessioninfo_grantId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Homeserver that issued this session.
     * @returns {PublicKey}
     */
    get homeserver() {
        const ret = wasm.grantsessioninfo_homeserver(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * User public key for this session.
     * @returns {PublicKey}
     */
    get publicKey() {
        const ret = wasm.grantsessioninfo_publicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Bearer token expiry timestamp, in Unix seconds.
     * @returns {number}
     */
    get tokenExpiresAt() {
        const ret = wasm.grantsessioninfo_tokenExpiresAt(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) GrantSessionInfo.prototype[Symbol.dispose] = GrantSessionInfo.prototype.free;
exports.GrantSessionInfo = GrantSessionInfo;

class IntoUnderlyingByteSource {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingByteSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingbytesource_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get autoAllocateChunkSize() {
        const ret = wasm.intounderlyingbytesource_autoAllocateChunkSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingbytesource_cancel(ptr);
    }
    /**
     * @param {ReadableByteStreamController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingbytesource_pull(this.__wbg_ptr, controller);
        return ret;
    }
    /**
     * @param {ReadableByteStreamController} controller
     */
    start(controller) {
        wasm.intounderlyingbytesource_start(this.__wbg_ptr, controller);
    }
    /**
     * @returns {ReadableStreamType}
     */
    get type() {
        const ret = wasm.intounderlyingbytesource_type(this.__wbg_ptr);
        return __wbindgen_enum_ReadableStreamType[ret];
    }
}
if (Symbol.dispose) IntoUnderlyingByteSource.prototype[Symbol.dispose] = IntoUnderlyingByteSource.prototype.free;
exports.IntoUnderlyingByteSource = IntoUnderlyingByteSource;

class IntoUnderlyingByteSource2 {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingByteSource2Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingbytesource2_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get autoAllocateChunkSize() {
        const ret = wasm.intounderlyingbytesource2_autoAllocateChunkSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingbytesource2_cancel(ptr);
    }
    /**
     * @param {ReadableByteStreamController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingbytesource2_pull(this.__wbg_ptr, controller);
        return ret;
    }
    /**
     * @param {ReadableByteStreamController} controller
     */
    start(controller) {
        wasm.intounderlyingbytesource2_start(this.__wbg_ptr, controller);
    }
    /**
     * @returns {ReadableStreamType}
     */
    get type() {
        const ret = wasm.intounderlyingbytesource2_type(this.__wbg_ptr);
        return __wbindgen_enum_ReadableStreamType[ret];
    }
}
if (Symbol.dispose) IntoUnderlyingByteSource2.prototype[Symbol.dispose] = IntoUnderlyingByteSource2.prototype.free;

class IntoUnderlyingSink {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsink_free(ptr, 0);
    }
    /**
     * @param {any} reason
     * @returns {Promise<any>}
     */
    abort(reason) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_abort(ptr, reason);
        return ret;
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_close(ptr);
        return ret;
    }
    /**
     * @param {any} chunk
     * @returns {Promise<any>}
     */
    write(chunk) {
        const ret = wasm.intounderlyingsink_write(this.__wbg_ptr, chunk);
        return ret;
    }
}
if (Symbol.dispose) IntoUnderlyingSink.prototype[Symbol.dispose] = IntoUnderlyingSink.prototype.free;
exports.IntoUnderlyingSink = IntoUnderlyingSink;

class IntoUnderlyingSink2 {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSink2Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsink2_free(ptr, 0);
    }
    /**
     * @param {any} reason
     * @returns {Promise<any>}
     */
    abort(reason) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink2_abort(ptr, reason);
        return ret;
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink2_close(ptr);
        return ret;
    }
    /**
     * @param {any} chunk
     * @returns {Promise<any>}
     */
    write(chunk) {
        const ret = wasm.intounderlyingsink2_write(this.__wbg_ptr, chunk);
        return ret;
    }
}
if (Symbol.dispose) IntoUnderlyingSink2.prototype[Symbol.dispose] = IntoUnderlyingSink2.prototype.free;

class IntoUnderlyingSource {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsource_free(ptr, 0);
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingsource_cancel(ptr);
    }
    /**
     * @param {ReadableStreamDefaultController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingsource_pull(this.__wbg_ptr, controller);
        return ret;
    }
}
if (Symbol.dispose) IntoUnderlyingSource.prototype[Symbol.dispose] = IntoUnderlyingSource.prototype.free;
exports.IntoUnderlyingSource = IntoUnderlyingSource;

class IntoUnderlyingSource2 {
    static __wrap(ptr) {
        const obj = Object.create(IntoUnderlyingSource2.prototype);
        obj.__wbg_ptr = ptr;
        IntoUnderlyingSource2Finalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSource2Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsource2_free(ptr, 0);
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingsource2_cancel(ptr);
    }
    /**
     * @param {ReadableStreamDefaultController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingsource2_pull(this.__wbg_ptr, controller);
        return ret;
    }
}
if (Symbol.dispose) IntoUnderlyingSource2.prototype[Symbol.dispose] = IntoUnderlyingSource2.prototype.free;

class Keypair {
    static __wrap(ptr) {
        const obj = Object.create(Keypair.prototype);
        obj.__wbg_ptr = ptr;
        KeypairFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        KeypairFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_keypair_free(ptr, 0);
    }
    /**
     * Create a recovery file for this keypair (encrypted with the given passphrase).
     * @param {string} passphrase
     * @returns {Uint8Array}
     */
    createRecoveryFile(passphrase) {
        const ptr0 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.keypair_createRecoveryFile(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Decrypt a recovery file and return a Keypair (decrypted with the given passphrase).
     * @param {Uint8Array} recovery_file
     * @param {string} passphrase
     * @returns {Keypair}
     */
    static fromRecoveryFile(recovery_file, passphrase) {
        const ptr0 = passArray8ToWasm0(recovery_file, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.keypair_fromRecoveryFile(ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Keypair.__wrap(ret[0]);
    }
    /**
     * Generate a [Keypair] from a 32-byte secret.
     * @param {Uint8Array} secret
     * @returns {Keypair}
     */
    static fromSecret(secret) {
        const ptr0 = passArray8ToWasm0(secret, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.keypair_fromSecret(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Keypair.__wrap(ret[0]);
    }
    /**
     * Returns the [PublicKey] of this keypair.
     *
     * Use `.toString()` on the returned `PublicKey` to get the string form
     * or `.z32()` to get the z32 string form without prefix.
     * Transport/storage (query params, headers, persistence) should use `.z32()`.
     *
     * @example
     * const who = keypair.publicKey.toString();
     * @returns {PublicKey}
     */
    get publicKey() {
        const ret = wasm.keypair_publicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Generate a random [Keypair]
     * @returns {Keypair}
     */
    static random() {
        const ret = wasm.keypair_random();
        return Keypair.__wrap(ret);
    }
    /**
     * Returns the secret of this keypair.
     * @returns {Uint8Array}
     */
    secret() {
        const ret = wasm.keypair_secret(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) Keypair.prototype[Symbol.dispose] = Keypair.prototype.free;
exports.Keypair = Keypair;

/**
 * Resolve/publish `_pubky` PKDNS records (homeserver pointers).
 */
class Pkdns {
    static __wrap(ptr) {
        const obj = Object.create(Pkdns.prototype);
        obj.__wbg_ptr = ptr;
        PkdnsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PkdnsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pkdns_free(ptr, 0);
    }
    /**
     * PKDNS actor with publishing enabled (requires a keypair).
     * @param {Keypair} keypair
     * @returns {Pkdns}
     */
    static fromKeypair(keypair) {
        _assertClass(keypair, Keypair);
        const ret = wasm.pkdns_fromKeypair(keypair.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Pkdns.__wrap(ret[0]);
    }
    /**
     * Resolve the homeserver for a given public key (read-only).
     *
     * @param {PublicKey} user
     * @returns {Promise<PublicKey|undefined>} Homeserver public key, or `undefined` when the
     *   user has no resolvable homeserver record.
     * @throws When Pkarr resolution fails or a resolved `_pubky` target is malformed.
     * @param {PublicKey} pubky
     * @returns {Promise<PublicKey | undefined>}
     */
    getHomeserverOf(pubky) {
        _assertClass(pubky, PublicKey);
        const ret = wasm.pkdns_getHomeserverOf(this.__wbg_ptr, pubky.__wbg_ptr);
        return ret;
    }
    /**
     * Resolve the homeserver for **this** user (requires keypair).
     *
     * @returns {Promise<PublicKey|undefined>} Homeserver public key or `undefined` if not found.
     * @throws When no keypair is attached, Pkarr resolution fails, or a resolved `_pubky` target
     *   is malformed.
     * @returns {Promise<PublicKey | undefined>}
     */
    getHomeserver() {
        const ret = wasm.pkdns_getHomeserver(this.__wbg_ptr);
        return ret;
    }
    /**
     * Read-only PKDNS actor (no keypair; resolve only).
     */
    constructor() {
        const ret = wasm.pkdns_new();
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        PkdnsFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Force publish homeserver immediately (even if fresh).
     *
     * Requires keypair or to be signer bound.
     *
     * @param {PublicKey=} overrideHost Optional new homeserver to publish (migration).
     * @returns {Promise<void>}
     * @param {PublicKey | null} [host_override]
     * @returns {Promise<void>}
     */
    publishHomeserverForce(host_override) {
        let ptr0 = 0;
        if (!isLikeNone(host_override)) {
            _assertClass(host_override, PublicKey);
            ptr0 = host_override.__destroy_into_raw();
        }
        const ret = wasm.pkdns_publishHomeserverForce(this.__wbg_ptr, ptr0);
        return ret;
    }
    /**
     * Republish homeserver if record is missing/stale.
     *
     * Requires keypair or to be signer bound.
     *
     * @param {PublicKey=} overrideHost Optional new homeserver to publish (migration).
     * @returns {Promise<void>}
     * @param {PublicKey | null} [host_override]
     * @returns {Promise<void>}
     */
    publishHomeserverIfStale(host_override) {
        let ptr0 = 0;
        if (!isLikeNone(host_override)) {
            _assertClass(host_override, PublicKey);
            ptr0 = host_override.__destroy_into_raw();
        }
        const ret = wasm.pkdns_publishHomeserverIfStale(this.__wbg_ptr, ptr0);
        return ret;
    }
}
if (Symbol.dispose) Pkdns.prototype[Symbol.dispose] = Pkdns.prototype.free;
exports.Pkdns = Pkdns;

/**
 * High-level entrypoint to the Pubky SDK.
 */
class Pubky {
    static __wrap(ptr) {
        const obj = Object.create(Pubky.prototype);
        obj.__wbg_ptr = ptr;
        PubkyFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubky_free(ptr, 0);
    }
    /**
     * Browser-backed store for explicitly persisted completed grant sessions.
     *
     * Use `browserSessionStore.save(session)` after a successful grant auth flow to make
     * the session restorable after reload. The store supports multiple accounts
     * and multiple grants per account.
     * @returns {BrowserSessionStore}
     */
    get browserSessionStore() {
        const ret = wasm.pubky_browserSessionStore(this.__wbg_ptr);
        return BrowserSessionStore.__wrap(ret);
    }
    /**
     * Access the underlying HTTP client (advanced).
     *
     * @returns {Client}
     * Use this for low-level `fetch()` calls or testing with raw URLs.
     *
     * @example
     * const r = await pubky.client.fetch(`pubky://${userPk.z32()}/pub/app/file.txt`, { credentials: "include" });
     * @returns {Client}
     */
    get client() {
        const ret = wasm.pubky_client(this.__wbg_ptr);
        return Client.__wrap(ret);
    }
    /**
     * Create an event stream builder for a single user.
     *
     * This is the simplest way to subscribe to events for one user. The homeserver
     * is automatically resolved from the user's Pkarr record.
     *
     * @param {PublicKey} user - The user's public key
     * @param {string | null} cursor - Optional cursor position to start from
     * @returns {EventStreamBuilder} - Builder for configuring and subscribing to the stream
     *
     * @example
     * ```typescript
     * const user = PublicKey.from("o1gg96ewuojmopcjbz8895478wdtxtzzuxnfjjz8o8e77csa1ngo");
     * const stream = await pubky.eventStreamForUser(user, null)
     *   .live()
     *   .subscribe();
     *
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     * @param {PublicKey} user
     * @param {string | null} [cursor]
     * @returns {EventStreamBuilder}
     */
    eventStreamForUser(user, cursor) {
        _assertClass(user, PublicKey);
        var ptr0 = isLikeNone(cursor) ? 0 : passStringToWasm0(cursor, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_eventStreamForUser(this.__wbg_ptr, user.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return EventStreamBuilder.__wrap(ret[0]);
    }
    /**
     * Create an event stream builder for a specific homeserver.
     *
     * Use this when you already know the homeserver pubkey. This avoids
     * Pkarr resolution overhead. Obtain a homeserver pubkey via `getHomeserverOf()`.
     *
     * @param {PublicKey} homeserver - The homeserver public key
     * @returns {EventStreamBuilder} - Builder for configuring and subscribing to the stream
     *
     * @example
     * ```typescript
     * const homeserver = await pubky.getHomeserverOf(user1);
     * const stream = await pubky.eventStreamFor(homeserver)
     *   .addUsers([[user1.z32(), null], [user2.z32(), null]])
     *   .live()
     *   .subscribe();
     *
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     * @param {PublicKey} homeserver
     * @returns {EventStreamBuilder}
     */
    eventStreamFor(homeserver) {
        _assertClass(homeserver, PublicKey);
        const ret = wasm.pubky_eventStreamFor(this.__wbg_ptr, homeserver.__wbg_ptr);
        return EventStreamBuilder.__wrap(ret);
    }
    /**
     * Resolve the homeserver for a given public key (read-only).
     *
     * Uses an internal read-only Pkdns actor.
     *
     * @param {PublicKey} user
     * @returns {Promise<PublicKey|undefined>} Homeserver public key, or `undefined` when the
     *   user has no resolvable homeserver record.
     * @throws When Pkarr resolution fails or a resolved `_pubky` target is malformed.
     * @param {PublicKey} user_public_key
     * @returns {Promise<PublicKey | undefined>}
     */
    getHomeserverOf(user_public_key) {
        _assertClass(user_public_key, PublicKey);
        const ret = wasm.pubky_getHomeserverOf(this.__wbg_ptr, user_public_key.__wbg_ptr);
        return ret;
    }
    /**
     * Create a Pubky facade wired for **mainnet** defaults (public relays).
     *
     * Prefer to instantiate only once and use trough your application a single shared `Pubky`
     * instead of constructing one per request. This avoids reinitializing transports and keeps
     * the same client available for repeated usage.
     *
     * @returns {Pubky}
     * A new facade instance. Use this to create signers, start auth flows, etc.
     *
     * @example
     * const pubky = new Pubky();
     * const signer = pubky.signer(Keypair.random());
     */
    constructor() {
        const ret = wasm.pubky_new();
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        PubkyFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Public, unauthenticated storage API.
     *
     * Use for **read-only** public access via addressed paths:
     * `"pubky<user>/pub/…"`.
     *
     * @returns {PublicStorage}
     *
     * @example
     * const text = await pubky.publicStorage.getText(`${userPk.toString()}/pub/example.com/hello.txt`);
     * @returns {PublicStorage}
     */
    get publicStorage() {
        const ret = wasm.pubky_publicStorage(this.__wbg_ptr);
        return PublicStorage.__wrap(ret);
    }
    /**
     * Restore a session from a previously exported token or snapshot, using this instance's client.
     *
     * Accepts grant secret tokens from `session.exportLocalSecret()` and legacy cookie
     * secret tokens. Also accepts legacy cookie metadata snapshots from `session.export()`.
     * Grant restore mints a fresh short-lived bearer.
     *
     * @param {string} exported A string produced by `session.exportLocalSecret()` or legacy `session.export()`.
     * @returns {Promise<Session>}
     * A rehydrated session bound to this SDK's HTTP client.
     *
     * @example
     * const restored = await pubky.restoreSession(localStorage.getItem("pubky-session")!);
     * @param {string} exported
     * @returns {Promise<Session>}
     */
    restoreSession(exported) {
        const ptr0 = passStringToWasm0(exported, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_restoreSession(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Resume a previously started **pubkyauth** flow from its saved `authorizationUrl`.
     *
     * If the user refreshes or navigates away mid-flow, WASM memory is lost and
     * the original `AuthFlow` object is gone. You can reconnect to the same relay
     * channel by saving the `authorizationUrl` beforehand and calling this method
     * after reload.
     *
     * The relay inbox retains messages for **~5 minutes**. Resume is only
     * viable within that window; afterwards start a fresh flow.
     *
     * **Security:** The URL contains the `client_secret` in plaintext.
     * Store it in `sessionStorage` (scoped to the tab), **not** `localStorage`,
     * and delete it as soon as the resumed flow completes or is abandoned.
     * See `startCookieAuthFlow()` docs for full storage guidance.
     *
     * @param {string} authorizationUrl The `pubkyauth://…` URL from a previous flow.
     * @returns {AuthFlow} A flow reconnected to the original relay channel.
     * @throws {PubkyError}
     * - `{ name: "AuthenticationError" }` if the URL is invalid or not a signin/signup link
     * - `{ name: "RequestError" }` on network/relay failure
     *
     * @example
     * // 1) Before a potential refresh, persist the URL.
     * const flow = pubky.startCookieAuthFlow("/pub/my-cool-app/:rw", AuthFlowKind.signin());
     * sessionStorage.setItem("pubky-auth-url", flow.authorizationUrl);
     * renderQr(flow.authorizationUrl);
     *
     * // 2) After reload, resume from the saved URL.
     * const savedUrl = sessionStorage.getItem("pubky-auth-url");
     * if (savedUrl) {
     *   try {
     *     const resumed = pubky.resumeCookieAuthFlow(savedUrl);
     *     const session = await resumed.awaitApproval();
     *   } finally {
     *     sessionStorage.removeItem("pubky-auth-url");
     *   }
     * }
     *
     * @deprecated Use `resumeGrantAuthFlow(...)` instead.
     * @param {string} authorization_url
     * @returns {AuthFlow}
     */
    resumeCookieAuthFlow(authorization_url) {
        const ptr0 = passStringToWasm0(authorization_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_resumeCookieAuthFlow(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthFlow.__wrap(ret[0]);
    }
    /**
     * Resume a previously saved pending delegated grant auth flow.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. The saved `keyId` must still
     * exist in IndexedDB for the same origin. Unsupported runtimes reject with
     * `ClientStateError`.
     * @param {string} saved_state
     * @returns {Promise<GrantAuthFlow>}
     */
    resumeDelegatedGrantAuthFlow(saved_state) {
        const ptr0 = passStringToWasm0(saved_state, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_resumeDelegatedGrantAuthFlow(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Resume a previously saved pending grant auth flow.
     *
     * **Security:** `savedState` contains the relay secret and PoP client private key.
     * Delete it from storage as soon as the resumed flow completes.
     *
     * @param {string} savedState A string produced by `grantFlow.saveLocal()`.
     * @returns {GrantAuthFlow} A flow reconnected to the original relay channel.
     * @param {string} saved_state
     * @returns {GrantAuthFlow}
     */
    resumeGrantAuthFlow(saved_state) {
        const ptr0 = passStringToWasm0(saved_state, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_resumeGrantAuthFlow(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GrantAuthFlow.__wrap(ret[0]);
    }
    /**
     * Create a `Signer` from an existing `Keypair`.
     *
     * @param {Keypair} keypair The user’s keys.
     * @returns {Signer}
     *
     * @example
     * const signer = pubky.signer(Keypair.random());
     * await signer.signup(homeserverPk);
     * @param {Keypair} keypair
     * @returns {Signer}
     */
    signer(keypair) {
        _assertClass(keypair, Keypair);
        const ret = wasm.pubky_signer(this.__wbg_ptr, keypair.__wbg_ptr);
        return Signer.__wrap(ret);
    }
    /**
     * Start a **pubkyauth** flow.
     *
     * Provide a **capabilities string** and (optionally) a relay base URL.
     * The capabilities string is a comma-separated list of entries:
     * `"<scope>:<actions>"`, where:
     * - `scope` starts with `/` (e.g. `/pub/example.com/`).
     * - `actions` is any combo of `r` and/or `w` (order normalized; `wr` -> `rw`).
     * Pass `""` for no scopes (read-only public session).
     *
     * **Security:** `authorizationUrl` contains the `client_secret` in plaintext.
     * If you need resume after refresh/app switch, save it in `sessionStorage`
     * (not `localStorage`), then delete it once approval arrives or is abandoned.
     *
     * @param {string} capabilities Comma-separated caps, e.g. `"/pub/app/:rw,/pub/foo/file:r"`.
     * @param {AuthFlowKind} kind The kind of authentication flow to perform.
     * Examples:
     * - `AuthFlowKind.signin()` - Sign in to an existing account.
     * - `AuthFlowKind.signup(homeserverPublicKey, signupToken)` - Sign up for a new account.
     * @param {string=} relay Optional HTTP relay base (e.g. `"https://…/inbox/"`).
     * @param {XCallbackParams=} xCallback Optional app return destinations.
     * @returns {AuthFlow}
     * A running auth flow. Show `authorizationUrl` as QR/deeplink,
     * then `awaitApproval()` to obtain a `Session`.
     *
     * @throws {PubkyError}
     * - `{ name: "InvalidInput" }` for malformed capabilities or bad relay URL
     * - `{ name: "RequestError" }` if the flow cannot be started (network/relay)
     *
     * @example
     * const flow = pubky.startCookieAuthFlow("/pub/my-cool-app/:rw");
     * renderQr(flow.authorizationUrl);
     * const session = await flow.awaitApproval();
     *
     * @deprecated Use `startGrantAuthFlow(...)` instead.
     * @param {Capabilities} capabilities
     * @param {AuthFlowKind} kind
     * @param {string | null} [relay]
     * @param {XCallbackParams | null} [x_callback]
     * @returns {AuthFlow}
     */
    startCookieAuthFlow(capabilities, kind, relay, x_callback) {
        const ptr0 = passStringToWasm0(capabilities, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(kind, AuthFlowKind);
        var ptr1 = kind.__destroy_into_raw();
        var ptr2 = isLikeNone(relay) ? 0 : passStringToWasm0(relay, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_startCookieAuthFlow(this.__wbg_ptr, ptr0, len0, ptr1, ptr2, len2, isLikeNone(x_callback) ? 0 : addToExternrefTable0(x_callback));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AuthFlow.__wrap(ret[0]);
    }
    /**
     * Start a grant-backed **pubkyauth** flow.
     *
     * Grant auth uses a user-signed grant JWS plus Proof-of-Possession and
     * returns a self-refreshing session.
     * Select `approvalFormat: "signedApprovalV1"` and include `e` on scopes that need content
     * keys. Storage `r` and `w` alone do not deliver encryption keys.
     *
     * @param {string} capabilities Comma-separated caps, e.g. `"/pub/app/:rw,/pub/foo/file:r"`.
     * @param {AuthFlowKind} kind The kind of authentication flow to perform.
     * @param {GrantAuthFlowOptions} options Options for the grant flow:
     * `{ clientId, relay?, xCallback?, approvalFormat? }`.
     * @returns {Promise<GrantAuthFlow>}
     * A running grant auth flow. Show `authorizationUrl` as QR/deeplink,
     * then `awaitApproval()` to obtain a grant-backed `Session`.
     *
     * @example
     * const flow = await pubky.startGrantAuthFlow(
     *   "/pub/my-cool-app/:rw",
     *   AuthFlowKind.signin(),
     *   { clientId: "my-cool-app.example" },
     * );
     * @param {Capabilities} capabilities
     * @param {AuthFlowKind} kind
     * @param {GrantAuthFlowOptions} options
     * @returns {Promise<GrantAuthFlow>}
     */
    startGrantAuthFlow(capabilities, kind, options) {
        const ptr0 = passStringToWasm0(capabilities, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(kind, AuthFlowKind);
        var ptr1 = kind.__destroy_into_raw();
        const ret = wasm.pubky_startGrantAuthFlow(this.__wbg_ptr, ptr0, len0, ptr1, options);
        return ret;
    }
    /**
     * Create a Pubky facade preconfigured for a **local testnet**.
     *
     * If `host` is provided, PKARR and HTTP endpoints are derived as `http://<host>:ports/...`.
     * If omitted, `"localhost"` is assumed (handy for `cargo install pubky-testnet`).
     *
     * @param {string=} host Optional host (e.g. `"localhost"`, `"docker-host"`, `"127.0.0.1"`).
     * @returns {Pubky}
     *
     * @example
     * const pubky = Pubky.testnet();              // localhost default
     * const pubky = Pubky.testnet("docker-host"); // custom hostname/IP
     * @param {string | null} [host]
     * @returns {Pubky}
     */
    static testnet(host) {
        var ptr0 = isLikeNone(host) ? 0 : passStringToWasm0(host, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubky_testnet(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Pubky.__wrap(ret[0]);
    }
    /**
     * Wrap an existing configured HTTP client into a Pubky facade.
     *
     * @param {Client} client A previously constructed client.
     * @returns {Pubky}
     *
     * @example
     * const client = Client.testnet();
     * const pubky = Pubky.withClient(client);
     * @param {Client} client
     * @returns {Pubky}
     */
    static withClient(client) {
        _assertClass(client, Client);
        const ret = wasm.pubky_withClient(client.__wbg_ptr);
        return Pubky.__wrap(ret);
    }
}
if (Symbol.dispose) Pubky.prototype[Symbol.dispose] = Pubky.prototype.free;
exports.Pubky = Pubky;

/**
 * An addressed resource: a user's public key paired with an absolute path.
 *
 * This represents a specific file or directory on a user's homeserver.
 *
 * @example
 * ```typescript
 * // Parse from a pubky URL
 * const resource = PubkyResource.parse("pubky://o1gg96ewuojmopcjbz8895478wdtxtzzuxnfjjz8o8e77csa1ngo/pub/example.txt");
 * console.log(resource.owner.z32()); // The user's public key
 * console.log(resource.path);        // "/pub/example.txt"
 * console.log(resource.toPubkyUrl()); // "pubky://o1gg96.../pub/example.txt"
 * ```
 */
class PubkyResource {
    static __wrap(ptr) {
        const obj = Object.create(PubkyResource.prototype);
        obj.__wbg_ptr = ptr;
        PubkyResourceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyResourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyresource_free(ptr, 0);
    }
    /**
     * Get the owner's public key.
     * @returns {PublicKey}
     */
    get owner() {
        const ret = wasm.pubkyresource_owner(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Parse a pubky resource from a string.
     *
     * Accepts:
     * - `pubky://<public_key>/<path>` (URL form)
     * - `pubky<public_key>/<path>` (identifier form)
     *
     * @param {string} value - The resource string to parse
     * @returns {PubkyResource} - The parsed resource
     * @throws {Error} - If the string is not a valid pubky resource
     * @param {string} value
     * @returns {PubkyResource}
     */
    static parse(value) {
        const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyresource_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyResource.__wrap(ret[0]);
    }
    /**
     * Get the absolute path (e.g., "/pub/example.txt").
     * @returns {string}
     */
    get path() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyresource_path(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Render as `pubky://<owner>/<path>` (deep-link/URL form).
     * @returns {string}
     */
    toPubkyUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyresource_toPubkyUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Render as `pubky<owner>/<path>` (identifier form).
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyresource_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PubkyResource.prototype[Symbol.dispose] = PubkyResource.prototype.free;
exports.PubkyResource = PubkyResource;

class PublicKey {
    static __wrap(ptr) {
        const obj = Object.create(PublicKey.prototype);
        obj.__wbg_ptr = ptr;
        PublicKeyFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublicKeyFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publickey_free(ptr, 0);
    }
    /**
     * @throws
     * @param {string} value
     * @returns {PublicKey}
     */
    static from(value) {
        const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publickey_from(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PublicKey.__wrap(ret[0]);
    }
    /**
     * Returns the identifier form with the `pubky` prefix.
     * Use for display only; transport/storage should use `.z32()`.
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.publickey_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Convert the PublicKey to Uint8Array
     * @returns {Uint8Array}
     */
    toUint8Array() {
        const ret = wasm.publickey_toUint8Array(this.__wbg_ptr);
        return ret;
    }
    /**
     * Returns the z-base32 encoding of this public key
     * @returns {string}
     */
    z32() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.publickey_z32(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PublicKey.prototype[Symbol.dispose] = PublicKey.prototype.free;
exports.PublicKey = PublicKey;

/**
 * Read-only public storage using addressed paths (`"pubky<user>/pub/..."`).
 */
class PublicStorage {
    static __wrap(ptr) {
        const obj = Object.create(PublicStorage.prototype);
        obj.__wbg_ptr = ptr;
        PublicStorageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublicStorageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publicstorage_free(ptr, 0);
    }
    /**
     * Check if a path exists.
     *
     * @param {Address} address
     * @returns {Promise<boolean>}
     * @param {Address} address
     * @returns {Promise<boolean>}
     */
    exists(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_exists(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Fetch bytes from an addressed path.
     *
     * @param {Address} address
     * @returns {Promise<Uint8Array>}
     * @param {Address} address
     * @returns {Promise<Uint8Array>}
     */
    getBytes(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_getBytes(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Fetch JSON from an addressed path.
     *
     * @param {Address} address `"pubky<user>/pub/.../file.json"` (preferred) or `pubky://<user>/pub/...`.
     * @returns {Promise<any>}
     * @param {Address} address
     * @returns {Promise<any>}
     */
    getJson(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_getJson(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Fetch text from an addressed path as UTF-8 text.
     *
     * @param {Address} address
     * @returns {Promise<string>}
     * @param {Address} address
     * @returns {Promise<string>}
     */
    getText(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_getText(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Perform a streaming `GET` and expose the raw `Response` object.
     *
     * @param {Address} address
     * @returns {Promise<Response>}
     * @param {Address} address
     * @returns {Promise<Response>}
     */
    get(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_get(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * List a directory. Results are `pubky://…` identifier URLs.
     *
     * @param {Address} address Addressed directory (must end with `/`).
     * @param {string|null=} cursor Optional suffix or full URL to start **after**.
     * @param {boolean=} reverse Default `false`. When `true`, newest/lexicographically-last first.
     * @param {number=} limit Optional result limit.
     * @param {boolean=} shallow Default `false`. When `true`, lists only first-level entries.
     * @returns {Promise<string[]>}
     * @param {Address} address
     * @param {string | null} [cursor]
     * @param {boolean | null} [reverse]
     * @param {number | null} [limit]
     * @param {boolean | null} [shallow]
     * @returns {Promise<string[]>}
     */
    list(address, cursor, reverse, limit, shallow) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(cursor) ? 0 : passStringToWasm0(cursor, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_list(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(reverse) ? 0xFFFFFF : reverse ? 1 : 0, isLikeNone(limit) ? 0xFFFFFF : limit, isLikeNone(shallow) ? 0xFFFFFF : shallow ? 1 : 0);
        return ret;
    }
    /**
     * Construct PublicStorage using global client (mainline relays).
     */
    constructor() {
        const ret = wasm.publicstorage_new();
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        PublicStorageFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get metadata for an address
     *
     * @param {Address} address `"pubky<user>/pub/.../file.json"` (preferred) or `pubky://<user>/pub/...`.
     * @returns {Promise<ResourceStats|undefined>} `undefined` if the resource does not exist.
     * @throws {PubkyError} On invalid input or transport/server errors.
     * @param {Address} address
     * @returns {Promise<ResourceStats | undefined>}
     */
    stats(address) {
        const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.publicstorage_stats(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) PublicStorage.prototype[Symbol.dispose] = PublicStorage.prototype.free;
exports.PublicStorage = PublicStorage;

class SeedExportDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(SeedExportDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        SeedExportDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SeedExportDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_seedexportdeeplink_free(ptr, 0);
    }
    /**
     * @param {string} url
     * @returns {SeedExportDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.seedexportdeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SeedExportDeepLink.__wrap(ret[0]);
    }
    /**
     * @returns {Uint8Array}
     */
    get secret() {
        const ret = wasm.seedexportdeeplink_secret(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.seedexportdeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.seedexportdeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) SeedExportDeepLink.prototype[Symbol.dispose] = SeedExportDeepLink.prototype.free;
exports.SeedExportDeepLink = SeedExportDeepLink;

/**
 * An authenticated context “as the user”.
 * - Use `storage` for reads/writes (absolute paths like `/pub/app/file.txt`)
 * - Cookie is managed automatically by the underlying fetch client
 */
class Session {
    static __wrap(ptr) {
        const obj = Object.create(Session.prototype);
        obj.__wbg_ptr = ptr;
        SessionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SessionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_session_free(ptr, 0);
    }
    /**
     * Cookie-only view for cookie-backed sessions.
     *
     * Grant-backed sessions return `undefined`.
     *
     * @returns {CookieSession|undefined}
     * @deprecated Use `session.grant` and `GrantSession` instead.
     * @returns {CookieSession | undefined}
     */
    get cookie() {
        const ret = wasm.session_cookie(this.__wbg_ptr);
        return ret === 0 ? undefined : CookieSession.__wrap(ret);
    }
    /**
     * Export the local secret material needed to restore this session.
     *
     * For local grant sessions this exports the grant JWS and PoP client secret;
     * restoring mints a fresh bearer. For legacy cookie sessions this exports the
     * cookie secret when the SDK owns it. Delegated browser grant sessions cannot
     * export raw secret material; use `BrowserSessionStore`.
     *
     * Treat the returned string as a bearer-equivalent secret until the grant or
     * cookie session expires or is revoked.
     *
     * @returns {Promise<string>}
     * A secret token that can be passed to `pubky.restoreSession()`.
     * @returns {Promise<string>}
     */
    exportLocalSecret() {
        const ret = wasm.session_exportLocalSecret(this.__wbg_ptr);
        return ret;
    }
    /**
     * Export the session metadata so it can be restored after a tab refresh.
     *
     * The export string contains **no secrets**; it only serializes the public `SessionInfo`.
     * Browsers remain responsible for persisting the HTTP-only session cookie.
     *
     * @returns {string}
     * A base64 string to store (e.g. in `localStorage`).
     *
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     * @returns {string}
     */
    export() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.session_export(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Grant-only management view for grant-backed sessions.
     *
     * Cookie-backed sessions return `undefined`.
     *
     * @returns {GrantSession|undefined}
     * @returns {GrantSession | undefined}
     */
    get grant() {
        const ret = wasm.session_grant(this.__wbg_ptr);
        return ret === 0 ? undefined : GrantSession.__wrap(ret);
    }
    /**
     * Retrieve immutable info about this session (user & capabilities).
     *
     * @returns {SessionInfo}
     * @returns {SessionInfo}
     */
    get info() {
        const ret = wasm.session_info(this.__wbg_ptr);
        return SessionInfo.__wrap(ret);
    }
    /**
     * Restore a session from an `export()` string.
     *
     * The HTTP-only cookie must still be present in the browser; this function does not
     * read or write any secrets.
     *
     * @param {string} exported
     * A string produced by `session.export()`.
     * @param {Client=} client
     * Optional client to reuse transport configuration.
     * @returns {Promise<Session>}
     *
     * @deprecated Use `Pubky.restoreSession(...)` with a grant secret.
     * @param {string} exported
     * @param {Client | null} [client]
     * @returns {Promise<Session>}
     */
    static restore(exported, client) {
        const ptr0 = passStringToWasm0(exported, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        let ptr1 = 0;
        if (!isLikeNone(client)) {
            _assertClass(client, Client);
            ptr1 = client.__destroy_into_raw();
        }
        const ret = wasm.session_restore(ptr0, len0, ptr1);
        return ret;
    }
    /**
     * Invalidate the session on the server (clears server cookie).
     * Further calls to storage API will fail.
     *
     * @returns {Promise<void>}
     * @returns {Promise<void>}
     */
    signout() {
        const ret = wasm.session_signout(this.__wbg_ptr);
        return ret;
    }
    /**
     * Access the session-scoped storage API (read/write).
     *
     * @returns {SessionStorage}
     * @returns {SessionStorage}
     */
    get storage() {
        const ret = wasm.session_storage(this.__wbg_ptr);
        return SessionStorage.__wrap(ret);
    }
}
if (Symbol.dispose) Session.prototype[Symbol.dispose] = Session.prototype.free;
exports.Session = Session;

/**
 * Static snapshot of session metadata.
 */
class SessionInfo {
    static __wrap(ptr) {
        const obj = Object.create(SessionInfo.prototype);
        obj.__wbg_ptr = ptr;
        SessionInfoFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SessionInfoFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sessioninfo_free(ptr, 0);
    }
    /**
     * Effective capabilities granted to this session.
     *
     * @returns {string[]} Normalized capability entries (e.g. `"/pub/app/:rw"`).
     * @returns {string[]}
     */
    get capabilities() {
        const ret = wasm.sessioninfo_capabilities(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The user’s public key for this session.
     *
     * Use `.toString()` on the returned `PublicKey` to get the `pubky<z32>` identifier.
     * Call `.z32()` when you specifically need the raw z-base32 value (e.g. hostnames).
     *
     * @returns {PublicKey}
     *
     * @example
     * const who = sessionInfo.publicKey.toString();
     * @returns {PublicKey}
     */
    get publicKey() {
        const ret = wasm.sessioninfo_publicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
}
if (Symbol.dispose) SessionInfo.prototype[Symbol.dispose] = SessionInfo.prototype.free;
exports.SessionInfo = SessionInfo;

/**
 * Read/write storage scoped to **your** session (absolute paths: `/pub/...` or `/priv/...`).
 *
 * Failures reject with a {@link PubkyError}. Path validation, transport, and HTTP
 * failures use `RequestError`; only HTTP errors include `data.statusCode`.
 * URL parsing failures use `InvalidInput`. Credential preparation, refresh,
 * and reading response bodies can also fail.
 *
 * Only {@link SessionStorage.exists} and {@link SessionStorage.stats} treat
 * HTTP 404/410 as missing. Other HTTP failures, including 401/403 and 5xx, reject.
 * Writes require write permission and can fail on directory targets (400),
 * file/directory path conflicts (409), a path someone holds a
 * {@link StorageLock} on (423), or exceeded quotas (507).
 */
class SessionStorage {
    static __wrap(ptr) {
        const obj = Object.create(SessionStorage.prototype);
        obj.__wbg_ptr = ptr;
        SessionStorageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SessionStorageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sessionstorage_free(ptr, 0);
    }
    /**
     * `DELETE` the path of a lock this client holds. The lock stays in place.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one.
     * Otherwise as {@link SessionStorage.delete}.
     * @param {StorageLock} lock
     * @returns {Promise<void>}
     */
    deleteLocked(lock) {
        _assertClass(lock, StorageLock);
        const ret = wasm.sessionstorage_deleteLocked(this.__wbg_ptr, lock.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a file. Directory targets are unsupported.
     *
     * @param {Path} path File path; must not end with `/`.
     * @returns {Promise<void>}
     * @throws {PubkyError} Missing file (404), directory target (400), or shared errors
     * (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<void>}
     */
    delete(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_delete(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Check existence with a HEAD request.
     *
     * @param {Path} path
     * @returns {Promise<boolean>} `true` on success; `false` for HTTP 404/410.
     * @throws {PubkyError} All other failures (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<boolean>}
     */
    exists(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_exists(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * GET bytes from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<Uint8Array>} The complete response body.
     * @throws {PubkyError} Missing resource (404/410) or shared errors (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<Uint8Array>}
     */
    getBytes(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_getBytes(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * GET JSON from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<any>} The parsed JSON value.
     * @throws {PubkyError} Missing resource (404/410), JSON parsing/conversion failures,
     * or shared errors (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<any>}
     */
    getJson(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_getJson(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * GET text from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<string>} The complete response body decoded as text.
     * @throws {PubkyError} Missing resource (404/410) or shared errors (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<string>}
     */
    getText(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_getText(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * GET a streaming response for an absolute session path.
     *
     * Reading the returned response body can still fail after this resolves.
     *
     * @param {Path} path
     * @returns {Promise<Response>} A successful response with an unread body.
     * @throws {PubkyError} Missing resource (404/410) or other request/response errors.
     * See {@link SessionStorage} for shared errors.
     * @param {Path} path
     * @returns {Promise<Response>}
     */
    get(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_get(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * List a directory (absolute session path).
     *
     * @param {Path} path Must end with `/`.
     * @param {string|null=} cursor Optional last entry URL to start **after**.
     * @param {boolean=} reverse Default `false`.
     * @param {number=} limit Optional result limit.
     * @param {boolean=} shallow Default `false`.
     * @returns {Promise<string[]>} `pubky://…` entry URLs, or an empty array for an empty page.
     * @throws {PubkyError} Missing directory (404), invalid cursor (400), invalid response
     * entries, or shared errors (see {@link SessionStorage}).
     * @param {Path} path
     * @param {string | null} [cursor]
     * @param {boolean | null} [reverse]
     * @param {number | null} [limit]
     * @param {boolean | null} [shallow]
     * @returns {Promise<string[]>}
     */
    list(path, cursor, reverse, limit, shallow) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(cursor) ? 0 : passStringToWasm0(cursor, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_list(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(reverse) ? 0xFFFFFF : reverse ? 1 : 0, isLikeNone(limit) ? 0xFFFFFF : limit, isLikeNone(shallow) ? 0xFFFFFF : shallow ? 1 : 0);
        return ret;
    }
    /**
     * Take an exclusive write lock on a file at an **absolute session path**.
     *
     * The file need not exist; locking a free path reserves it. `timeoutSeconds` is
     * the lifetime asked for; the homeserver caps it, and
     * {@link StorageLock.timeoutSeconds} tells what was granted. A write made under
     * the lock keeps it alive until the write ends, so it need not cover the upload itself.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {number} timeoutSeconds Lifetime to ask for, in seconds; rounded down to
     * whole seconds, and at least 1.
     * @returns {Promise<StorageLock>} The granted lock.
     * @throws {PubkyError} `InvalidInput` for a negative, NaN or out-of-range timeout;
     * a path that is already locked rejects with `RequestError` and status `423`;
     * directory targets with `400`; a homeserver without lock support with `405`.
     * See {@link SessionStorage} for shared errors.
     * @param {Path} path
     * @param {number} timeout_seconds
     * @returns {Promise<StorageLock>}
     */
    lock(path, timeout_seconds) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_lock(this.__wbg_ptr, ptr0, len0, timeout_seconds);
        return ret;
    }
    /**
     * `PUT` binary data to the path of a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * Otherwise as {@link SessionStorage.putBytes}.
     * @param {StorageLock} lock
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     */
    putBytesLocked(lock, body) {
        _assertClass(lock, StorageLock);
        const ptr0 = passArray8ToWasm0(body, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_putBytesLocked(this.__wbg_ptr, lock.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Create or replace a file with binary data at an absolute session path.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     * @throws {PubkyError} Upload or shared write/request errors (see {@link SessionStorage}).
     * @param {Path} path
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     */
    putBytes(path, body) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(body, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_putBytes(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Create or replace a file with JSON at an absolute session path.
     *
     * @param {Path} path File path (e.g. `"/pub/app/data.json"`); must not end with `/`.
     * @param {any} body JSON-serializable value.
     * @returns {Promise<void>}
     * @throws {PubkyError} `InvalidInput` if `body` cannot be converted to JSON;
     * otherwise serialization, upload, or shared write/request errors (see {@link SessionStorage}).
     * @param {Path} path
     * @param {any} body
     * @returns {Promise<void>}
     */
    putJson(path, body) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_putJson(this.__wbg_ptr, ptr0, len0, body);
        return ret;
    }
    /**
     * `PUT` text to the path of a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {string} body
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * Otherwise as {@link SessionStorage.putText}.
     * @param {StorageLock} lock
     * @param {string} body
     * @returns {Promise<void>}
     */
    putTextLocked(lock, body) {
        _assertClass(lock, StorageLock);
        const ptr0 = passStringToWasm0(body, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_putTextLocked(this.__wbg_ptr, lock.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Create or replace a file with text at an absolute session path.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {string} body
     * @returns {Promise<void>}
     * @throws {PubkyError} Upload or shared write/request errors (see {@link SessionStorage}).
     * @param {Path} path
     * @param {string} body
     * @returns {Promise<void>}
     */
    putText(path, body) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(body, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_putText(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Restart the lifetime of a lock this client holds.
     *
     * On success the lock carries the newly granted
     * {@link StorageLock.timeoutSeconds}.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {number} timeoutSeconds Lifetime to ask for, in seconds; rounded down to
     * whole seconds, and at least 1.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * `InvalidInput` for a negative, NaN or out-of-range timeout.
     * See {@link SessionStorage} for shared errors.
     * @param {StorageLock} lock
     * @param {number} timeout_seconds
     * @returns {Promise<void>}
     */
    refreshLock(lock, timeout_seconds) {
        _assertClass(lock, StorageLock);
        const ret = wasm.sessionstorage_refreshLock(this.__wbg_ptr, lock.__wbg_ptr, timeout_seconds);
        return ret;
    }
    /**
     * Get metadata for an absolute, session-scoped path (e.g. `"/pub/app/file.json"`).
     *
     * On success, missing or unparseable metadata headers leave their properties absent.
     *
     * @param {Path} path Absolute path under your user (starts with `/`).
     * @returns {Promise<ResourceStats|undefined>} Metadata on success; `undefined` for HTTP 404/410.
     * @throws {PubkyError} All other failures (see {@link SessionStorage}).
     * @param {Path} path
     * @returns {Promise<ResourceStats | undefined>}
     */
    stats(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sessionstorage_stats(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Release a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that no longer exists rejects with `RequestError`
     * and status `409`. See {@link SessionStorage} for shared errors.
     * @param {StorageLock} lock
     * @returns {Promise<void>}
     */
    unlock(lock) {
        _assertClass(lock, StorageLock);
        const ret = wasm.sessionstorage_unlock(this.__wbg_ptr, lock.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) SessionStorage.prototype[Symbol.dispose] = SessionStorage.prototype.free;
exports.SessionStorage = SessionStorage;

/**
 * Holds a user’s `Keypair` and performs identity operations:
 * - `signup` creates a new homeserver user.
 * - `signin` creates a homeserver session for an existing user.
 * - Approve pubkyauth requests
 * - Publish PKDNS when signer-bound
 */
class Signer {
    static __wrap(ptr) {
        const obj = Object.create(Signer.prototype);
        obj.__wbg_ptr = ptr;
        SignerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SignerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signer_free(ptr, 0);
    }
    /**
     * Approve a `pubkyauth://` request URL (encrypts & POSTs the signed AuthToken).
     * @param {string} pubkyauth_url
     * @returns {Promise<void>}
     */
    approveAuthRequest(pubkyauth_url) {
        const ptr0 = passStringToWasm0(pubkyauth_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_approveAuthRequest(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Create a signer from a `Keypair` (prefer `pubky.signer(kp)`).
     *
     * @param {Keypair} keypair
     * @returns {Signer}
     * @param {Keypair} keypair
     * @returns {Signer}
     */
    static fromKeypair(keypair) {
        _assertClass(keypair, Keypair);
        const ret = wasm.signer_fromKeypair(keypair.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Signer.__wrap(ret[0]);
    }
    /**
     * Handle a `pubkyauth://` deep link.
     *
     * Auth requests are approved through their relay. A `direct_signup` link
     * creates an account on its target homeserver.
     * @param {string} pubkyauth_url
     * @returns {Promise<void>}
     */
    handleDeepLink(pubkyauth_url) {
        const ptr0 = passStringToWasm0(pubkyauth_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_handleDeepLink(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Get a PKDNS actor bound to this signer's client & keypair (publishing enabled).
     *
     * @returns {Pkdns}
     *
     * @example
     * await signer.pkdns.publishHomeserverIfStale(homeserverPk);
     * @returns {Pkdns}
     */
    get pkdns() {
        const ret = wasm.signer_pkdns(this.__wbg_ptr);
        return Pkdns.__wrap(ret);
    }
    /**
     * Get the public key of this signer.
     *
     * @returns {PublicKey}
     * @returns {PublicKey}
     */
    get publicKey() {
        const ret = wasm.signer_publicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Blocking sign-in. Waits for PKDNS publish to complete (slower; safer).
     *
     * Creates a grant-backed homeserver session with root storage access (`/:rw`).
     * Encryption keys require an explicit `e` request through a signed approval flow.
     * `clientId` is shown in the user's grant/session list.
     * @param {string} clientId App identifier, typically a domain.
     *
     * @returns {Promise<Session>}
     * @param {string} client_id
     * @returns {Promise<Session>}
     */
    signinBlocking(client_id) {
        const ptr0 = passStringToWasm0(client_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_signinBlocking(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Legacy cookie blocking signin. Prefer `signinBlocking(clientId)`.
     *
     * @deprecated Prefer `signinBlocking(clientId)`.
     * @returns {Promise<Session>}
     */
    signinCookieBlocking() {
        const ret = wasm.signer_signinCookieBlocking(this.__wbg_ptr);
        return ret;
    }
    /**
     * Legacy cookie signin. Prefer `signin(clientId)`.
     *
     * @deprecated Prefer `signin(clientId)`.
     * @returns {Promise<Session>}
     */
    signinCookie() {
        const ret = wasm.signer_signinCookie(this.__wbg_ptr);
        return ret;
    }
    /**
     * Fast sign-in for a returning user. Publishes PKDNS in the background.
     *
     * Creates a grant-backed homeserver session with root storage access (`/:rw`).
     * Encryption keys require an explicit `e` request through a signed approval flow.
     * `clientId` is shown in the user's grant/session list.
     * @param {string} clientId App identifier, typically a domain.
     *
     * @returns {Promise<Session>}
     *
     * @throws {PubkyError}
     * @param {string} client_id
     * @returns {Promise<Session>}
     */
    signin(client_id) {
        const ptr0 = passStringToWasm0(client_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_signin(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Legacy cookie signup. Prefer `signup()` plus `signin(clientId)`.
     *
     * @deprecated Prefer `signup()` followed by `signin(clientId)`.
     * @param {PublicKey} homeserver
     * @param {string | null} [signup_token]
     * @returns {Promise<Session>}
     */
    signupCookie(homeserver, signup_token) {
        _assertClass(homeserver, PublicKey);
        var ptr0 = isLikeNone(signup_token) ? 0 : passStringToWasm0(signup_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_signupCookie(this.__wbg_ptr, homeserver.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Sign up at a homeserver.
     *
     * Creates the account and publishes PKDNS. Call `signin(clientId)` to create a session.
     *
     * @param {PublicKey} homeserver The homeserver’s public key.
     * @param {string|null} signupToken Invite/registration token or `null`.
     * @returns {Promise<void>}
     *
     * @throws {PubkyError}
     * - `AuthenticationError` (bad/expired token)
     * - `RequestError` (network/server)
     * @param {PublicKey} homeserver
     * @param {string | null} [signup_token]
     * @returns {Promise<void>}
     */
    signup(homeserver, signup_token) {
        _assertClass(homeserver, PublicKey);
        var ptr0 = isLikeNone(signup_token) ? 0 : passStringToWasm0(signup_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.signer_signup(this.__wbg_ptr, homeserver.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) Signer.prototype[Symbol.dispose] = Signer.prototype.free;
exports.Signer = Signer;

class SigninDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(SigninDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        SigninDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SigninDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signindeeplink_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get baseRelayUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signindeeplink_baseRelayUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get capabilities() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signindeeplink_capabilities(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} url
     * @returns {SigninDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signindeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SigninDeepLink.__wrap(ret[0]);
    }
    /**
     * @returns {Uint8Array}
     */
    get secret() {
        const ret = wasm.signindeeplink_secret(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signindeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.signindeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) SigninDeepLink.prototype[Symbol.dispose] = SigninDeepLink.prototype.free;
exports.SigninDeepLink = SigninDeepLink;

/**
 * Parsed grant-based signin deeplink.
 *
 * This is useful for tools, tests, and signer UIs that need to inspect a
 * `pubky://signin-grant` authorization URL before approving it.
 */
class SigninGrantDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(SigninGrantDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        SigninGrantDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SigninGrantDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signingrantdeeplink_free(ptr, 0);
    }
    /**
     * Negotiated approval format: `bareGrant` or `signedApprovalV1`.
     * @returns {string}
     */
    get approvalFormat() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signingrantdeeplink_approvalFormat(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Base HTTP relay inbox URL used by this auth request.
     *
     * @returns {string}
     * @returns {string}
     */
    get baseRelayUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signingrantdeeplink_baseRelayUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Capabilities requested by the application.
     *
     * @returns {string}
     * @returns {string}
     */
    get capabilities() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signingrantdeeplink_capabilities(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Application identifier shown in the user's grant/session list.
     *
     * @returns {string}
     * @returns {string}
     */
    get clientId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signingrantdeeplink_clientId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Public key for the Proof-of-Possession client created by the application.
     *
     * @returns {PublicKey}
     * @returns {PublicKey}
     */
    get clientPublicKey() {
        const ret = wasm.signingrantdeeplink_clientPublicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Parse a grant signin deeplink URL.
     *
     * @param {string} url
     * @returns {SigninGrantDeepLink}
     * @throws {PubkyError} `InvalidInput` when the URL is malformed or not a grant signin link.
     * @param {string} url
     * @returns {SigninGrantDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signingrantdeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SigninGrantDeepLink.__wrap(ret[0]);
    }
    /**
     * Relay channel secret embedded in the deeplink.
     *
     * Treat this as sensitive temporary auth-flow material.
     *
     * @returns {Uint8Array}
     * @returns {Uint8Array}
     */
    get secret() {
        const ret = wasm.signingrantdeeplink_secret(this.__wbg_ptr);
        return ret;
    }
    /**
     * Serialize this parsed deeplink back to its URL form.
     *
     * @returns {string}
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signingrantdeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.signingrantdeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) SigninGrantDeepLink.prototype[Symbol.dispose] = SigninGrantDeepLink.prototype.free;
exports.SigninGrantDeepLink = SigninGrantDeepLink;

class SignupDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(SignupDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        SignupDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SignupDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signupdeeplink_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get baseRelayUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupdeeplink_baseRelayUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get capabilities() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupdeeplink_capabilities(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {PublicKey}
     */
    get homeserver() {
        const ret = wasm.signupdeeplink_homeserver(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * @param {string} url
     * @returns {SignupDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signupdeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SignupDeepLink.__wrap(ret[0]);
    }
    /**
     * @returns {Uint8Array}
     */
    get secret() {
        const ret = wasm.signupdeeplink_secret(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string | undefined}
     */
    get signupToken() {
        const ret = wasm.signupdeeplink_signupToken(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupdeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.signupdeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) SignupDeepLink.prototype[Symbol.dispose] = SignupDeepLink.prototype.free;
exports.SignupDeepLink = SignupDeepLink;

/**
 * Parsed grant-based signup deeplink.
 *
 * This is useful for tools, tests, and signer UIs that need to inspect a
 * `pubky://signup-grant` authorization URL before approving it.
 */
class SignupGrantDeepLink {
    static __wrap(ptr) {
        const obj = Object.create(SignupGrantDeepLink.prototype);
        obj.__wbg_ptr = ptr;
        SignupGrantDeepLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SignupGrantDeepLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signupgrantdeeplink_free(ptr, 0);
    }
    /**
     * Negotiated approval format: `bareGrant` or `signedApprovalV1`.
     * @returns {string}
     */
    get approvalFormat() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupgrantdeeplink_approvalFormat(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Base HTTP relay inbox URL used by this auth request.
     *
     * @returns {string}
     * @returns {string}
     */
    get baseRelayUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupgrantdeeplink_baseRelayUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Capabilities requested by the application.
     *
     * @returns {string}
     * @returns {string}
     */
    get capabilities() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupgrantdeeplink_capabilities(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Application identifier shown in the user's grant/session list.
     *
     * @returns {string}
     * @returns {string}
     */
    get clientId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupgrantdeeplink_clientId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Public key for the Proof-of-Possession client created by the application.
     *
     * @returns {PublicKey}
     * @returns {PublicKey}
     */
    get clientPublicKey() {
        const ret = wasm.signupgrantdeeplink_clientPublicKey(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Homeserver public key requested for account creation.
     *
     * @returns {PublicKey}
     * @returns {PublicKey}
     */
    get homeserver() {
        const ret = wasm.signupgrantdeeplink_homeserver(this.__wbg_ptr);
        return PublicKey.__wrap(ret);
    }
    /**
     * Parse a grant signup deeplink URL.
     *
     * @param {string} url
     * @returns {SignupGrantDeepLink}
     * @throws {PubkyError} `InvalidInput` when the URL is malformed or not a grant signup link.
     * @param {string} url
     * @returns {SignupGrantDeepLink}
     */
    static parse(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.signupgrantdeeplink_parse(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SignupGrantDeepLink.__wrap(ret[0]);
    }
    /**
     * Relay channel secret embedded in the deeplink.
     *
     * Treat this as sensitive temporary auth-flow material.
     *
     * @returns {Uint8Array}
     * @returns {Uint8Array}
     */
    get secret() {
        const ret = wasm.signupgrantdeeplink_secret(this.__wbg_ptr);
        return ret;
    }
    /**
     * Optional signup token included in the request.
     *
     * @returns {string|undefined}
     * @returns {string | undefined}
     */
    get signupToken() {
        const ret = wasm.signupgrantdeeplink_signupToken(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Serialize this parsed deeplink back to its URL form.
     *
     * @returns {string}
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.signupgrantdeeplink_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Optional x-callback-url metadata carried by this deep link.
     * @returns {XCallbackParams}
     */
    get xCallback() {
        const ret = wasm.signupgrantdeeplink_xCallback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) SignupGrantDeepLink.prototype[Symbol.dispose] = SignupGrantDeepLink.prototype.free;
exports.SignupGrantDeepLink = SignupGrantDeepLink;

/**
 * An exclusive write lock on one file path, granted by the homeserver.
 *
 * While the lock lives, only writes that present it are accepted on the path;
 * every other write, and every other {@link SessionStorage.lock}, rejects with
 * `423 Locked`. The lock ends when it is {@link SessionStorage.unlock | unlocked}
 * or when its {@link StorageLock.timeoutSeconds} runs out without a
 * {@link SessionStorage.refreshLock | refresh}, so a client that disappears never
 * blocks a path for long.
 *
 * The lock is a bearer token: whoever holds this value, and may write the path,
 * can use and release the lock.
 *
 * Calls that take the lock may overlap: a {@link SessionStorage.refreshLock | refresh}
 * can run while a locked write is in flight.
 *
 * @example
 * const lock = await session.storage.lock("/pub/my.app/state.json", 30);
 * const state = await session.storage.getText(lock.path);
 * await session.storage.putTextLocked(lock, state);
 * await session.storage.unlock(lock);
 */
class StorageLock {
    static __wrap(ptr) {
        const obj = Object.create(StorageLock.prototype);
        obj.__wbg_ptr = ptr;
        StorageLockFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        StorageLockFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_storagelock_free(ptr, 0);
    }
    /**
     * Value of the `If` header that presents this lock on a write.
     * @returns {string}
     */
    ifHeader() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storagelock_ifHeader(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The locked path.
     * @returns {Path}
     */
    get path() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storagelock_path(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Lifetime the homeserver granted at the last `lock` or `refreshLock`, in seconds,
     * counted from when that call resolved. It may be shorter than what was asked for.
     * It is not the time remaining: note when the call resolved to know when to refresh.
     * @returns {number}
     */
    get timeoutSeconds() {
        const ret = wasm.storagelock_timeoutSeconds(this.__wbg_ptr);
        return ret;
    }
    /**
     * The lock token URL, `opaquelocktoken:<uuid>`.
     * @returns {string}
     */
    get token() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storagelock_token(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) StorageLock.prototype[Symbol.dispose] = StorageLock.prototype.free;
exports.StorageLock = StorageLock;

/**
 * Metadata for a session saved in the browser session store.
 */
class StoredSessionInfo {
    static __wrap(ptr) {
        const obj = Object.create(StoredSessionInfo.prototype);
        obj.__wbg_ptr = ptr;
        StoredSessionInfoFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        StoredSessionInfoFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_storedsessioninfo_free(ptr, 0);
    }
    /**
     * Authorized capabilities.
     * @returns {string[]}
     */
    get capabilities() {
        const ret = wasm.storedsessioninfo_capabilities(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Application/client identifier.
     * @returns {string}
     */
    get clientId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_clientId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Local save timestamp, in Unix milliseconds.
     * @returns {number}
     */
    get createdAt() {
        const ret = wasm.storedsessioninfo_createdAt(this.__wbg_ptr);
        return ret;
    }
    /**
     * Underlying grant expiry timestamp, in Unix seconds.
     * @returns {number}
     */
    get grantExpiresAt() {
        const ret = wasm.storedsessioninfo_grantExpiresAt(this.__wbg_ptr);
        return ret;
    }
    /**
     * Grant identifier backing this stored session.
     * @returns {string}
     */
    get grantId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_grantId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Homeserver public key as z32.
     * @returns {string}
     */
    get homeserver() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_homeserver(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Stable local identifier for this stored session.
     * @returns {string}
     */
    get id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * User public key as z32.
     * @returns {string}
     */
    get publicKey() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_publicKey(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * `delegated` for origin-bound WebCrypto sessions, `localSecret` for raw local PoP secret storage.
     * @returns {string}
     */
    get storageMode() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.storedsessioninfo_storageMode(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) StoredSessionInfo.prototype[Symbol.dispose] = StoredSessionInfo.prototype.free;
exports.StoredSessionInfo = StoredSessionInfo;

/**
 * Resolve a `pubky://` or `pubky<pk>/…` identifier into the homeserver transport URL.
 *
 * @param {string} identifier Either `pubky<pk>/...` (preferred) or `pubky://<pk>/...`.
 * @returns {string} HTTPS URL in the form `https://_pubky.<pk>/storage/<pk>/...`.
 * @param {string} identifier
 * @returns {string}
 */
function resolvePubky(identifier) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(identifier, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.resolvePubky(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.resolvePubky = resolvePubky;

/**
 * Set the global logging verbosity for the WASM Pubky SDK. Routes Rust `log` output to the browser console.
 *
 * Accepted values (case-sensitive): "error" | "warn" | "info" | "debug" | "trace".
 * Effects:
 * - Initializes the logger once; subsequent calls may throw if the logger is already set.
 * - Emits a single info log: `Log level set to: <level>`.
 * - Messages at or above `level` are forwarded to the appropriate `console.*` method.
 *
 * @param {Level} level
 *        Minimum log level to enable. One of: "error" | "warn" | "info" | "debug" | "trace".
 *
 * @returns {void}
 *
 * @throws {Error}
 *         If `level` is invalid ("Invalid log level") or the logger cannot be initialized
 *         (e.g., already initialized).
 *
 * Usage:
 *   Call once at application startup, before invoking other SDK APIs.
 * @param {Level} level
 */
function setLogLevel(level) {
    const ret = wasm.setLogLevel((__wbindgen_enum_Level.indexOf(level) + 1 || 6) - 1);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}
exports.setLogLevel = setLogLevel;

/**
 * Validate and normalize a capabilities string.
 *
 * - Normalizes action order (`wr` -> `rw`, `ewr` -> `rwe`).
 * - `e` requests scoped encryption/decryption keys in V1 grant approvals.
 * - Throws `InvalidInput` identifying the first malformed entry.
 *
 * @param {string} input
 * @returns {string} Normalized string (same shape as input).
 * @throws {PubkyError} `{ name: "InvalidInput" }` with a helpful message.
 * The error's `data` field is `{ invalidEntries: string[] }` containing the malformed token.
 * @param {string} input
 * @returns {string}
 */
function validateCapabilities(input) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.validateCapabilities(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.validateCapabilities = validateCapabilities;

/**
 * Verify both signatures, grant binding, and grant validity against the local clock.
 * Allows 30 seconds of future clock skew by default; never extends grant expiry.
 * Does not check replay, application authorization, or homeserver revocation.
 * @param {CustomPop} credentials
 * @param {CustomPopVerificationOptions | null} [options]
 * @returns {VerifiedCustomPop}
 */
function verifyCustomGrantPop(credentials, options) {
    const ret = wasm.verifyCustomGrantPop(credentials, isLikeNone(options) ? 0 : addToExternrefTable0(options));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyCustomGrantPop = verifyCustomGrantPop;
const import1 = {
  __pubkySessionStoreIsAvailable,
  __pubkySessionStorePut,
  __pubkySessionStoreMetadata,
  __pubkySessionStoreGet,
  __pubkySessionStoreList,
  __pubkySessionAcquire,
  __pubkySessionWait,
  __pubkySessionRelease,
  __pubkySharedSessionLoad,
  __pubkySharedSessionStore,
  __pubkySharedSessionRemove,
  __pubkySessionStoreClear,
  __pubkySessionStoreClearAll,
};
const import2 = {
  __pubkySessionStoreIsAvailable,
  __pubkySessionStorePut,
  __pubkySessionStoreMetadata,
  __pubkySessionStoreGet,
  __pubkySessionStoreList,
  __pubkySessionAcquire,
  __pubkySessionWait,
  __pubkySessionRelease,
  __pubkySharedSessionLoad,
  __pubkySharedSessionStore,
  __pubkySharedSessionRemove,
  __pubkySessionStoreClear,
  __pubkySessionStoreClearAll,
};
const import3 = {
  __pubkySessionStoreIsAvailable,
  __pubkySessionStorePut,
  __pubkySessionStoreMetadata,
  __pubkySessionStoreGet,
  __pubkySessionStoreList,
  __pubkySessionAcquire,
  __pubkySessionWait,
  __pubkySessionRelease,
  __pubkySharedSessionLoad,
  __pubkySharedSessionStore,
  __pubkySharedSessionRemove,
  __pubkySessionStoreClear,
  __pubkySessionStoreClearAll,
};
const import4 = {
  __pubkySessionStoreIsAvailable,
  __pubkySessionStorePut,
  __pubkySessionStoreMetadata,
  __pubkySessionStoreGet,
  __pubkySessionStoreList,
  __pubkySessionAcquire,
  __pubkySessionWait,
  __pubkySessionRelease,
  __pubkySharedSessionLoad,
  __pubkySharedSessionStore,
  __pubkySharedSessionRemove,
  __pubkySessionStoreClear,
  __pubkySessionStoreClearAll,
};
const import5 = {
  __pubkyGrantIsDelegationAvailable,
  __pubkyGrantCanUseDelegation,
  __pubkyGrantEnsureDelegatedKey,
  __pubkyGrantLoadDelegatedPublicKey,
  __pubkyGrantDelegatedSign,
};
const import6 = {
  __pubkyRecoveredEncryptionKeys,
  __pubkyImportEncryptionCryptoKey,
};
const import7 = {
  __pubkyGrantIsDelegationAvailable,
  __pubkyGrantCanUseDelegation,
  __pubkyGrantEnsureDelegatedKey,
  __pubkyGrantLoadDelegatedPublicKey,
  __pubkyGrantDelegatedSign,
};

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_67e7344beaa85059: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_c54e7112a3fa7e3e: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___pubkyGrantDelegatedSign_3145fede89a925f4: function(arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            let deferred1_0;
            let deferred1_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                deferred1_0 = arg2;
                deferred1_1 = arg3;
                const ret = __pubkyGrantDelegatedSign(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
                return ret;
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
                wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
            }
        },
        __wbg___pubkyGrantEnsureDelegatedKey_1067334e491ee176: function(arg0, arg1) {
            let v0;
            if (arg0 !== 0) {
                v0 = getStringFromWasm0(arg0, arg1);
                wasm.__wbindgen_free(arg0, arg1 * 1, 1);
            }
            const ret = __pubkyGrantEnsureDelegatedKey(v0);
            return ret;
        },
        __wbg___pubkyGrantLoadDelegatedPublicKey_162cec02a5e4b65f: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                const ret = __pubkyGrantLoadDelegatedPublicKey(getStringFromWasm0(arg0, arg1));
                return ret;
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg___pubkyRecoveredEncryptionKeys_e0395b0e9ce5e379: function(arg0, arg1, arg2, arg3, arg4) {
            const ret = __pubkyRecoveredEncryptionKeys(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), EncryptionKeys.__wrap(arg4));
            return ret;
        },
        __wbg___pubkySessionAcquire_9cbf23c9cb4de2dd: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            const ret = __pubkySessionAcquire(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), arg4 !== 0);
            return ret;
        }, arguments); },
        __wbg___pubkySessionRelease_61113613898f8369: function(arg0) {
            __pubkySessionRelease(arg0 >>> 0);
        },
        __wbg___pubkySessionStoreGet_bf3d995400545463: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                const ret = __pubkySessionStoreGet(getStringFromWasm0(arg0, arg1));
                return ret;
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg___pubkySessionStoreMetadata_1061de6abd5bdda6: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                const ret = __pubkySessionStoreMetadata(getStringFromWasm0(arg0, arg1));
                return ret;
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg___pubkySessionStorePut_a1073209d38242cc: function(arg0, arg1) {
            const ret = __pubkySessionStorePut(arg0, arg1 >>> 0);
            return ret;
        },
        __wbg___pubkySessionWait_21c5e8e3be5de6ff: function(arg0) {
            const ret = __pubkySessionWait(arg0 >>> 0);
            return ret;
        },
        __wbg___pubkySharedSessionLoad_5cd9c74d47bf2afd: function(arg0) {
            const ret = __pubkySharedSessionLoad(arg0 >>> 0);
            return ret;
        },
        __wbg___pubkySharedSessionRemove_56831ee1430cf7ad: function(arg0) {
            const ret = __pubkySharedSessionRemove(arg0 >>> 0);
            return ret;
        },
        __wbg___pubkySharedSessionStore_beb384d555af114b: function(arg0, arg1) {
            const ret = __pubkySharedSessionStore(arg0 >>> 0, arg1);
            return ret;
        },
        __wbg___wbindgen_bigint_get_as_i64_b482365c149396c8: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_7a12af2b3f899c5a: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_0e68cf47c9cbd9b0: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_50072d4d6e45c193: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_60fc0336cb14f5d7: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_fcda5e3902d732fe: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_5160b3e381865372: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_edb6b15aa3afe12e: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_c4f7cb494a2a21f1: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_8c687d0b90d5b524: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_9fdcd3c0a860dd3b: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_3c30021c243b64cd: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_1dc732b810cb937c: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_92ab86bb19cbc12f: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_5d9e815e6fdf150f: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_997e73d32238e655: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_abort_03f8c5804715cb9a: function(arg0, arg1) {
            arg0.abort(arg1);
        },
        __wbg_abort_76dea11221098ae5: function(arg0) {
            arg0.abort();
        },
        __wbg_append_8e87c13f0f08f8cd: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            arg0.append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        }, arguments); },
        __wbg_arrayBuffer_06f3da76f071d37f: function() { return handleError(function (arg0) {
            const ret = arg0.arrayBuffer();
            return ret;
        }, arguments); },
        __wbg_authtoken_new: function(arg0) {
            const ret = AuthToken.__wrap(arg0);
            return ret;
        },
        __wbg_body_9ee03724e9ad0639: function(arg0) {
            const ret = arg0.body;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_buffer_4a989bded7035f57: function(arg0) {
            const ret = arg0.buffer;
            return ret;
        },
        __wbg_byobRequest_f161fc37241dd3d4: function(arg0) {
            const ret = arg0.byobRequest;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_byteLength_0ddb1795e2c7e689: function(arg0) {
            const ret = arg0.byteLength;
            return ret;
        },
        __wbg_byteOffset_46eb015f52b6ad7d: function(arg0) {
            const ret = arg0.byteOffset;
            return ret;
        },
        __wbg_call_269c5566fbede3eb: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_call_6bcf8d3e20937e46: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_cancel_c076350a7e8954be: function(arg0) {
            const ret = arg0.cancel();
            return ret;
        },
        __wbg_catch_e2134ef6dcdb69ed: function(arg0, arg1) {
            const ret = arg0.catch(arg1);
            return ret;
        },
        __wbg_clearTimeout_1daad5c6ee4fcd3b: function(arg0) {
            const ret = clearTimeout(arg0);
            return ret;
        },
        __wbg_close_22882088c136df25: function() { return handleError(function (arg0) {
            arg0.close();
        }, arguments); },
        __wbg_close_8b609460dd26e367: function() { return handleError(function (arg0) {
            arg0.close();
        }, arguments); },
        __wbg_crypto_38df2bab126b63dc: function(arg0) {
            const ret = arg0.crypto;
            return ret;
        },
        __wbg_debug_d6d1b899018fb5ec: function(arg0, arg1, arg2, arg3) {
            console.debug(arg0, arg1, arg2, arg3);
        },
        __wbg_done_cffed884d87aa22e: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_encryptionkeys_new: function(arg0) {
            const ret = EncryptionKeys.__wrap(arg0);
            return ret;
        },
        __wbg_enqueue_6cb545d22db14f33: function() { return handleError(function (arg0, arg1) {
            arg0.enqueue(arg1);
        }, arguments); },
        __wbg_entries_972a87586902cf87: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_entries_f9de04c09a57314e: function(arg0) {
            const ret = arg0.entries();
            return ret;
        },
        __wbg_error_83ae2b0e77197298: function(arg0, arg1, arg2, arg3) {
            console.error(arg0, arg1, arg2, arg3);
        },
        __wbg_event_new: function(arg0) {
            const ret = Event.__wrap(arg0);
            return ret;
        },
        __wbg_fetch_1182c189ace424aa: function(arg0) {
            const ret = fetch(arg0);
            return ret;
        },
        __wbg_fetch_7a37768ab67c5bd8: function(arg0) {
            const ret = fetch(arg0);
            return ret;
        },
        __wbg_fetch_920242d59bac2026: function(arg0, arg1) {
            const ret = arg0.fetch(arg1);
            return ret;
        },
        __wbg_from_a39669ce566077da: function(arg0) {
            const ret = Array.from(arg0);
            return ret;
        },
        __wbg_getRandomValues_436a51d0629d84e1: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getRandomValues_c44a50d8cfdaebeb: function() { return handleError(function (arg0, arg1) {
            arg0.getRandomValues(arg1);
        }, arguments); },
        __wbg_getReader_9facd4f899beac89: function() { return handleError(function (arg0) {
            const ret = arg0.getReader();
            return ret;
        }, arguments); },
        __wbg_get_6cf5a4d4d8ad3c5a: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_989d0a1309644f2b: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_b1f0ab13c737f856: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_done_a668aa62d81fad70: function(arg0) {
            const ret = arg0.done;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg_get_unchecked_363572bdd397d473: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_value_6c62a77c168d825a: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_grantauthflow_new: function(arg0) {
            const ret = GrantAuthFlow.__wrap(arg0);
            return ret;
        },
        __wbg_grantinfo_new: function(arg0) {
            const ret = GrantInfo.__wrap(arg0);
            return ret;
        },
        __wbg_grantsessioninfo_new: function(arg0) {
            const ret = GrantSessionInfo.__wrap(arg0);
            return ret;
        },
        __wbg_has_464f8b9416279d65: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.has(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_headers_2594464ff62969f3: function(arg0) {
            const ret = arg0.headers;
            return ret;
        },
        __wbg_info_01cb0b0ae0fde22f: function(arg0, arg1, arg2, arg3) {
            console.info(arg0, arg1, arg2, arg3);
        },
        __wbg_instanceof_ArrayBuffer_d4ff01f8247925ae: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_CryptoKey_98e09fab6f03bfea: function(arg0) {
            let result;
            try {
                result = arg0 instanceof CryptoKey;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Error_fe6fa771c78ee4cf: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Error;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Headers_b1a833e675bdf12d: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Headers;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_1ff6a2b54c899f0d: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Response_6366a785e400039b: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Response;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_598adc0fef426aa8: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_5674713bb7b79043: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_8f51c743827d1ec5: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_iterator_22ddeb808cf55a6f: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_31bdaf014f5fbde2: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_4e1adc0d42e23620: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_log_d4082f66a52944c3: function(arg0, arg1, arg2, arg3) {
            console.log(arg0, arg1, arg2, arg3);
        },
        __wbg_message_1cbc5bc03dcf1dee: function(arg0) {
            const ret = arg0.message;
            return ret;
        },
        __wbg_msCrypto_bd5a034af96bcba6: function(arg0) {
            const ret = arg0.msCrypto;
            return ret;
        },
        __wbg_new_0afe64b4dc16ab74: function() { return handleError(function () {
            const ret = new Headers();
            return ret;
        }, arguments); },
        __wbg_new_1da3429bc3c4541c: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_8d36e20aa758e411: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_a32a1ab6c6655abe: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_baa0a0207935dd43: function() { return handleError(function () {
            const ret = new AbortController();
            return ret;
        }, arguments); },
        __wbg_new_bebc3f4757acf305: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_ffa92086ea89f79c: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_from_slice_4ee02165f9de919e: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_typed_6f8b0d724fe26c07: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined_______true_(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_with_byte_offset_and_length_492c969e8b5da8a4: function(arg0, arg1, arg2) {
            const ret = new Uint8Array(arg0, arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_new_with_into_underlying_source_a57cfcc7c705351c: function(arg0, arg1) {
            const ret = new ReadableStream(IntoUnderlyingSource2.__wrap(arg0), arg1);
            return ret;
        },
        __wbg_new_with_length_5ffeddb9d9fbb96f: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_new_with_opt_readable_stream_and_init_652b1d60607d75aa: function() { return handleError(function (arg0, arg1) {
            const ret = new Response(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_new_with_str_and_init_2f31a77deda127fd: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = new Request(getStringFromWasm0(arg0, arg1), arg2);
            return ret;
        }, arguments); },
        __wbg_next_95053e306b1c3aed: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_next_f31ecb8646d2c605: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_node_84ea875411254db1: function(arg0) {
            const ret = arg0.node;
            return ret;
        },
        __wbg_now_d1fb6650485d7f3e: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_now_e7c6795a7f81e10f: function(arg0) {
            const ret = arg0.now();
            return ret;
        },
        __wbg_parse_6937a9050adfb0e1: function() { return handleError(function (arg0, arg1) {
            const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
            return ret;
        }, arguments); },
        __wbg_performance_3fcf6e32a7e1ed0a: function(arg0) {
            const ret = arg0.performance;
            return ret;
        },
        __wbg_process_44c7a14e11e9f69e: function(arg0) {
            const ret = arg0.process;
            return ret;
        },
        __wbg_prototypesetcall_ae9f5e7459250748: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_publickey_new: function(arg0) {
            const ret = PublicKey.__wrap(arg0);
            return ret;
        },
        __wbg_queueMicrotask_85c90f6987555d65: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_f6a1fa10b81d1fc0: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_randomFillSync_6c25eac9869eb53c: function() { return handleError(function (arg0, arg1) {
            arg0.randomFillSync(arg1);
        }, arguments); },
        __wbg_read_31091533ffadf971: function(arg0) {
            const ret = arg0.read();
            return ret;
        },
        __wbg_releaseLock_1538945f5f183d9f: function(arg0) {
            arg0.releaseLock();
        },
        __wbg_require_b4edbdcf3e2a1ef0: function() { return handleError(function () {
            const ret = module.require;
            return ret;
        }, arguments); },
        __wbg_resolve_35ec7e0c6af4c82c: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_respond_83a71686e927ca32: function() { return handleError(function (arg0, arg1) {
            arg0.respond(arg1 >>> 0);
        }, arguments); },
        __wbg_session_new: function(arg0) {
            const ret = Session.__wrap(arg0);
            return ret;
        },
        __wbg_setTimeout_b4a9096784635514: function(arg0, arg1) {
            const ret = setTimeout(arg0, arg1);
            return ret;
        },
        __wbg_set_13d25b81ab403f5e: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_5f2ad37e5e02dc7b: function(arg0, arg1, arg2) {
            arg0.set(getArrayU8FromWasm0(arg1, arg2));
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_7923e5ea63b41e6b: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            arg0.set(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        }, arguments); },
        __wbg_set_a377297433dfea63: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_set_bf6dde4923b9b059: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_set_body_f39cee72c74a5b02: function(arg0, arg1) {
            arg0.body = arg1;
        },
        __wbg_set_cache_6e8c35a5ed76edb1: function(arg0, arg1) {
            arg0.cache = __wbindgen_enum_RequestCache[arg1];
        },
        __wbg_set_credentials_bf1d3e014213a571: function(arg0, arg1) {
            arg0.credentials = __wbindgen_enum_RequestCredentials[arg1];
        },
        __wbg_set_headers_31d373f68f28bf76: function(arg0, arg1) {
            arg0.headers = arg1;
        },
        __wbg_set_headers_dfe6a763facd3dcc: function(arg0, arg1) {
            arg0.headers = arg1;
        },
        __wbg_set_high_water_mark_089e3476522036ad: function(arg0, arg1) {
            arg0.highWaterMark = arg1;
        },
        __wbg_set_method_82e6c3c083da0734: function(arg0, arg1, arg2) {
            arg0.method = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_mode_f7e56ed768d0ade0: function(arg0, arg1) {
            arg0.mode = __wbindgen_enum_RequestMode[arg1];
        },
        __wbg_set_name_6e2a5da46a9ae1e7: function(arg0, arg1, arg2) {
            arg0.name = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_referrer_13cf56bbccbb2ceb: function(arg0, arg1, arg2) {
            arg0.referrer = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_referrer_policy_dac1caa6e937479a: function(arg0, arg1) {
            arg0.referrerPolicy = __wbindgen_enum_ReferrerPolicy[arg1];
        },
        __wbg_set_signal_f4b32f40f19786f4: function(arg0, arg1) {
            arg0.signal = arg1;
        },
        __wbg_set_status_74351f5228412c33: function(arg0, arg1) {
            arg0.status = arg1;
        },
        __wbg_set_status_text_c443c5fe14fd551d: function(arg0, arg1, arg2) {
            arg0.statusText = getStringFromWasm0(arg1, arg2);
        },
        __wbg_signal_45367c6c2255877a: function(arg0) {
            const ret = arg0.signal;
            return ret;
        },
        __wbg_static_accessor_GLOBAL_8eb4cd83130a11a0: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_1e7044f654e934db: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_d8b50611246a6d92: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_fd0bc376bf0f8b42: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_status_88ccc72fe7bea621: function(arg0) {
            const ret = arg0.status;
            return ret;
        },
        __wbg_storagelock_new: function(arg0) {
            const ret = StorageLock.__wrap(arg0);
            return ret;
        },
        __wbg_storedsessioninfo_new: function(arg0) {
            const ret = StoredSessionInfo.__wrap(arg0);
            return ret;
        },
        __wbg_stringify_54b3d9b61602aee6: function() { return handleError(function (arg0) {
            const ret = JSON.stringify(arg0);
            return ret;
        }, arguments); },
        __wbg_subarray_1daff70dde20c145: function(arg0, arg1, arg2) {
            const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_text_b00323a194b10fa8: function() { return handleError(function (arg0) {
            const ret = arg0.text();
            return ret;
        }, arguments); },
        __wbg_then_7a850dae4493f353: function(arg0, arg1, arg2) {
            const ret = arg0.then(arg1, arg2);
            return ret;
        },
        __wbg_then_b830475380919203: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_toString_beee8ad71195e063: function(arg0) {
            const ret = arg0.toString();
            return ret;
        },
        __wbg_url_f1948b0d7f881e02: function(arg0, arg1) {
            const ret = arg1.url;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_value_c227f843d21da141: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbg_versions_276b2795b1c6a219: function(arg0) {
            const ret = arg0.versions;
            return ret;
        },
        __wbg_view_d8c7b26e4d4650f1: function(arg0) {
            const ret = arg0.view;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_warn_0dba8b87d6637549: function(arg0, arg1, arg2, arg3) {
            console.warn(arg0, arg1, arg2, arg3);
        },
        __wbindgen_generic_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 123, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_6fb33c0245079662___JsError___true_);
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 281, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue______true_);
            return ret;
        },
        __wbindgen_generic_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 279, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_6fb33c0245079662___convert__closures_____invoke_______true_);
            return ret;
        },
        __wbindgen_generic_0000000000000004: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000005: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000006: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000007: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000008: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_generic_0000000000000009: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1);
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("string")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_generic_000000000000000a: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1);
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(RustStruct { name: "GrantInfo", unique_crate_identifier: "pubky-wasm-7d6e91dad805c24f" }) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_generic_000000000000000b: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1);
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(RustStruct { name: "StoredSessionInfo", unique_crate_identifier: "pubky-wasm-7d6e91dad805c24f" }) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./pubky_bg.js": import0,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline1.js": import1,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline1.js": import2,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline1.js": import3,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline1.js": import4,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline2.js": import5,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline0.js": import6,
        "./snippets/pubky-wasm-7d6e91dad805c24f/inline2.js": import7,
    };
}

function wasm_bindgen_6fb33c0245079662___convert__closures_____invoke_______true_(arg0, arg1) {
    wasm.wasm_bindgen_6fb33c0245079662___convert__closures_____invoke_______true_(arg0, arg1);
}

function wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue______true_(arg0, arg1, arg2) {
    wasm.wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue______true_(arg0, arg1, arg2);
}

function wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_6fb33c0245079662___JsError___true_(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___wasm_bindgen_6fb33c0245079662___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_6fb33c0245079662___JsError___true_(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined_______true_(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen_6fb33c0245079662___convert__closures_____invoke___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined___js_sys_5fd4844d262c835b___Function_fn_wasm_bindgen_6fb33c0245079662___JsValue_____wasm_bindgen_6fb33c0245079662___sys__Undefined_______true_(arg0, arg1, arg2, arg3);
}


const __wbindgen_enum_Level = ["error", "warn", "info", "debug", "trace"];


const __wbindgen_enum_ReadableStreamType = ["bytes"];


const __wbindgen_enum_ReferrerPolicy = ["", "no-referrer", "no-referrer-when-downgrade", "origin", "origin-when-cross-origin", "unsafe-url", "same-origin", "strict-origin", "strict-origin-when-cross-origin"];


const __wbindgen_enum_RequestCache = ["default", "no-store", "reload", "no-cache", "force-cache", "only-if-cached"];


const __wbindgen_enum_RequestCredentials = ["omit", "same-origin", "include"];


const __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];
const AuthFlowFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authflow_free(ptr, 1));
const AuthFlowKindFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authflowkind_free(ptr, 1));
const AuthTokenFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authtoken_free(ptr, 1));
const BrowserSessionStoreFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_browsersessionstore_free(ptr, 1));
const ClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_client_free(ptr, 1));
const CookieSessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cookiesession_free(ptr, 1));
const DirectSignupDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_directsignupdeeplink_free(ptr, 1));
const EncryptionKeysFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_encryptionkeys_free(ptr, 1));
const EventFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_event_free(ptr, 1));
const EventStreamBuilderFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_eventstreambuilder_free(ptr, 1));
const GrantAuthFlowFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_grantauthflow_free(ptr, 1));
const GrantInfoFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_grantinfo_free(ptr, 1));
const GrantManagerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_grantmanager_free(ptr, 1));
const GrantSessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_grantsession_free(ptr, 1));
const GrantSessionInfoFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_grantsessioninfo_free(ptr, 1));
const IntoUnderlyingByteSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingbytesource_free(ptr, 1));
const IntoUnderlyingByteSource2Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingbytesource2_free(ptr, 1));
const IntoUnderlyingSinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsink_free(ptr, 1));
const IntoUnderlyingSink2Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsink2_free(ptr, 1));
const IntoUnderlyingSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsource_free(ptr, 1));
const IntoUnderlyingSource2Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsource2_free(ptr, 1));
const KeypairFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_keypair_free(ptr, 1));
const PkdnsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pkdns_free(ptr, 1));
const PubkyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubky_free(ptr, 1));
const PubkyResourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyresource_free(ptr, 1));
const PublicKeyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publickey_free(ptr, 1));
const PublicStorageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publicstorage_free(ptr, 1));
const SeedExportDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_seedexportdeeplink_free(ptr, 1));
const SessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_session_free(ptr, 1));
const SessionInfoFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sessioninfo_free(ptr, 1));
const SessionStorageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sessionstorage_free(ptr, 1));
const SignerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signer_free(ptr, 1));
const SigninDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signindeeplink_free(ptr, 1));
const SigninGrantDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signingrantdeeplink_free(ptr, 1));
const SignupDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signupdeeplink_free(ptr, 1));
const SignupGrantDeepLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signupgrantdeeplink_free(ptr, 1));
const StorageLockFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_storagelock_free(ptr, 1));
const StoredSessionInfoFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_storedsessioninfo_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/pubky_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasmInstance = new WebAssembly.Instance(wasmModule, __wbg_get_imports());
let wasm = wasmInstance.exports;
wasm.__wbindgen_start();
