/* tslint:disable */
/* eslint-disable */
/**
 * An enum representing the available verbosity levels of the logger.
 */

export type Level = "error" | "warn" | "info" | "debug" | "trace";
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

export type ReadableStreamType = "bytes";

/** Offline recovery result. Check the identity before using the keys. */
export interface RecoveredEncryptionKeys {
    /** Authenticated account public key, encoded as z-base-32. */
    publicKey: string;
    /** Authenticated grant identifier (jti). */
    grantId: string;
    /** Independently owned scoped keys. Call keys.free() when finished. */
    keys: EncryptionKeys;
}



export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
/** Root-signed grant claims. Public keys are z-base-32; times are Unix seconds. */
export interface VerifiedGrantClaims {
    iss: string;
    client_id: string;
    caps: string[];
    cnf: string;
    jti: string;
    iat: number;
    exp: number;
}


/**
 * A union type of all possible machine-readable codes for the `name` property
 * of a {@link PubkyError}.
 *
 * Provides a simplified, actionable set of error categories for developers
 * to handle in their code.
 */
export type PubkyErrorName = "RequestError" | "InvalidInput" | "AuthenticationError" | "PkarrError" | "ClientStateError" | "InternalError";

/**
 * Optional x-callback-url metadata carried by a Pubky deep link.
 *
 * Callback destinations are untrusted navigation hints. Authentication still
 * completes through the encrypted relay.
 */
export interface XCallbackParams {
    /**
     * Human-readable name of the requesting application.
     */
    xSource?: string | null;
    /**
     * Destination to open after successful completion.
     */
    xSuccess?: string | null;
    /**
     * Destination to open after an error.
     */
    xError?: string | null;
    /**
     * Destination to open after user cancellation or timeout.
     */
    xCancel?: string | null;
}

/**
 * Options for starting a grant-backed pubkyauth flow.
 */
export interface GrantAuthFlowOptions {
    /**
     * App identifier shown in the user's grant/session list, typically a domain.
     */
    clientId: string;
    /**
     * Optional HTTP relay base, e.g. `"https://demo.httprelay.io/inbox/"`.
     * Defaults to the default Synonym-hosted relay when omitted.
     */
    relay?: string | null;
    /**
     * Optional return destinations for success, error, and cancellation.
     */
    xCallback?: XCallbackParams | null;
    /**
     * Relay approval format. `signedApprovalV1` delivers keys for approved `e` scopes
     * and rejects bare-grant downgrades.
     * Omitted or `bareGrant` selects a grant without an approval envelope.
     * `signedApprovalV1` sets `af=v1` in the authorization link.
     */
    approvalFormat?: GrantApprovalFormat;
}

/**
 * Options for verifying custom grant proofs.
 */
export interface CustomPopVerificationOptions {
    /**
     * Allow the grant's issue time this many seconds ahead of the local clock.
     * Defaults to 30; zero disables the allowance. Expiry remains strict.
     * Must be an integer between 0 and 4294967295.
     */
    clockSkewSeconds?: number;
}

/**
 * Pkarr Config
 */
export interface PkarrConfig {
    /**
     * The list of relays to access the DHT with.
     */
    relays?: string[];
    /**
     * The timeout for relay HTTP requests in milliseconds.
     * Default is 5000ms.
     */
    requestTimeout?: number;
}

/**
 * Pubky Client Config
 */
export interface PubkyClientConfig {
    /**
     * Configuration on how to access pkarr packets on the mainline DHT.
     */
    pkarr?: PkarrConfig;
    /**
     * Maximum raw HTTP error-body bytes to capture. Defaults to 4096; zero skips the body.
     * UTF-8 decoding can produce up to three times as many bytes of text, plus the
     * truncation marker. This does not cap final message size or total memory use.
     */
    maxErrorBodyBytes?: number;
}

/**
 * Relay payload format understood by the requesting app.
 */
export type GrantApprovalFormat = "bareGrant" | "signedApprovalV1";

/**
 * Represents the standard error structure for all exceptions thrown by the Pubky
 * WASM client.
 *
 * @property name - A machine-readable error code from {@link PubkyErrorName}. Use this for programmatic error handling.
 * @property message - A human-readable, descriptive error message suitable for logging.
 * @property data - An optional payload containing structured context for an error. For a `RequestError`, this may contain an object with the HTTP status code, e.g., `{ statusCode: 404 }`.
 *
 * @example
 * ```typescript
 * try {
 *   await client.signup(...);
 * } catch (e) {
 *   const error = e as PubkyError;
 *   if (
 *     error.name === "RequestError" &&
 *     typeof error.data === "object" &&
 *     error.data !== null &&
 *     "statusCode" in error.data &&
 *     (error.data as { statusCode?: number }).statusCode === 404
 *   ) {
 *     // Handle not found...
 *   }
 * }
 * ```
 */
export interface PubkyError extends Error {
    name: PubkyErrorName;
    message: string;
    data?: unknown;
}

/**
 * Represents the standard error structure for all exceptions thrown by the Pubky
 * WASM client.
 *
 * @property name - A machine-readable error code from {@link PubkyErrorName}. Use this for programmatic error handling.
 * @property message - A human-readable, descriptive error message suitable for logging.
 * @property data - An optional payload containing structured context for an error. For a `RequestError`, this may contain an object with the HTTP status code, e.g., `{ statusCode: 404 }`.
 *
 * @example
 * ```typescript
 * try {
 *   await client.signup(...);
 * } catch (e) {
 *   const error = e as PubkyError;
 *   if (
 *     error.name === 'RequestError' &&
 *     typeof error.data === 'object' &&
 *     error.data !== null &&
 *     'statusCode' in error.data &&
 *     (error.data as { statusCode?: number }).statusCode === 404
 *   ) {
 *     // Handle not found...
 *   }
 * }
 * ```
 */
export interface PubkyError {
    name: PubkyErrorName;
    message: string;
    /**
     * Optional structured context associated with the error.
     */
    data?: unknown;
}

/**
 * Resource metadata returned by `SessionStorage.stats()` and `PublicStorage.stats()`.
 *
 * @typedef {Object} ResourceStats
 * @property {number=} contentLength  Size in bytes.
 * @property {string=} contentType    Media type (e.g. "application/json; charset=utf-8").
 * @property {number=} lastModifiedMs Unix epoch milliseconds.
 * @property {string=} etag           Opaque server ETag for the current version.
 *
 * @example
 * const stats = await pubky.publicStorage.stats(`${user}/pub/app/file.json`);
 * if (stats) {
 *   console.log(stats.contentLength, stats.contentType, stats.lastModifiedMs);
 * }
 *
 * Notes:
 * - `contentLength` equals `getBytes(...).length`.
 * - `etag` may be absent and is opaque; compare values to detect updates.
 * - `lastModifiedMs` increases when the resource is updated.
 */
export interface ResourceStats {
    /**
     * Size in bytes of the stored object.
     */
    contentLength?: number;
    /**
     * Media type of the stored object (e.g., `"application/json"`).
     */
    contentType?: string;
    /**
     * Unix epoch **milliseconds** for the last modification time.
     */
    lastModifiedMs?: number;
    /**
     * Opaque entity tag identifying the current stored version.
     */
    etag?: string;
}

/**
 * Self-contained credentials for offline custom-proof verification.
 * Unknown fields are ignored so future bundles remain readable by older verifiers.
 */
export interface CustomPop {
    /**
     * Original root-signed grant JWS.
     */
    grant: string;
    /**
     * Client-signed custom proof JWS.
     */
    pop: string;
}

/**
 * Verified provenance and data; applications validate the data's meaning.
 */
export interface VerifiedCustomPop {
    /**
     * Root public key encoded as z-base-32.
     */
    identity: string;
    /**
     * Root-signed claims; storage capabilities do not grant service permissions.
     */
    grantClaims: VerifiedGrantClaims;
    /**
     * Unix seconds at which the client signed the proof. No maximum age is enforced.
     */
    iat: number;
    /**
     * Random per-proof value. Record it until grant expiry to detect replays.
     */
    nonce: string;
    /**
     * Signed JSON data, without application-specific validation.
     */
    data: JsonValue;
}

export type Address = `pubky${string}/pub/${string}` | `pubky://${string}/pub/${string}`;

export type CapabilityAction = "r" | "w" | "e" | "rw" | "re" | "we" | "rwe";
export type CapabilityScope = `/${string}`;
export type CapabilityEntry = `${CapabilityScope}:${CapabilityAction}`;
type CapabilitiesTail = `,${CapabilityEntry}${string}`;
export type Capabilities = "" | CapabilityEntry | `${CapabilityEntry}${CapabilitiesTail}`;

export type Path = `/pub/${string}` | `/priv/${string}`;


/**
 * Start and control a pubkyauth authorization flow.
 *
 * Typical flow:
 * 1) `AuthFlow.start(...)` or `pubky.startCookieAuthFlow(...)`
 * 2) Show `authorizationUrl()` as QR/deeplink to the user’s signing device
 * 3) `awaitApproval()` to receive a ready `Session`
 *
 * @deprecated Use `GrantAuthFlow` instead.
 */
export class AuthFlow {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Block until the user approves on their signer device; returns a `Session`.
     *
     * @returns {Promise<Session>}
     * Resolves when approved; rejects on timeout/cancel/network errors.
     *
     * @throws {PubkyError}
     * - `RequestError` if relay/network fails
     * - `AuthenticationError` if approval is denied/invalid
     */
    awaitApproval(): Promise<Session>;
    /**
     * Block until the user approves on their signer device; returns an `AuthToken`.
     *
     * @returns {Promise<AuthToken>}
     * Resolves when approved; rejects on timeout/cancel/network errors.
     *
     * @throws {PubkyError}
     * - `RequestError` if relay/network fails
     */
    awaitToken(): Promise<AuthToken>;
    /**
     * Resume a previously started auth flow from its saved `authorizationUrl` (standalone).
     * Prefer `pubky.resumeCookieAuthFlow()` to reuse a facade client; this creates a default (mainnet) client.
     *
     * Relay messages expire after ~5 minutes; resume is only viable in that window.
     * See `Pubky.resumeCookieAuthFlow()` / `Pubky.startCookieAuthFlow()` for full guidance.
     *
     * **Security:** `authorizationUrl` contains the `client_secret`.
     * Delete it from storage as soon as resume completes or is abandoned.
     *
     * @param {string} authorizationUrl The `pubkyauth://…` URL from a previous flow.
     * @returns {AuthFlow} A flow reconnected to the original relay channel.
     * @throws {PubkyError}
     * - `{ name: "AuthenticationError" }` if the URL is invalid or not a signin/signup link
     *
     * @deprecated Use `GrantAuthFlow.resume(...)` instead.
     */
    static resume(authorization_url: string): AuthFlow;
    /**
     * Start a flow (standalone).
     * Prefer `pubky.startCookieAuthFlow()` to reuse a facade client.
     *
     * @param {string} capabilities
     * Comma-separated capabilities, e.g. `"/pub/app/:rw,/priv/foo.txt:r"`.
     * Each entry must be `"<scope>:<actions>"`, where:
     * - `scope` starts with `/` (e.g. `/pub/example.com/`)
     * - `actions` is any combo of `r` and/or `w` (order is normalized; `wr` -> `rw`)
     * Empty string is allowed (no scopes).
     *
     * @param {AuthFlowKind} kind
     * The kind of authentication flow to perform.
     * This can either be a sign in or a sign up flow.
     * Examples:
     * - `AuthFlowKind.signin()` - Sign in to an existing account.
     * - `AuthFlowKind.signup(homeserverPublicKey, signupToken)` - Sign up for a new account.
     *
     * @param {string} [relay]
     * Optional HTTP relay base, e.g. `"https://demo.httprelay.io/inbox/"`.
     * Defaults to the default Synonym-hosted relay when omitted.
     *
     * @param {XCallbackParams} [xCallback]
     * Optional return destinations for success, error, and cancellation.
     *
     * @returns {AuthFlow}
     * A running auth flow. Call `authorizationUrl()` to show the deep link,
     * then `awaitApproval()` to receive a `Session`.
     * @throws {PubkyError}
     * - `{ name: "InvalidInput", message: string }` if any capability entry is invalid
     *     or for an invalid relay URL.
     * @example
     * const flow = AuthFlow.start("/pub/my-cool-app/:rw,/pub/pubky.app/:w");
     * renderQRCode(flow.authorizationUrl());
     * const session = await flow.awaitApproval();
     *
     * @deprecated Use `GrantAuthFlow.start(...)` instead.
     */
    static start(capabilities: Capabilities, kind: AuthFlowKind, relay?: string | null, x_callback?: XCallbackParams | null): AuthFlow;
    /**
     * Non-blocking single poll step (advanced UIs).
     *
     * @returns {Promise<Session|undefined>} A session if the approval arrived, otherwise `undefined`.
     */
    tryPollOnce(): Promise<Session | undefined>;
    /**
     * Return the authorization deep link (URL) to show as QR or open on the signer device.
     *
     * **Security:** This URL contains the `client_secret` in plaintext.
     * Treat it as a short-lived secret and delete it after the flow completes.
     * See `Pubky.startCookieAuthFlow()` docs for storage guidance.
     *
     * @returns {string} A `pubkyauth://…` or `https://…` URL with channel info.
     *
     * @example
     * renderQr(flow.authorizationUrl);
     */
    readonly authorizationUrl: string;
}

/**
 * The kind of authentication flow to perform.
 * This can either be a sign in or a sign up flow.
 */
export class AuthFlowKind {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a sign in flow.
     */
    static signin(): AuthFlowKind;
    /**
     * Create a sign up flow.
     * # Arguments
     * * `homeserver_public_key` - The public key of the homeserver to sign up on.
     * * `signup_token` - The signup token to use for the signup flow. This is optional.
     */
    static signup(homeserver_public_key: PublicKey, signup_token?: string | null): AuthFlowKind;
    /**
     * Get the intent of the authentication flow.
     * # Returns
     * * `"signin"` - If the authentication flow is a sign in flow.
     * * `"signup"` - If the authentication flow is a sign up flow.
     */
    readonly intent: string;
}

/**
 * AuthToken: signed, time-bound proof of key ownership.
 *
 * Returned by [`AuthFlow.awaitToken()`] on the 3rd-party app side when doing **authentication-only**
 * flows (no homeserver session). You can inspect who authenticated and which capabilities were
 * requested, or serialize the token and send it to a backend to verify.
 *
 * ### Typical usage
 * ```js
 * // Start an auth-only flow (no capabilities)
 * const flow = pubky.startCookieAuthFlow("", relay);
 *
 * // Wait for the signer to approve; returns an AuthToken
 * const token = await flow.awaitToken();
 *
 * // Identify the user
 * console.log(token.publicKey().toString());
 *
 * // Optionally forward to a server for verification:
 * await fetch("/api/verify", { method: "POST", body: token.toBytes() });
 * ```
 *
 * ### Binary format
 * `AuthToken` serializes to a canonical binary (postcard) form; use [`AuthToken.toBytes()`] to get a
 * `Uint8Array`, and [`AuthToken.verify()`] to parse + verify on the server.
 */
export class AuthToken {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Deserialize an `AuthToken` **without** verification.
     *
     * Most apps should call [`AuthToken.verify()`]. This is provided for tooling or diagnostics
     * where you want to inspect the structure first.
     *
     * Throws if the bytes cannot be parsed as a valid serialized token.
     */
    static fromBytes(bytes: Uint8Array): AuthToken;
    /**
     * Serialize the token to a `Uint8Array` in its **canonical** (postcard) binary format.
     *
     * Use this to send the token to a backend for verification.
     *
     * ```js
     * const bytes = token.toBytes();
     * await fetch("/api/verify", { method: "POST", body: bytes });
     * ```
     */
    toBytes(): Uint8Array;
    /**
     * Parse and verify an `AuthToken` from its canonical bytes.
     *
     * - Verifies version, timestamp freshness window, and signature.
     * - Throws on invalid/expired/unknown version.
     *
     * Use this on your server after receiving `Uint8Array` from the client.
     *
     * ```js
     * import { AuthToken } from "@synonymdev/pubky";
     *
     * export async function POST(req) {
     *   const bytes = new Uint8Array(await req.arrayBuffer());
     *   const token = AuthToken.verify(bytes); // throws on failure
     *   return new Response(token.publicKey().toString(), { status: 200 });
     * }
     * ```
     */
    static verify(bytes: Uint8Array): AuthToken;
    /**
     * Returns the **capabilities** requested by the flow at the time this token was signed.
     *
     * Most auth-only flows pass an empty string to `startCookieAuthFlow("", relay)`, so this will
     * commonly be an empty array.
     *
     * Returns: `string[]`, where each item is the canonical entry `"<scope>:<actions>"`.
     *
     * Example entry: `"/pub/my-cool-app/:rw"`
     */
    readonly capabilities: string[];
    /**
     * Returns the **public key** that authenticated with this token.
     *
     * Use `.toString()` on the returned `PublicKey` to get the `pubky<z32>` identifier.
     * Call `.z32()` when you specifically need the raw z-base32 value (e.g. hostnames).
     *
     * @example
     * const who = token.publicKey.toString();
     */
    readonly publicKey: PublicKey;
}

/**
 * Browser-backed durable store for completed grant sessions.
 */
export class BrowserSessionStore {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Clear all browser auth persistence owned by this SDK origin.
     *
     * This removes all stored session records and all browser-held delegated
     * grant keys, including keys for pending delegated grant flows. Saved
     * delegated flow state becomes unrestorable. This does not revoke remote
     * grants. Browser-managed handles stop working when their saved record is removed.
     */
    clearAll(): Promise<void>;
    /**
     * Clear all local stored session records for this origin.
     *
     * Delegated keys referenced by those stored session records are removed.
     * Delegated keys that only belong to pending grant flows are preserved.
     */
    clear(): Promise<void>;
    /**
     * Whether IndexedDB and Web Locks are available.
     */
    isAvailable(): Promise<boolean>;
    /**
     * List all locally stored sessions for this origin.
     */
    list(): Promise<StoredSessionInfo[]>;
    /**
     * Remove local stored session metadata and any SDK-owned delegated key for that record.
     */
    remove(id: string): Promise<void>;
    /**
     * Recover a stored session's encryption keys without network access.
     * Verifies the signed approval, exact grant binding, and requested session
     * identity. Works after grant expiry/revocation and without the delegated
     * WebCrypto signing key.
     * Restore material is stored as plaintext in IndexedDB.
     * Bare-grant records return undefined; signed approvals without `e` scopes
     * return an empty bundle. Creates no session.
     */
    restoreEncryptionKeys(id: string): Promise<EncryptionKeys | undefined>;
    /**
     * Restore a specific stored session by id.
     *
     * Shares one bearer with other tabs on this origin. Requires IndexedDB and
     * Web Locks in a secure browser context.
     */
    restore(id: string): Promise<Session>;
    /**
     * Persist a completed grant session and its optional signed approval.
     * Confidential restore material is stored as plaintext in IndexedDB.
     * Delegated signing keys remain non-extractable WebCrypto keys.
     * Records are identified by user and grant ID. Reauthorizing the same
     * client creates a separate record; use the returned ID to restore it.
     */
    save(session: Session): Promise<StoredSessionInfo>;
}

/**
 * Low-level HTTP bridge used by the Pubky facade and actors.
 *
 * - Supports `http(s)://` URLs targeting Pubky or ICANN hosts.
 * - In browsers/undici, passes `credentials: "include"` to send cookies.
 */
export class Client {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Perform a raw fetch. Works with `http(s)://` URLs.
     *
     * @param {string} url
     * @param {RequestInit} init Standard fetch options; `credentials: "include"` recommended for session I/O.
     * @returns {Promise<Response>}
     *
     * @example
     * const client = pubky.client;
     * const res = await client.fetch(`https://_pubky.${user}/storage/${user}/pub/app/file.txt`, { method: "PUT", body: "hi", credentials: "include" });
     */
    fetch(url: string, init?: RequestInit | null): Promise<Response>;
    /**
     * Create a Pubky HTTP client.
     *
     * @param {PubkyClientConfig} [config]
     * Optional error-body limit and PKARR overrides:
     * `{ maxErrorBodyBytes?: number, pkarr?: { relays?: string[], requestTimeout?: number } }`.
     *
     * @returns {Client}
     * A configured low-level client. Prefer `new Pubky().client` unless you
     * need custom relays, timeouts or error-body limits.
     *
     * @throws {InvalidInput}
     * If a relay URL is invalid or the error-body limit is not an integer in 0..=4294967295.
     *
     * @example
     * const client = new Client({
     *   maxErrorBodyBytes: 1024,
     *   pkarr: { relays: ["https://relay1/","https://relay2/"], requestTimeout: 8000 }
     * });
     * const pubky = Pubky.withClient(client);
     */
    constructor(config_opt?: PubkyClientConfig | null);
    /**
     * Create a client wired for **local testnet**.
     *
     * Configures PKARR relays for the testnet and remembers the hostname for WASM `_pubky` mapping.
     *
     * @param {string} [host="localhost"]
     * Testnet hostname or IP.
     *
     * @returns {Client}
     * A client ready to talk to your local testnet.
     *
     * @example
     * const client = Client.testnet();           // localhost
     * const pubky  = Pubky.withClient(client);
     *
     * @example
     * const client = Client.testnet("docker0");  // custom host
     */
    static testnet(host?: string | null): Client;
}

/**
 * Cookie-only view over a cookie-backed `Session`.
 *
 * New applications should use `session.grant` and `GrantSession`.
 *
 * @deprecated Use `GrantSession` instead.
 */
export class CookieSession {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Export the cookie secret needed to restore this cookie session.
     *
     * This is available when the SDK captured the cookie secret, such as in
     * Node.js. Browser sessions cannot read HTTP-only Set-Cookie values.
     *
     * @returns {Promise<string>}
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     */
    exportSecret(): Promise<string>;
    /**
     * Export session metadata for legacy cookie restore.
     *
     * The returned string contains no secrets; the browser cookie jar must
     * still hold the HTTP-only cookie.
     *
     * @returns {string}
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     */
    export(): string;
}

/**
 * Parsed direct signup deeplink.
 */
export class DirectSignupDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Parse a direct signup deeplink URL.
     */
    static parse(url: string): DirectSignupDeepLink;
    toString(): string;
    /**
     * Homeserver public key requested for account creation.
     */
    readonly homeserver: PublicKey;
    /**
     * Optional signup token included in the request.
     */
    readonly signupToken: string | undefined;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

/**
 * Verified scoped encryption keys obtained from a session or offline recovery.
 * This object owns its secrets independently of the session and grants no storage
 * access. Call `free()` when finished; secret bytes are zeroized on free/drop.
 */
export class EncryptionKeys {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Derive a non-extractable AES-GCM-256 key for WebCrypto encryption/decryption.
     * Rejects directories and files outside approved scopes. Requires WebCrypto.
     * Temporary JS key bytes are cleared after import, including on failure.
     */
    deriveCryptoKeyForPath(path: string): Promise<CryptoKey>;
    /**
     * Derive a 32-byte content key for a canonical decoded file path.
     * Rejects directories and files outside the approved scopes. The caller
     * owns the JS byte copy and should clear it after use.
     */
    deriveForPath(path: string): Uint8Array;
    /**
     * Recover authenticated identity and keys from an exportLocalSecret() token offline.
     * Verifies the signed approval and grant binding even if the grant expired
     * or was revoked. Bare-grant tokens return undefined; signed approvals
     * without `e` scopes return a result with an empty key bundle.
     * Check publicKey (z-base-32) against the expected account and grantId
     * against the expected grant before using keys. Call keys.free() when done.
     */
    static fromLocalSecret(token: string): RecoveredEncryptionKeys | undefined;
    /**
     * Approved scopes; directory scopes cover descendant files.
     */
    readonly scopes: string[];
}

/**
 * A single event from the event stream.
 *
 * @example
 * ```typescript
 * for await (const event of stream) {
 *   console.log(event.eventType);  // "PUT" or "DEL"
 *   console.log(event.cursor);     // cursor string for pagination
 *
 *   if (event.eventType === "PUT") {
 *     console.log("Hash:", event.contentHash);
 *   }
 *
 *   // Access resource details
 *   console.log(event.resource.owner.z32()); // User's public key
 *   console.log(event.resource.path);        // "/pub/example.txt"
 *   console.log(event.resource.toPubkyUrl()); // Full pubky:// URL
 * }
 * ```
 */
export class Event {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get the content hash (only for PUT events).
     * Returns the blake3 hash in base64 format, or undefined for DELETE events.
     */
    readonly contentHash: string | undefined;
    /**
     * Get the cursor for pagination.
     */
    readonly cursor: string;
    /**
     * Get the event type ("PUT" or "DEL").
     */
    readonly eventType: string;
    /**
     * Get the resource that was created, updated, or deleted.
     */
    readonly resource: PubkyResource;
}

/**
 * Builder for creating an event stream subscription.
 *
 * Construct via `Pubky.eventStreamForUser()` or `Pubky.eventStreamFor()`.
 * Configuration methods consume this builder unless documented otherwise.
 *
 * @example
 * ```typescript
 * const stream = await pubky.eventStreamForUser(userPubkey, null)
 *   .live()
 *   .limit(100)
 *   .path("/pub/")
 *   .subscribe();
 *
 * for await (const event of stream) {
 *   console.log(event.eventType, event.resource.path);
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Private events: attach a session and request a `/priv/...` path.
 * const stream = await pubky.eventStreamForUser(userPubkey, null)
 *   .session(session)
 *   .path("/priv/app/")
 *   .subscribe();
 * ```
 */
export class EventStreamBuilder {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Add multiple users to the event stream subscription at once.
     *
     * Each user can have an independent cursor position. If a user already exists,
     * their cursor value is overwritten.
     * Updates this builder and returns a copy for chaining. Rejected input
     * leaves this builder unchanged.
     *
     * @param {Array<[string, string | null]>} users - Array of [z32PublicKey, cursor] tuples
     * @returns {EventStreamBuilder} - Builder for chaining
     * @throws {Error} - If total users would exceed 50 or if any cursor/pubkey is invalid
     *
     * @example
     * ```typescript
     * const users: [string, string | null][] = [
     *   [user1.z32(), null],
     *   [user2.z32(), "100"],
     * ];
     * const stream = await pubky.eventStreamFor(homeserver)
     *   .addUsers(users)
     *   .live()
     *   .subscribe();
     * ```
     */
    addUsers(users: Array<any>): EventStreamBuilder;
    /**
     * Set maximum number of events to receive before closing the connection.
     *
     * If omitted:
     * - With `live=false`: sends all historical events, then closes
     * - With `live=true`: sends all historical events, then enters live mode (infinite stream)
     *
     * @param {number} limit - Maximum number of events (1-65535)
     * @returns {EventStreamBuilder} - Builder for chaining
     */
    limit(limit: number): EventStreamBuilder;
    /**
     * Enable live streaming mode.
     *
     * When called, the stream will:
     * 1. First deliver all historical events (oldest first)
     * 2. Then remain open to stream new events as they occur in real-time
     *
     * Without this flag (default): Stream only delivers historical events and closes.
     *
     * **Note**: Cannot be combined with `reverse()`.
     *
     * ## Cleanup
     * To stop a live stream, use the reader's `cancel()` method:
     * ```typescript
     * const stream = await pubky.eventStreamForUser(user, null).live().subscribe();
     * const reader = stream.getReader();
     *
     * while (true) {
     *   const { done, value } = await reader.read();
     *   if (shouldStop) {
     *     await reader.cancel(); // Closes the connection
     *     break;
     *   }
     * }
     * ```
     *
     * @returns {EventStreamBuilder} - Builder for chaining
     */
    live(): EventStreamBuilder;
    /**
     * Set a client-side byte limit for SSE payloads. Unbounded by default.
     * Limits accumulated data (including newlines joining data fields), each
     * event name, and each ID separately in historical and live streams.
     * Comments, unknown fields and framing bytes are excluded.
     * There is no total block or stream byte limit.
     * Overflow cancels the response and errors the ReadableStream.
     * Updates this builder and returns a copy for chaining. Rejected input
     * leaves this builder unchanged.
     *
     * @param {number} limit - Integer in 1..=4294967295.
     * @throws {InvalidInput} If the limit is not a positive 32-bit integer.
     */
    maxEventBytes(limit: number): EventStreamBuilder;
    /**
     * Filter events by path. Call once per path to receive the
     * union of several scopes (e.g. `/pub/` plus a private `/priv/app/`).
     *
     * Format: a path WITHOUT the `pubky://` scheme or user pubkey. A trailing
     * slash matches a directory and all its descendants (`/pub/files/`); no
     * trailing slash matches an exact file (`/pub/notes.txt`).
     *
     * Private (`/priv/...`) paths require a session attached via `session()`;
     * without one the homeserver rejects the subscription with 401.
     *
     * @param {string} path - Path filter (repeatable)
     * @returns {EventStreamBuilder} - Builder for chaining
     */
    path(path: string): EventStreamBuilder;
    /**
     * Return events in reverse chronological order (newest first).
     *
     * When called, events are delivered from newest to oldest, then the stream closes.
     *
     * Without this flag (default): Events are delivered oldest first.
     *
     * **Note**: Cannot be combined with `live()`.
     *
     * @returns {EventStreamBuilder} - Builder for chaining
     */
    reverse(): EventStreamBuilder;
    /**
     * Authenticate the subscription with a user `Session`.
     *
     * Required to receive private (`/priv/...`) events: the session credential
     * (grant or cookie) is attached so the homeserver can authorize each private
     * `path()` against the session's read capabilities. Public subscriptions
     * don't need this.
     *
     *
     * @param {Session} session - The authenticated session
     * @returns {EventStreamBuilder} - Builder for chaining
     */
    session(session: Session): EventStreamBuilder;
    /**
     * Subscribe to the event stream.
     *
     * This performs the following steps:
     * 1. Resolves the user's homeserver via DHT/PKDNS
     * 2. Constructs the `/events-stream` URL with query parameters
     * 3. Makes the HTTP request
     * 4. Returns a Web ReadableStream of parsed events
     *
     * @returns {Promise<ReadableStream>} - A Web ReadableStream that yields Event objects
     *
     * @throws {PubkyError}
     * - `{ name: "RequestError" }` if the homeserver cannot be resolved
     * - `{ name: "ValidationError" }` if `live=true` and `reverse=true` (invalid combination)
     * - Propagates HTTP request errors
     *
     * @example
     * ```typescript
     * const stream = await builder.subscribe();
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     */
    subscribe(): Promise<ReadableStream>;
}

/**
 * Start and control a grant-backed pubkyauth authorization flow.
 *
 * Typical flow:
 * 1) `GrantAuthFlow.start(...)` or `pubky.startGrantAuthFlow(...)`
 * 2) Show `authorizationUrl()` as QR/deeplink to the user's signing device
 * 3) `awaitApproval()` to receive a grant-backed, self-refreshing `Session`
 */
export class GrantAuthFlow {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Block until the user approves on their signer device; returns a grant-backed `Session`.
     */
    awaitApproval(): Promise<Session>;
    /**
     * Resume a previously saved pending delegated grant auth flow.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. The saved `keyId` must still
     * exist in IndexedDB for the same origin. Unsupported runtimes reject with
     * `ClientStateError`.
     */
    static resumeDelegated(saved_state: string): Promise<GrantAuthFlow>;
    /**
     * Resume a previously saved pending grant auth flow (standalone).
     * Prefer `pubky.resumeGrantAuthFlow()` to reuse a facade client.
     *
     * **Security:** `savedState` contains the relay secret and PoP client private key.
     * Store it only temporarily and delete it once the flow completes or is abandoned.
     *
     * @param {string} savedState A string produced by `grantFlow.saveLocal()`.
     * @returns {GrantAuthFlow} A flow reconnected to the original relay channel.
     */
    static resume(saved_state: string): GrantAuthFlow;
    /**
     * Save sensitive state required to resume this delegated pending grant flow.
     *
     * This does not export the delegated private key, but it includes the relay
     * secret in the authorization URL. Store it only temporarily and delete it
     * once the flow completes or is abandoned.
     */
    saveDelegated(): string;
    /**
     * Save sensitive state required to resume this pending local grant flow.
     *
     * @returns {string} Opaque state for `GrantAuthFlow.resume()` or
     * `pubky.resumeGrantAuthFlow()`.
     */
    saveLocal(): string;
    /**
     * Start a browser delegated grant-backed flow.
     *
     * The SDK creates a fresh non-extractable WebCrypto Ed25519 key in
     * IndexedDB and uses that key for grant Proof-of-Possession signing.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. Unsupported runtimes reject
     * with `ClientStateError`.
     */
    static startDelegated(capabilities: Capabilities, kind: AuthFlowKind, options: GrantAuthFlowOptions): Promise<GrantAuthFlow>;
    /**
     * Start a grant-backed flow with a new DHT client.
     * Prefer `pubky.startGrantAuthFlow()` to reuse a facade DHT client.
     *
     * @param {string} capabilities
     * Comma-separated capabilities, e.g. `"/pub/app/:rw,/priv/foo.txt:r"`.
     * Empty string is allowed (no scopes).
     *
     * @param {AuthFlowKind} kind
     * The kind of authentication flow to perform.
     *
     * @param {GrantAuthFlowOptions} options
     * Options for the grant flow: `{ clientId, relay?, xCallback? }`.
     *
     * @returns {GrantAuthFlow}
     * A running grant auth flow. Call `authorizationUrl()` to show the deep link,
     * then `awaitApproval()` to receive a grant-backed `Session`.
     */
    static start(capabilities: Capabilities, kind: AuthFlowKind, options: GrantAuthFlowOptions): GrantAuthFlow;
    /**
     * Non-blocking single poll step (advanced UIs).
     *
     * @returns {Promise<Session|undefined>} A session if the approval arrived, otherwise `undefined`.
     */
    tryPollOnce(): Promise<Session | undefined>;
    /**
     * Return the authorization deep link (URL) to show as QR or open on the signer device.
     */
    readonly authorizationUrl: string;
    /**
     * Whether delegated grant auth is available in the current JS runtime.
     *
     * This checks for a secure browser context with WebCrypto `crypto.subtle`
     * and IndexedDB. It is a coarse synchronous feature-detection helper only;
     * some runtimes expose those primitives without Ed25519 support.
     */
    static readonly isDelegationAvailable: boolean;
}

/**
 * Summary of an active grant returned by `GrantManager.list()`.
 */
export class GrantInfo {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Comma-separated capabilities authorized by the grant.
     */
    readonly capabilities: string;
    /**
     * Application identifier.
     */
    readonly clientId: string;
    /**
     * Expiry timestamp, in Unix seconds.
     */
    readonly expiresAt: number;
    /**
     * Grant identifier used for revocation.
     */
    readonly grantId: string;
    /**
     * Issued-at timestamp, in Unix seconds.
     */
    readonly issuedAt: number;
}

/**
 * Account-level grant management for a signed-in user.
 */
export class GrantManager {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * List all active grants for this user.
     *
     * Requires a root-capability session. Non-root sessions surface the
     * homeserver `403` as the standard request error.
     *
     * @returns {Promise<GrantInfo[]>}
     */
    list(): Promise<GrantInfo[]>;
    /**
     * Create a grant manager authenticated by a session.
     *
     * @param {Session} session
     * @returns {GrantManager}
     */
    constructor(session: Session);
    /**
     * Revoke a specific grant by id.
     *
     * Requires a root-capability session. Malformed ids throw
     * `InvalidInput`.
     *
     * @param {string} grantId
     * @returns {Promise<void>}
     */
    revoke(grant_id: string): Promise<void>;
}

/**
 * Grant-only view over a grant-backed `Session`.
 *
 * Cookie-backed sessions do not expose this view; use `session.grant` and
 * check for `undefined` before calling grant-session methods.
 */
export class GrantSession {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Sign JSON data and return both the custom proof and its root-signed grant.
     * Data follows `JSON.stringify` semantics, e.g. `undefined` properties are omitted.
     * Each proof carries its signing time (`iat`) and a random `nonce`.
     * Makes no network requests. Your applications handle freshness and replay protection.
     */
    createCustomPop(data: JsonValue): Promise<CustomPop>;
    /**
     * Export the portable local secret material needed to restore this grant session.
     *
     * Treat the returned string as bearer-equivalent secret material until the
     * grant expires or is revoked. Included scoped keys remain sensitive after
     * expiry or revocation.
     *
     * @returns {Promise<string>}
     */
    exportLocalSecret(): Promise<string>;
    /**
     * Current grant id (`jti`) backing this session.
     *
     * @returns {Promise<string>}
     */
    grantId(): Promise<string>;
    /**
     * Full grant session metadata.
     *
     * @returns {Promise<GrantSessionInfo>}
     */
    sessionInfo(): Promise<GrantSessionInfo>;
    /**
     * Return scoped keys with the same derivation API as offline recovered keys.
     * Bare grants return `undefined`; signed approvals without `e` scopes
     * return an object with empty scopes.
     * Each access creates an owned copy. Keep it for repeated use and call
     * `free()` when finished. It remains usable after this view or its session
     * is freed, signed out, or revoked; freeing it does not affect the session.
     */
    readonly encryptionKeys: EncryptionKeys | undefined;
}

/**
 * Grant-specific session metadata returned by `grant.sessionInfo()`.
 */
export class GrantSessionInfo {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Authorized capabilities for this session.
     */
    readonly capabilities: string[];
    /**
     * Application identifier.
     */
    readonly clientId: string;
    /**
     * Session creation timestamp, in Unix seconds.
     */
    readonly createdAt: number;
    /**
     * Underlying grant expiry timestamp, in Unix seconds.
     */
    readonly grantExpiresAt: number;
    /**
     * Grant id this session was minted from.
     */
    readonly grantId: string;
    /**
     * Homeserver that issued this session.
     */
    readonly homeserver: PublicKey;
    /**
     * User public key for this session.
     */
    readonly publicKey: PublicKey;
    /**
     * Bearer token expiry timestamp, in Unix seconds.
     */
    readonly tokenExpiresAt: number;
}

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

declare class IntoUnderlyingByteSource2 {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}
export type { IntoUnderlyingByteSource2 };

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

declare class IntoUnderlyingSink2 {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}
export type { IntoUnderlyingSink2 };

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

declare class IntoUnderlyingSource2 {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}
export type { IntoUnderlyingSource2 };

export class Keypair {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a recovery file for this keypair (encrypted with the given passphrase).
     */
    createRecoveryFile(passphrase: string): Uint8Array;
    /**
     * Decrypt a recovery file and return a Keypair (decrypted with the given passphrase).
     */
    static fromRecoveryFile(recovery_file: Uint8Array, passphrase: string): Keypair;
    /**
     * Generate a [Keypair] from a 32-byte secret.
     */
    static fromSecret(secret: Uint8Array): Keypair;
    /**
     * Generate a random [Keypair]
     */
    static random(): Keypair;
    /**
     * Returns the secret of this keypair.
     */
    secret(): Uint8Array;
    /**
     * Returns the [PublicKey] of this keypair.
     *
     * Use `.toString()` on the returned `PublicKey` to get the string form
     * or `.z32()` to get the z32 string form without prefix.
     * Transport/storage (query params, headers, persistence) should use `.z32()`.
     *
     * @example
     * const who = keypair.publicKey.toString();
     */
    readonly publicKey: PublicKey;
}

/**
 * Resolve/publish `_pubky` PKDNS records (homeserver pointers).
 */
export class Pkdns {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * PKDNS actor with publishing enabled (requires a keypair).
     */
    static fromKeypair(keypair: Keypair): Pkdns;
    /**
     * Resolve the homeserver for a given public key (read-only).
     *
     * @param {PublicKey} user
     * @returns {Promise<PublicKey|undefined>} Homeserver public key, or `undefined` when the
     *   user has no resolvable homeserver record.
     * @throws When Pkarr resolution fails or a resolved `_pubky` target is malformed.
     */
    getHomeserverOf(pubky: PublicKey): Promise<PublicKey | undefined>;
    /**
     * Resolve the homeserver for **this** user (requires keypair).
     *
     * @returns {Promise<PublicKey|undefined>} Homeserver public key or `undefined` if not found.
     * @throws When no keypair is attached, Pkarr resolution fails, or a resolved `_pubky` target
     *   is malformed.
     */
    getHomeserver(): Promise<PublicKey | undefined>;
    /**
     * Read-only PKDNS actor (no keypair; resolve only).
     */
    constructor();
    /**
     * Force publish homeserver immediately (even if fresh).
     *
     * Requires keypair or to be signer bound.
     *
     * @param {PublicKey=} overrideHost Optional new homeserver to publish (migration).
     * @returns {Promise<void>}
     */
    publishHomeserverForce(host_override?: PublicKey | null): Promise<void>;
    /**
     * Republish homeserver if record is missing/stale.
     *
     * Requires keypair or to be signer bound.
     *
     * @param {PublicKey=} overrideHost Optional new homeserver to publish (migration).
     * @returns {Promise<void>}
     */
    publishHomeserverIfStale(host_override?: PublicKey | null): Promise<void>;
}

/**
 * High-level entrypoint to the Pubky SDK.
 */
export class Pubky {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create an event stream builder for a single user.
     *
     * This is the simplest way to subscribe to events for one user. The homeserver
     * is automatically resolved from the user's Pkarr record.
     *
     * @param {PublicKey} user - The user's public key
     * @param {string | null} cursor - Optional cursor position to start from
     * @returns {EventStreamBuilder} - Builder for configuring and subscribing to the stream
     *
     * @example
     * ```typescript
     * const user = PublicKey.from("o1gg96ewuojmopcjbz8895478wdtxtzzuxnfjjz8o8e77csa1ngo");
     * const stream = await pubky.eventStreamForUser(user, null)
     *   .live()
     *   .subscribe();
     *
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     */
    eventStreamForUser(user: PublicKey, cursor?: string | null): EventStreamBuilder;
    /**
     * Create an event stream builder for a specific homeserver.
     *
     * Use this when you already know the homeserver pubkey. This avoids
     * Pkarr resolution overhead. Obtain a homeserver pubkey via `getHomeserverOf()`.
     *
     * @param {PublicKey} homeserver - The homeserver public key
     * @returns {EventStreamBuilder} - Builder for configuring and subscribing to the stream
     *
     * @example
     * ```typescript
     * const homeserver = await pubky.getHomeserverOf(user1);
     * const stream = await pubky.eventStreamFor(homeserver)
     *   .addUsers([[user1.z32(), null], [user2.z32(), null]])
     *   .live()
     *   .subscribe();
     *
     * for await (const event of stream) {
     *   console.log(`${event.eventType}: ${event.resource.path}`);
     * }
     * ```
     */
    eventStreamFor(homeserver: PublicKey): EventStreamBuilder;
    /**
     * Resolve the homeserver for a given public key (read-only).
     *
     * Uses an internal read-only Pkdns actor.
     *
     * @param {PublicKey} user
     * @returns {Promise<PublicKey|undefined>} Homeserver public key, or `undefined` when the
     *   user has no resolvable homeserver record.
     * @throws When Pkarr resolution fails or a resolved `_pubky` target is malformed.
     */
    getHomeserverOf(user_public_key: PublicKey): Promise<PublicKey | undefined>;
    /**
     * Create a Pubky facade wired for **mainnet** defaults (public relays).
     *
     * Prefer to instantiate only once and use trough your application a single shared `Pubky`
     * instead of constructing one per request. This avoids reinitializing transports and keeps
     * the same client available for repeated usage.
     *
     * @returns {Pubky}
     * A new facade instance. Use this to create signers, start auth flows, etc.
     *
     * @example
     * const pubky = new Pubky();
     * const signer = pubky.signer(Keypair.random());
     */
    constructor();
    /**
     * Restore a session from a previously exported token or snapshot, using this instance's client.
     *
     * Accepts grant secret tokens from `session.exportLocalSecret()` and legacy cookie
     * secret tokens. Also accepts legacy cookie metadata snapshots from `session.export()`.
     * Grant restore mints a fresh short-lived bearer.
     *
     * @param {string} exported A string produced by `session.exportLocalSecret()` or legacy `session.export()`.
     * @returns {Promise<Session>}
     * A rehydrated session bound to this SDK's HTTP client.
     *
     * @example
     * const restored = await pubky.restoreSession(localStorage.getItem("pubky-session")!);
     */
    restoreSession(exported: string): Promise<Session>;
    /**
     * Resume a previously started **pubkyauth** flow from its saved `authorizationUrl`.
     *
     * If the user refreshes or navigates away mid-flow, WASM memory is lost and
     * the original `AuthFlow` object is gone. You can reconnect to the same relay
     * channel by saving the `authorizationUrl` beforehand and calling this method
     * after reload.
     *
     * The relay inbox retains messages for **~5 minutes**. Resume is only
     * viable within that window; afterwards start a fresh flow.
     *
     * **Security:** The URL contains the `client_secret` in plaintext.
     * Store it in `sessionStorage` (scoped to the tab), **not** `localStorage`,
     * and delete it as soon as the resumed flow completes or is abandoned.
     * See `startCookieAuthFlow()` docs for full storage guidance.
     *
     * @param {string} authorizationUrl The `pubkyauth://…` URL from a previous flow.
     * @returns {AuthFlow} A flow reconnected to the original relay channel.
     * @throws {PubkyError}
     * - `{ name: "AuthenticationError" }` if the URL is invalid or not a signin/signup link
     * - `{ name: "RequestError" }` on network/relay failure
     *
     * @example
     * // 1) Before a potential refresh, persist the URL.
     * const flow = pubky.startCookieAuthFlow("/pub/my-cool-app/:rw", AuthFlowKind.signin());
     * sessionStorage.setItem("pubky-auth-url", flow.authorizationUrl);
     * renderQr(flow.authorizationUrl);
     *
     * // 2) After reload, resume from the saved URL.
     * const savedUrl = sessionStorage.getItem("pubky-auth-url");
     * if (savedUrl) {
     *   try {
     *     const resumed = pubky.resumeCookieAuthFlow(savedUrl);
     *     const session = await resumed.awaitApproval();
     *   } finally {
     *     sessionStorage.removeItem("pubky-auth-url");
     *   }
     * }
     *
     * @deprecated Use `resumeGrantAuthFlow(...)` instead.
     */
    resumeCookieAuthFlow(authorization_url: string): AuthFlow;
    /**
     * Resume a previously saved pending delegated grant auth flow.
     *
     * Runtime: delegated grant keys require a secure browser context with
     * WebCrypto `crypto.subtle` and IndexedDB. The saved `keyId` must still
     * exist in IndexedDB for the same origin. Unsupported runtimes reject with
     * `ClientStateError`.
     */
    resumeDelegatedGrantAuthFlow(saved_state: string): Promise<GrantAuthFlow>;
    /**
     * Resume a previously saved pending grant auth flow.
     *
     * **Security:** `savedState` contains the relay secret and PoP client private key.
     * Delete it from storage as soon as the resumed flow completes.
     *
     * @param {string} savedState A string produced by `grantFlow.saveLocal()`.
     * @returns {GrantAuthFlow} A flow reconnected to the original relay channel.
     */
    resumeGrantAuthFlow(saved_state: string): GrantAuthFlow;
    /**
     * Create a `Signer` from an existing `Keypair`.
     *
     * @param {Keypair} keypair The user’s keys.
     * @returns {Signer}
     *
     * @example
     * const signer = pubky.signer(Keypair.random());
     * await signer.signup(homeserverPk);
     */
    signer(keypair: Keypair): Signer;
    /**
     * Start a **pubkyauth** flow.
     *
     * Provide a **capabilities string** and (optionally) a relay base URL.
     * The capabilities string is a comma-separated list of entries:
     * `"<scope>:<actions>"`, where:
     * - `scope` starts with `/` (e.g. `/pub/example.com/`).
     * - `actions` is any combo of `r` and/or `w` (order normalized; `wr` -> `rw`).
     * Pass `""` for no scopes (read-only public session).
     *
     * **Security:** `authorizationUrl` contains the `client_secret` in plaintext.
     * If you need resume after refresh/app switch, save it in `sessionStorage`
     * (not `localStorage`), then delete it once approval arrives or is abandoned.
     *
     * @param {string} capabilities Comma-separated caps, e.g. `"/pub/app/:rw,/pub/foo/file:r"`.
     * @param {AuthFlowKind} kind The kind of authentication flow to perform.
     * Examples:
     * - `AuthFlowKind.signin()` - Sign in to an existing account.
     * - `AuthFlowKind.signup(homeserverPublicKey, signupToken)` - Sign up for a new account.
     * @param {string=} relay Optional HTTP relay base (e.g. `"https://…/inbox/"`).
     * @param {XCallbackParams=} xCallback Optional app return destinations.
     * @returns {AuthFlow}
     * A running auth flow. Show `authorizationUrl` as QR/deeplink,
     * then `awaitApproval()` to obtain a `Session`.
     *
     * @throws {PubkyError}
     * - `{ name: "InvalidInput" }` for malformed capabilities or bad relay URL
     * - `{ name: "RequestError" }` if the flow cannot be started (network/relay)
     *
     * @example
     * const flow = pubky.startCookieAuthFlow("/pub/my-cool-app/:rw");
     * renderQr(flow.authorizationUrl);
     * const session = await flow.awaitApproval();
     *
     * @deprecated Use `startGrantAuthFlow(...)` instead.
     */
    startCookieAuthFlow(capabilities: Capabilities, kind: AuthFlowKind, relay?: string | null, x_callback?: XCallbackParams | null): AuthFlow;
    /**
     * Start a grant-backed **pubkyauth** flow.
     *
     * Grant auth uses a user-signed grant JWS plus Proof-of-Possession and
     * returns a self-refreshing session.
     * Select `approvalFormat: "signedApprovalV1"` and include `e` on scopes that need content
     * keys. Storage `r` and `w` alone do not deliver encryption keys.
     *
     * @param {string} capabilities Comma-separated caps, e.g. `"/pub/app/:rw,/pub/foo/file:r"`.
     * @param {AuthFlowKind} kind The kind of authentication flow to perform.
     * @param {GrantAuthFlowOptions} options Options for the grant flow:
     * `{ clientId, relay?, xCallback?, approvalFormat? }`.
     * @returns {Promise<GrantAuthFlow>}
     * A running grant auth flow. Show `authorizationUrl` as QR/deeplink,
     * then `awaitApproval()` to obtain a grant-backed `Session`.
     *
     * @example
     * const flow = await pubky.startGrantAuthFlow(
     *   "/pub/my-cool-app/:rw",
     *   AuthFlowKind.signin(),
     *   { clientId: "my-cool-app.example" },
     * );
     */
    startGrantAuthFlow(capabilities: Capabilities, kind: AuthFlowKind, options: GrantAuthFlowOptions): Promise<GrantAuthFlow>;
    /**
     * Create a Pubky facade preconfigured for a **local testnet**.
     *
     * If `host` is provided, PKARR and HTTP endpoints are derived as `http://<host>:ports/...`.
     * If omitted, `"localhost"` is assumed (handy for `cargo install pubky-testnet`).
     *
     * @param {string=} host Optional host (e.g. `"localhost"`, `"docker-host"`, `"127.0.0.1"`).
     * @returns {Pubky}
     *
     * @example
     * const pubky = Pubky.testnet();              // localhost default
     * const pubky = Pubky.testnet("docker-host"); // custom hostname/IP
     */
    static testnet(host?: string | null): Pubky;
    /**
     * Wrap an existing configured HTTP client into a Pubky facade.
     *
     * @param {Client} client A previously constructed client.
     * @returns {Pubky}
     *
     * @example
     * const client = Client.testnet();
     * const pubky = Pubky.withClient(client);
     */
    static withClient(client: Client): Pubky;
    /**
     * Browser-backed store for explicitly persisted completed grant sessions.
     *
     * Use `browserSessionStore.save(session)` after a successful grant auth flow to make
     * the session restorable after reload. The store supports multiple accounts
     * and multiple grants per account.
     */
    readonly browserSessionStore: BrowserSessionStore;
    /**
     * Access the underlying HTTP client (advanced).
     *
     * @returns {Client}
     * Use this for low-level `fetch()` calls or testing with raw URLs.
     *
     * @example
     * const r = await pubky.client.fetch(`pubky://${userPk.z32()}/pub/app/file.txt`, { credentials: "include" });
     */
    readonly client: Client;
    /**
     * Public, unauthenticated storage API.
     *
     * Use for **read-only** public access via addressed paths:
     * `"pubky<user>/pub/…"`.
     *
     * @returns {PublicStorage}
     *
     * @example
     * const text = await pubky.publicStorage.getText(`${userPk.toString()}/pub/example.com/hello.txt`);
     */
    readonly publicStorage: PublicStorage;
}

/**
 * An addressed resource: a user's public key paired with an absolute path.
 *
 * This represents a specific file or directory on a user's homeserver.
 *
 * @example
 * ```typescript
 * // Parse from a pubky URL
 * const resource = PubkyResource.parse("pubky://o1gg96ewuojmopcjbz8895478wdtxtzzuxnfjjz8o8e77csa1ngo/pub/example.txt");
 * console.log(resource.owner.z32()); // The user's public key
 * console.log(resource.path);        // "/pub/example.txt"
 * console.log(resource.toPubkyUrl()); // "pubky://o1gg96.../pub/example.txt"
 * ```
 */
export class PubkyResource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Parse a pubky resource from a string.
     *
     * Accepts:
     * - `pubky://<public_key>/<path>` (URL form)
     * - `pubky<public_key>/<path>` (identifier form)
     *
     * @param {string} value - The resource string to parse
     * @returns {PubkyResource} - The parsed resource
     * @throws {Error} - If the string is not a valid pubky resource
     */
    static parse(value: string): PubkyResource;
    /**
     * Render as `pubky://<owner>/<path>` (deep-link/URL form).
     */
    toPubkyUrl(): string;
    /**
     * Render as `pubky<owner>/<path>` (identifier form).
     */
    toString(): string;
    /**
     * Get the owner's public key.
     */
    readonly owner: PublicKey;
    /**
     * Get the absolute path (e.g., "/pub/example.txt").
     */
    readonly path: string;
}

export class PublicKey {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * @throws
     */
    static from(value: string): PublicKey;
    /**
     * Returns the identifier form with the `pubky` prefix.
     * Use for display only; transport/storage should use `.z32()`.
     */
    toString(): string;
    /**
     * Convert the PublicKey to Uint8Array
     */
    toUint8Array(): Uint8Array;
    /**
     * Returns the z-base32 encoding of this public key
     */
    z32(): string;
}

/**
 * Read-only public storage using addressed paths (`"pubky<user>/pub/..."`).
 */
export class PublicStorage {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Check if a path exists.
     *
     * @param {Address} address
     * @returns {Promise<boolean>}
     */
    exists(address: Address): Promise<boolean>;
    /**
     * Fetch bytes from an addressed path.
     *
     * @param {Address} address
     * @returns {Promise<Uint8Array>}
     */
    getBytes(address: Address): Promise<Uint8Array>;
    /**
     * Fetch JSON from an addressed path.
     *
     * @param {Address} address `"pubky<user>/pub/.../file.json"` (preferred) or `pubky://<user>/pub/...`.
     * @returns {Promise<any>}
     */
    getJson(address: Address): Promise<any>;
    /**
     * Fetch text from an addressed path as UTF-8 text.
     *
     * @param {Address} address
     * @returns {Promise<string>}
     */
    getText(address: Address): Promise<string>;
    /**
     * Perform a streaming `GET` and expose the raw `Response` object.
     *
     * @param {Address} address
     * @returns {Promise<Response>}
     */
    get(address: Address): Promise<Response>;
    /**
     * List a directory. Results are `pubky://…` identifier URLs.
     *
     * @param {Address} address Addressed directory (must end with `/`).
     * @param {string|null=} cursor Optional suffix or full URL to start **after**.
     * @param {boolean=} reverse Default `false`. When `true`, newest/lexicographically-last first.
     * @param {number=} limit Optional result limit.
     * @param {boolean=} shallow Default `false`. When `true`, lists only first-level entries.
     * @returns {Promise<string[]>}
     */
    list(address: Address, cursor?: string | null, reverse?: boolean | null, limit?: number | null, shallow?: boolean | null): Promise<string[]>;
    /**
     * Construct PublicStorage using global client (mainline relays).
     */
    constructor();
    /**
     * Get metadata for an address
     *
     * @param {Address} address `"pubky<user>/pub/.../file.json"` (preferred) or `pubky://<user>/pub/...`.
     * @returns {Promise<ResourceStats|undefined>} `undefined` if the resource does not exist.
     * @throws {PubkyError} On invalid input or transport/server errors.
     */
    stats(address: Address): Promise<ResourceStats | undefined>;
}

export class SeedExportDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static parse(url: string): SeedExportDeepLink;
    toString(): string;
    readonly secret: Uint8Array;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

/**
 * An authenticated context “as the user”.
 * - Use `storage` for reads/writes (absolute paths like `/pub/app/file.txt`)
 * - Cookie is managed automatically by the underlying fetch client
 */
export class Session {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Export the local secret material needed to restore this session.
     *
     * For local grant sessions this exports the grant JWS and PoP client secret;
     * restoring mints a fresh bearer. For legacy cookie sessions this exports the
     * cookie secret when the SDK owns it. Delegated browser grant sessions cannot
     * export raw secret material; use `BrowserSessionStore`.
     *
     * Treat the returned string as a bearer-equivalent secret until the grant or
     * cookie session expires or is revoked.
     *
     * @returns {Promise<string>}
     * A secret token that can be passed to `pubky.restoreSession()`.
     */
    exportLocalSecret(): Promise<string>;
    /**
     * Export the session metadata so it can be restored after a tab refresh.
     *
     * The export string contains **no secrets**; it only serializes the public `SessionInfo`.
     * Browsers remain responsible for persisting the HTTP-only session cookie.
     *
     * @returns {string}
     * A base64 string to store (e.g. in `localStorage`).
     *
     * @deprecated Use `GrantSession.exportLocalSecret()` instead.
     */
    export(): string;
    /**
     * Restore a session from an `export()` string.
     *
     * The HTTP-only cookie must still be present in the browser; this function does not
     * read or write any secrets.
     *
     * @param {string} exported
     * A string produced by `session.export()`.
     * @param {Client=} client
     * Optional client to reuse transport configuration.
     * @returns {Promise<Session>}
     *
     * @deprecated Use `Pubky.restoreSession(...)` with a grant secret.
     */
    static restore(exported: string, client?: Client | null): Promise<Session>;
    /**
     * Invalidate the session on the server (clears server cookie).
     * Further calls to storage API will fail.
     *
     * @returns {Promise<void>}
     */
    signout(): Promise<void>;
    /**
     * Cookie-only view for cookie-backed sessions.
     *
     * Grant-backed sessions return `undefined`.
     *
     * @returns {CookieSession|undefined}
     * @deprecated Use `session.grant` and `GrantSession` instead.
     */
    readonly cookie: CookieSession | undefined;
    /**
     * Grant-only management view for grant-backed sessions.
     *
     * Cookie-backed sessions return `undefined`.
     *
     * @returns {GrantSession|undefined}
     */
    readonly grant: GrantSession | undefined;
    /**
     * Retrieve immutable info about this session (user & capabilities).
     *
     * @returns {SessionInfo}
     */
    readonly info: SessionInfo;
    /**
     * Access the session-scoped storage API (read/write).
     *
     * @returns {SessionStorage}
     */
    readonly storage: SessionStorage;
}

/**
 * Static snapshot of session metadata.
 */
export class SessionInfo {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Effective capabilities granted to this session.
     *
     * @returns {string[]} Normalized capability entries (e.g. `"/pub/app/:rw"`).
     */
    readonly capabilities: string[];
    /**
     * The user’s public key for this session.
     *
     * Use `.toString()` on the returned `PublicKey` to get the `pubky<z32>` identifier.
     * Call `.z32()` when you specifically need the raw z-base32 value (e.g. hostnames).
     *
     * @returns {PublicKey}
     *
     * @example
     * const who = sessionInfo.publicKey.toString();
     */
    readonly publicKey: PublicKey;
}

/**
 * Read/write storage scoped to **your** session (absolute paths: `/pub/...` or `/priv/...`).
 *
 * Failures reject with a {@link PubkyError}. Path validation, transport, and HTTP
 * failures use `RequestError`; only HTTP errors include `data.statusCode`.
 * URL parsing failures use `InvalidInput`. Credential preparation, refresh,
 * and reading response bodies can also fail.
 *
 * Only {@link SessionStorage.exists} and {@link SessionStorage.stats} treat
 * HTTP 404/410 as missing. Other HTTP failures, including 401/403 and 5xx, reject.
 * Writes require write permission and can fail on directory targets (400),
 * file/directory path conflicts (409), a path someone holds a
 * {@link StorageLock} on (423), or exceeded quotas (507).
 */
export class SessionStorage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * `DELETE` the path of a lock this client holds. The lock stays in place.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one.
     * Otherwise as {@link SessionStorage.delete}.
     */
    deleteLocked(lock: StorageLock): Promise<void>;
    /**
     * Delete a file. Directory targets are unsupported.
     *
     * @param {Path} path File path; must not end with `/`.
     * @returns {Promise<void>}
     * @throws {PubkyError} Missing file (404), directory target (400), or shared errors
     * (see {@link SessionStorage}).
     */
    delete(path: Path): Promise<void>;
    /**
     * Check existence with a HEAD request.
     *
     * @param {Path} path
     * @returns {Promise<boolean>} `true` on success; `false` for HTTP 404/410.
     * @throws {PubkyError} All other failures (see {@link SessionStorage}).
     */
    exists(path: Path): Promise<boolean>;
    /**
     * GET bytes from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<Uint8Array>} The complete response body.
     * @throws {PubkyError} Missing resource (404/410) or shared errors (see {@link SessionStorage}).
     */
    getBytes(path: Path): Promise<Uint8Array>;
    /**
     * GET JSON from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<any>} The parsed JSON value.
     * @throws {PubkyError} Missing resource (404/410), JSON parsing/conversion failures,
     * or shared errors (see {@link SessionStorage}).
     */
    getJson(path: Path): Promise<any>;
    /**
     * GET text from an absolute session path.
     *
     * @param {Path} path
     * @returns {Promise<string>} The complete response body decoded as text.
     * @throws {PubkyError} Missing resource (404/410) or shared errors (see {@link SessionStorage}).
     */
    getText(path: Path): Promise<string>;
    /**
     * GET a streaming response for an absolute session path.
     *
     * Reading the returned response body can still fail after this resolves.
     *
     * @param {Path} path
     * @returns {Promise<Response>} A successful response with an unread body.
     * @throws {PubkyError} Missing resource (404/410) or other request/response errors.
     * See {@link SessionStorage} for shared errors.
     */
    get(path: Path): Promise<Response>;
    /**
     * List a directory (absolute session path).
     *
     * @param {Path} path Must end with `/`.
     * @param {string|null=} cursor Optional last entry URL to start **after**.
     * @param {boolean=} reverse Default `false`.
     * @param {number=} limit Optional result limit.
     * @param {boolean=} shallow Default `false`.
     * @returns {Promise<string[]>} `pubky://…` entry URLs, or an empty array for an empty page.
     * @throws {PubkyError} Missing directory (404), invalid cursor (400), invalid response
     * entries, or shared errors (see {@link SessionStorage}).
     */
    list(path: Path, cursor?: string | null, reverse?: boolean | null, limit?: number | null, shallow?: boolean | null): Promise<string[]>;
    /**
     * Take an exclusive write lock on a file at an **absolute session path**.
     *
     * The file need not exist; locking a free path reserves it. `timeoutSeconds` is
     * the lifetime asked for; the homeserver caps it, and
     * {@link StorageLock.timeoutSeconds} tells what was granted. A write made under
     * the lock keeps it alive until the write ends, so it need not cover the upload itself.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {number} timeoutSeconds Lifetime to ask for, in seconds; rounded down to
     * whole seconds, and at least 1.
     * @returns {Promise<StorageLock>} The granted lock.
     * @throws {PubkyError} `InvalidInput` for a negative, NaN or out-of-range timeout;
     * a path that is already locked rejects with `RequestError` and status `423`;
     * directory targets with `400`; a homeserver without lock support with `405`.
     * See {@link SessionStorage} for shared errors.
     */
    lock(path: Path, timeout_seconds: number): Promise<StorageLock>;
    /**
     * `PUT` binary data to the path of a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * Otherwise as {@link SessionStorage.putBytes}.
     */
    putBytesLocked(lock: StorageLock, body: Uint8Array): Promise<void>;
    /**
     * Create or replace a file with binary data at an absolute session path.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {Uint8Array} body
     * @returns {Promise<void>}
     * @throws {PubkyError} Upload or shared write/request errors (see {@link SessionStorage}).
     */
    putBytes(path: Path, body: Uint8Array): Promise<void>;
    /**
     * Create or replace a file with JSON at an absolute session path.
     *
     * @param {Path} path File path (e.g. `"/pub/app/data.json"`); must not end with `/`.
     * @param {any} body JSON-serializable value.
     * @returns {Promise<void>}
     * @throws {PubkyError} `InvalidInput` if `body` cannot be converted to JSON;
     * otherwise serialization, upload, or shared write/request errors (see {@link SessionStorage}).
     */
    putJson(path: Path, body: any): Promise<void>;
    /**
     * `PUT` text to the path of a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {string} body
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * Otherwise as {@link SessionStorage.putText}.
     */
    putTextLocked(lock: StorageLock, body: string): Promise<void>;
    /**
     * Create or replace a file with text at an absolute session path.
     *
     * @param {Path} path File path; must not end with `/`.
     * @param {string} body
     * @returns {Promise<void>}
     * @throws {PubkyError} Upload or shared write/request errors (see {@link SessionStorage}).
     */
    putText(path: Path, body: string): Promise<void>;
    /**
     * Restart the lifetime of a lock this client holds.
     *
     * On success the lock carries the newly granted
     * {@link StorageLock.timeoutSeconds}.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @param {number} timeoutSeconds Lifetime to ask for, in seconds; rounded down to
     * whole seconds, and at least 1.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that has expired or was unlocked rejects with
     * `RequestError` and status `412`; take a new one and read the file again.
     * `InvalidInput` for a negative, NaN or out-of-range timeout.
     * See {@link SessionStorage} for shared errors.
     */
    refreshLock(lock: StorageLock, timeout_seconds: number): Promise<void>;
    /**
     * Get metadata for an absolute, session-scoped path (e.g. `"/pub/app/file.json"`).
     *
     * On success, missing or unparseable metadata headers leave their properties absent.
     *
     * @param {Path} path Absolute path under your user (starts with `/`).
     * @returns {Promise<ResourceStats|undefined>} Metadata on success; `undefined` for HTTP 404/410.
     * @throws {PubkyError} All other failures (see {@link SessionStorage}).
     */
    stats(path: Path): Promise<ResourceStats | undefined>;
    /**
     * Release a lock this client holds.
     *
     * @param {StorageLock} lock A lock this client holds.
     * @returns {Promise<void>}
     * @throws {PubkyError} A lock that no longer exists rejects with `RequestError`
     * and status `409`. See {@link SessionStorage} for shared errors.
     */
    unlock(lock: StorageLock): Promise<void>;
}

/**
 * Holds a user’s `Keypair` and performs identity operations:
 * - `signup` creates a new homeserver user.
 * - `signin` creates a homeserver session for an existing user.
 * - Approve pubkyauth requests
 * - Publish PKDNS when signer-bound
 */
export class Signer {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Approve a `pubkyauth://` request URL (encrypts & POSTs the signed AuthToken).
     */
    approveAuthRequest(pubkyauth_url: string): Promise<void>;
    /**
     * Create a signer from a `Keypair` (prefer `pubky.signer(kp)`).
     *
     * @param {Keypair} keypair
     * @returns {Signer}
     */
    static fromKeypair(keypair: Keypair): Signer;
    /**
     * Handle a `pubkyauth://` deep link.
     *
     * Auth requests are approved through their relay. A `direct_signup` link
     * creates an account on its target homeserver.
     */
    handleDeepLink(pubkyauth_url: string): Promise<void>;
    /**
     * Blocking sign-in. Waits for PKDNS publish to complete (slower; safer).
     *
     * Creates a grant-backed homeserver session with root storage access (`/:rw`).
     * Encryption keys require an explicit `e` request through a signed approval flow.
     * `clientId` is shown in the user's grant/session list.
     * @param {string} clientId App identifier, typically a domain.
     *
     * @returns {Promise<Session>}
     */
    signinBlocking(client_id: string): Promise<Session>;
    /**
     * Legacy cookie blocking signin. Prefer `signinBlocking(clientId)`.
     *
     * @deprecated Prefer `signinBlocking(clientId)`.
     */
    signinCookieBlocking(): Promise<Session>;
    /**
     * Legacy cookie signin. Prefer `signin(clientId)`.
     *
     * @deprecated Prefer `signin(clientId)`.
     */
    signinCookie(): Promise<Session>;
    /**
     * Fast sign-in for a returning user. Publishes PKDNS in the background.
     *
     * Creates a grant-backed homeserver session with root storage access (`/:rw`).
     * Encryption keys require an explicit `e` request through a signed approval flow.
     * `clientId` is shown in the user's grant/session list.
     * @param {string} clientId App identifier, typically a domain.
     *
     * @returns {Promise<Session>}
     *
     * @throws {PubkyError}
     */
    signin(client_id: string): Promise<Session>;
    /**
     * Legacy cookie signup. Prefer `signup()` plus `signin(clientId)`.
     *
     * @deprecated Prefer `signup()` followed by `signin(clientId)`.
     */
    signupCookie(homeserver: PublicKey, signup_token?: string | null): Promise<Session>;
    /**
     * Sign up at a homeserver.
     *
     * Creates the account and publishes PKDNS. Call `signin(clientId)` to create a session.
     *
     * @param {PublicKey} homeserver The homeserver’s public key.
     * @param {string|null} signupToken Invite/registration token or `null`.
     * @returns {Promise<void>}
     *
     * @throws {PubkyError}
     * - `AuthenticationError` (bad/expired token)
     * - `RequestError` (network/server)
     */
    signup(homeserver: PublicKey, signup_token?: string | null): Promise<void>;
    /**
     * Get a PKDNS actor bound to this signer's client & keypair (publishing enabled).
     *
     * @returns {Pkdns}
     *
     * @example
     * await signer.pkdns.publishHomeserverIfStale(homeserverPk);
     */
    readonly pkdns: Pkdns;
    /**
     * Get the public key of this signer.
     *
     * @returns {PublicKey}
     */
    readonly publicKey: PublicKey;
}

export class SigninDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static parse(url: string): SigninDeepLink;
    toString(): string;
    readonly baseRelayUrl: string;
    readonly capabilities: string;
    readonly secret: Uint8Array;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

/**
 * Parsed grant-based signin deeplink.
 *
 * This is useful for tools, tests, and signer UIs that need to inspect a
 * `pubky://signin-grant` authorization URL before approving it.
 */
export class SigninGrantDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Parse a grant signin deeplink URL.
     *
     * @param {string} url
     * @returns {SigninGrantDeepLink}
     * @throws {PubkyError} `InvalidInput` when the URL is malformed or not a grant signin link.
     */
    static parse(url: string): SigninGrantDeepLink;
    /**
     * Serialize this parsed deeplink back to its URL form.
     *
     * @returns {string}
     */
    toString(): string;
    /**
     * Negotiated approval format: `bareGrant` or `signedApprovalV1`.
     */
    readonly approvalFormat: string;
    /**
     * Base HTTP relay inbox URL used by this auth request.
     *
     * @returns {string}
     */
    readonly baseRelayUrl: string;
    /**
     * Capabilities requested by the application.
     *
     * @returns {string}
     */
    readonly capabilities: string;
    /**
     * Application identifier shown in the user's grant/session list.
     *
     * @returns {string}
     */
    readonly clientId: string;
    /**
     * Public key for the Proof-of-Possession client created by the application.
     *
     * @returns {PublicKey}
     */
    readonly clientPublicKey: PublicKey;
    /**
     * Relay channel secret embedded in the deeplink.
     *
     * Treat this as sensitive temporary auth-flow material.
     *
     * @returns {Uint8Array}
     */
    readonly secret: Uint8Array;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

export class SignupDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    static parse(url: string): SignupDeepLink;
    toString(): string;
    readonly baseRelayUrl: string;
    readonly capabilities: string;
    readonly homeserver: PublicKey;
    readonly secret: Uint8Array;
    readonly signupToken: string | undefined;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

/**
 * Parsed grant-based signup deeplink.
 *
 * This is useful for tools, tests, and signer UIs that need to inspect a
 * `pubky://signup-grant` authorization URL before approving it.
 */
export class SignupGrantDeepLink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Parse a grant signup deeplink URL.
     *
     * @param {string} url
     * @returns {SignupGrantDeepLink}
     * @throws {PubkyError} `InvalidInput` when the URL is malformed or not a grant signup link.
     */
    static parse(url: string): SignupGrantDeepLink;
    /**
     * Serialize this parsed deeplink back to its URL form.
     *
     * @returns {string}
     */
    toString(): string;
    /**
     * Negotiated approval format: `bareGrant` or `signedApprovalV1`.
     */
    readonly approvalFormat: string;
    /**
     * Base HTTP relay inbox URL used by this auth request.
     *
     * @returns {string}
     */
    readonly baseRelayUrl: string;
    /**
     * Capabilities requested by the application.
     *
     * @returns {string}
     */
    readonly capabilities: string;
    /**
     * Application identifier shown in the user's grant/session list.
     *
     * @returns {string}
     */
    readonly clientId: string;
    /**
     * Public key for the Proof-of-Possession client created by the application.
     *
     * @returns {PublicKey}
     */
    readonly clientPublicKey: PublicKey;
    /**
     * Homeserver public key requested for account creation.
     *
     * @returns {PublicKey}
     */
    readonly homeserver: PublicKey;
    /**
     * Relay channel secret embedded in the deeplink.
     *
     * Treat this as sensitive temporary auth-flow material.
     *
     * @returns {Uint8Array}
     */
    readonly secret: Uint8Array;
    /**
     * Optional signup token included in the request.
     *
     * @returns {string|undefined}
     */
    readonly signupToken: string | undefined;
    /**
     * Optional x-callback-url metadata carried by this deep link.
     */
    readonly xCallback: XCallbackParams;
}

/**
 * An exclusive write lock on one file path, granted by the homeserver.
 *
 * While the lock lives, only writes that present it are accepted on the path;
 * every other write, and every other {@link SessionStorage.lock}, rejects with
 * `423 Locked`. The lock ends when it is {@link SessionStorage.unlock | unlocked}
 * or when its {@link StorageLock.timeoutSeconds} runs out without a
 * {@link SessionStorage.refreshLock | refresh}, so a client that disappears never
 * blocks a path for long.
 *
 * The lock is a bearer token: whoever holds this value, and may write the path,
 * can use and release the lock.
 *
 * Calls that take the lock may overlap: a {@link SessionStorage.refreshLock | refresh}
 * can run while a locked write is in flight.
 *
 * @example
 * const lock = await session.storage.lock("/pub/my.app/state.json", 30);
 * const state = await session.storage.getText(lock.path);
 * await session.storage.putTextLocked(lock, state);
 * await session.storage.unlock(lock);
 */
export class StorageLock {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Value of the `If` header that presents this lock on a write.
     */
    ifHeader(): string;
    /**
     * The locked path.
     */
    readonly path: Path;
    /**
     * Lifetime the homeserver granted at the last `lock` or `refreshLock`, in seconds,
     * counted from when that call resolved. It may be shorter than what was asked for.
     * It is not the time remaining: note when the call resolved to know when to refresh.
     */
    readonly timeoutSeconds: number;
    /**
     * The lock token URL, `opaquelocktoken:<uuid>`.
     */
    readonly token: string;
}

/**
 * Metadata for a session saved in the browser session store.
 */
export class StoredSessionInfo {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Authorized capabilities.
     */
    readonly capabilities: string[];
    /**
     * Application/client identifier.
     */
    readonly clientId: string;
    /**
     * Local save timestamp, in Unix milliseconds.
     */
    readonly createdAt: number;
    /**
     * Underlying grant expiry timestamp, in Unix seconds.
     */
    readonly grantExpiresAt: number;
    /**
     * Grant identifier backing this stored session.
     */
    readonly grantId: string;
    /**
     * Homeserver public key as z32.
     */
    readonly homeserver: string;
    /**
     * Stable local identifier for this stored session.
     */
    readonly id: string;
    /**
     * User public key as z32.
     */
    readonly publicKey: string;
    /**
     * `delegated` for origin-bound WebCrypto sessions, `localSecret` for raw local PoP secret storage.
     */
    readonly storageMode: string;
}

/**
 * Resolve a `pubky://` or `pubky<pk>/…` identifier into the homeserver transport URL.
 *
 * @param {string} identifier Either `pubky<pk>/...` (preferred) or `pubky://<pk>/...`.
 * @returns {string} HTTPS URL in the form `https://_pubky.<pk>/storage/<pk>/...`.
 */
export function resolvePubky(identifier: string): string;

/**
 * Set the global logging verbosity for the WASM Pubky SDK. Routes Rust `log` output to the browser console.
 *
 * Accepted values (case-sensitive): "error" | "warn" | "info" | "debug" | "trace".
 * Effects:
 * - Initializes the logger once; subsequent calls may throw if the logger is already set.
 * - Emits a single info log: `Log level set to: <level>`.
 * - Messages at or above `level` are forwarded to the appropriate `console.*` method.
 *
 * @param {Level} level
 *        Minimum log level to enable. One of: "error" | "warn" | "info" | "debug" | "trace".
 *
 * @returns {void}
 *
 * @throws {Error}
 *         If `level` is invalid ("Invalid log level") or the logger cannot be initialized
 *         (e.g., already initialized).
 *
 * Usage:
 *   Call once at application startup, before invoking other SDK APIs.
 */
export function setLogLevel(level: Level): void;

/**
 * Validate and normalize a capabilities string.
 *
 * - Normalizes action order (`wr` -> `rw`, `ewr` -> `rwe`).
 * - `e` requests scoped encryption/decryption keys in V1 grant approvals.
 * - Throws `InvalidInput` identifying the first malformed entry.
 *
 * @param {string} input
 * @returns {string} Normalized string (same shape as input).
 * @throws {PubkyError} `{ name: "InvalidInput" }` with a helpful message.
 * The error's `data` field is `{ invalidEntries: string[] }` containing the malformed token.
 */
export function validateCapabilities(input: string): string;

/**
 * Verify both signatures, grant binding, and grant validity against the local clock.
 * Allows 30 seconds of future clock skew by default; never extends grant expiry.
 * Does not check replay, application authorization, or homeserver revocation.
 */
export function verifyCustomGrantPop(credentials: CustomPop, options?: CustomPopVerificationOptions | null): VerifiedCustomPop;
